"""Seed currently open Indian government/public-sector recruitment data.

Snapshot checked on 02 September 2026.
Run from the backend directory:
    python seed-jobs.py

NOTE: Recruitment dates can change. Re-check the official notification before
applying. This seed file is a starting dataset for DataPath Navigator; it is
not a live government-job feed.
"""

from datetime import datetime

from database import SessionLocal
from models import GovernmentJob


# Snapshot: 02 September 2026 (IST)
sample_jobs = [
    {
        "title": "IBPS RRB XV - Office Assistant (Multipurpose)",
        "department": "Regional Rural Banks",
        "organization": "Institute of Banking Personnel Selection (IBPS)",
        "qualification": "Bachelor's degree in any discipline; local-language proficiency as prescribed by the participating RRB; computer knowledge desirable",
        "age_limit_min": 18,
        "age_limit_max": 28,
        "salary_range": "As per RRB pay scale and notification",
        "location": "All India",
        "state": "Central",
        "exam_type": "Banking - IBPS RRB",
        "vacancies": 8183,
        "apply_link": "https://ibpsreg.ibps.in/rrboaxvaug26/",
        "description": "Common Recruitment Process for Office Assistants (Multipurpose) in Regional Rural Banks under CRP-RRBs XV.",
        "eligibility": "Bachelor's degree in any discipline from a recognised university or equivalent. Candidate must meet the local-language requirement of the participating RRB. Check the official notification for category-wise age relaxation and other conditions.",
        "exam_pattern": "Preliminary Examination followed by Main Examination. The 2026-27 calendar lists Office Assistant prelims on 6, 12 and 13 December 2026 and the main examination on 30 January 2027.",
        "syllabus_link": "https://www.ibps.in/index.php/recruitment-of-office-assistants-multipurpose-under-crp-rrbs-xv/",
        "last_date": datetime(2026, 9, 21, 23, 59, 59),
        "is_active": True,
    },
    {
        "title": "IBPS RRB XV - Officer Scale I (Assistant Manager)",
        "department": "Regional Rural Banks",
        "organization": "Institute of Banking Personnel Selection (IBPS)",
        "qualification": "Bachelor's degree in any discipline; local-language proficiency as prescribed by the participating RRB; computer knowledge desirable",
        "age_limit_min": 18,
        "age_limit_max": 30,
        "salary_range": "As per Officer Scale I RRB pay scale and notification",
        "location": "All India",
        "state": "Central",
        "exam_type": "Banking - IBPS RRB",
        "vacancies": 4256,
        "apply_link": "https://ibpsreg.ibps.in/rrbxvaug26/",
        "description": "CRP-RRBs XV recruitment for Officer Scale I (Assistant Manager) posts in Regional Rural Banks.",
        "eligibility": "Bachelor's degree in any discipline from a recognised university or equivalent, subject to the detailed notification and participating-RRB requirements. Check the official notification for category-wise age relaxation and other conditions.",
        "exam_pattern": "Preliminary Examination followed by Main Examination and the prescribed selection process. The 2026-27 calendar lists Scale I prelims on 21 and 22 November 2026 and the main examination on 20 December 2026.",
        "syllabus_link": "https://www.ibps.in/index.php/recruitment-of-officers-scale-i-ii-iii-under-crp-rrbs-xv/",
        "last_date": datetime(2026, 9, 21, 23, 59, 59),
        "is_active": True,
    },
    {
        "title": "IBPS RRB XV - Officer Scale II Information Technology",
        "department": "Regional Rural Banks",
        "organization": "Institute of Banking Personnel Selection (IBPS)",
        "qualification": "Degree in Electronics/Communication/Computer Science/Information Technology or related qualification as specified; post-qualification experience required as per notification",
        "age_limit_min": 21,
        "age_limit_max": 32,
        "salary_range": "As per Officer Scale II RRB pay scale and notification",
        "location": "All India",
        "state": "Central",
        "exam_type": "Banking - IBPS RRB IT",
        "vacancies": 182,
        "apply_link": "https://ibpsreg.ibps.in/rrbxvaug26/",
        "description": "Specialist Officer Scale II Information Technology recruitment under CRP-RRBs XV. This is particularly relevant to candidates with computer science or IT backgrounds.",
        "eligibility": "Relevant IT/Computer Science/Electronics qualification and post-qualification experience as prescribed in the official CRP-RRBs XV notification. Candidates must satisfy all post-specific conditions.",
        "exam_pattern": "Single/Main examination and interview/selection process as prescribed for Officer Scale II. Check the official notification for the detailed IT syllabus and selection rules.",
        "syllabus_link": "https://www.ibps.in/index.php/notification-for-common-recruitment-process-for-crp-rrb-xv/",
        "last_date": datetime(2026, 9, 21, 23, 59, 59),
        "is_active": True,
    },
    {
        "title": "Indian Overseas Bank - Generalist / Specialist Officers 2026-27",
        "department": "Banking",
        "organization": "Indian Overseas Bank",
        "qualification": "Degree/PG and post-qualification experience as specified for the selected Generalist or Specialist post",
        "age_limit_min": 22,
        "age_limit_max": 45,
        "salary_range": "₹48,480 - ₹1,05,280 (scale-wise; post-specific)",
        "location": "All India",
        "state": "Central",
        "exam_type": "Banking - IOB",
        "vacancies": 291,
        "apply_link": "https://www.iob.bank.in/en/Careers",
        "description": "Recruitment of Generalist and Specialist Officers in JMGS I, MMGS II and MMGS III under Advertisement No. HRDD/RECT/04/2026-27.",
        "eligibility": "Eligibility varies by post code. The recruitment covers branch management, IT, information security, IS audit, database/network administration, cyber security, credit, risk and security roles. Candidates must satisfy the qualification and experience requirements of the selected post.",
        "exam_pattern": "Online Examination followed by Personal Interview. Final selection uses the weightage prescribed in the official notification.",
        "syllabus_link": "https://www.iob.bank.in/en/Careers",
        "last_date": datetime(2026, 9, 15, 23, 59, 59),
        "is_active": True,
    },
    {
        "title": "Sainik School Ambikapur - Laboratory Assistant (Biology)",
        "department": "Sainik Schools Society / Ministry of Defence",
        "organization": "Sainik School Ambikapur",
        "qualification": "Intermediate/12th Science or equivalent with Biology",
        "age_limit_min": 21,
        "age_limit_max": 35,
        "salary_range": "Pay Level 4 of 7th CPC",
        "location": "Ambikapur, Chhattisgarh",
        "state": "Chhattisgarh",
        "exam_type": "Defence / Education",
        "vacancies": 1,
        "apply_link": "https://employmentnews.gov.in/newemp/AllJobs.aspx?k=All",
        "description": "Regular Laboratory Assistant (Biology) recruitment at Sainik School Ambikapur. The vacancy is listed through Employment News and the school's recruitment notice.",
        "eligibility": "Intermediate/12th Science or equivalent with Biology. Candidates should verify category, age cut-off, application mode and all post-specific conditions in the official notice.",
        "exam_pattern": "Selection process is as prescribed in the Sainik School Ambikapur recruitment notice.",
        "syllabus_link": "https://employmentnews.gov.in/newemp/AllJobs.aspx?k=All",
        "last_date": datetime(2026, 9, 11, 23, 59, 59),
        "is_active": True,
    },
    {
        "title": "BRIC-NIAB - Scientist-B and Farm Manager",
        "department": "Department of Biotechnology, Ministry of Science and Technology",
        "organization": "BRIC - National Institute of Animal Biotechnology (NIAB)",
        "qualification": "Scientist-B: M.V.Sc/M.Sc/M.Tech or equivalent with required R&D experience; Farm Manager: relevant degree in Animal Husbandry/Horticulture/Life Sciences as specified",
        "age_limit_min": 18,
        "age_limit_max": 40,
        "salary_range": "As per BRIC-NIAB recruitment notification",
        "location": "Hyderabad, Telangana",
        "state": "Telangana",
        "exam_type": "Scientific Research",
        "vacancies": 2,
        "apply_link": "https://employmentnews.gov.in/newemp/AllJobs.aspx?k=All",
        "description": "Direct recruitment for Scientist-B and Farm Manager at BRIC-National Institute of Animal Biotechnology, Hyderabad.",
        "eligibility": "Scientist-B requires the specified postgraduate qualification and relevant R&D experience. Farm Manager requires the qualification prescribed in the notification. The notification states post-specific eligibility and reservation conditions.",
        "exam_pattern": "Shortlisting and selection process as specified in the BRIC-NIAB recruitment notification.",
        "syllabus_link": "https://employmentnews.gov.in/newemp/AllJobs.aspx?k=All",
        "last_date": datetime(2026, 9, 11, 17, 0, 0),
        "is_active": True,
    },
    {
        "title": "LBSNAA - Administrative Officer (Accounts)",
        "department": "Department of Personnel and Training",
        "organization": "Lal Bahadur Shastri National Academy of Administration",
        "qualification": "Central Government service/experience and accounts qualifications as specified; deputation post",
        "age_limit_min": 18,
        "age_limit_max": 56,
        "salary_range": "Pay Level as specified in the official vacancy notice",
        "location": "Mussoorie, Uttarakhand",
        "state": "Uttarakhand",
        "exam_type": "Central Government - Deputation",
        "vacancies": 1,
        "apply_link": "https://www.lbsnaa.gov.in/vacancy",
        "description": "Administrative Officer (Accounts) vacancy at LBSNAA, Mussoorie. This is a deputation opportunity and is not intended for fresh graduates.",
        "eligibility": "For eligible government/public-sector officers meeting the deputation, service and accounts requirements in the official notice. Fresh graduates should not treat this as an entry-level vacancy.",
        "exam_pattern": "Selection through the deputation process prescribed by LBSNAA/DoPT; see the official vacancy notice.",
        "syllabus_link": "https://www.lbsnaa.gov.in/vacancy",
        "last_date": datetime(2026, 9, 16, 23, 59, 59),
        "is_active": True,
    },
]


def seed_jobs():
    db = SessionLocal()
    try:
        # Remove old seed records so the portal shows the current snapshot.
        # WARNING: only use this script for the seeded government-job dataset.
        db.query(GovernmentJob).delete(synchronize_session=False)
        db.commit()

        for job_data in sample_jobs:
            db.add(GovernmentJob(**job_data))

        db.commit()
        print(f"Inserted {len(sample_jobs)} current government/public-sector jobs.")
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


if __name__ == "__main__":
    seed_jobs()
