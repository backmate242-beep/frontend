function injectSidebar(activePage) {
    const user = api.getUser();
    const userName = user?.full_name || "User";
    const userInitial = userName.charAt(0).toUpperCase();
    const sector = localStorage.getItem('preferred_sector') || 'career';

    let menuItems = '';

    if (sector === 'career') {
        menuItems = `
            <li><a href="dashboard.html" class="${activePage === 'dashboard' ? 'active' : ''}"><span class="icon"><i class="fas fa-chart-pie" aria-hidden="true"></i></span> Dashboard</a></li>
            <li><a href="profile.html" class="${activePage === 'profile' ? 'active' : ''}"><span class="icon"><i class="fas fa-user" aria-hidden="true"></i></span> Profile</a></li>
            <li><a href="ai-recommendations.html" class="${activePage === 'recs' ? 'active' : ''}"><span class="icon"><i class="fas fa-bullseye" aria-hidden="true"></i></span> Career Recommendation</a></li>
            <li><a href="skill-gap.html" class="${activePage === 'skillgap' ? 'active' : ''}"><span class="icon"><i class="fas fa-chart-line" aria-hidden="true"></i></span> Skill Gap Analysis</a></li>
            <li><a href="roadmap.html" class="${activePage === 'roadmap' ? 'active' : ''}"><span class="icon"><i class="fas fa-route" aria-hidden="true"></i></span> Career Roadmap</a></li>
            <li><a href="resource-center.html" class="${activePage === 'resources' ? 'active' : ''}"><span class="icon"><i class="fas fa-book-open" aria-hidden="true"></i></span> Resource Center</a></li>
            <li class="${(activePage === 'aptitude' || activePage === 'mock') ? 'active' : ''}"><a href="javascript:void(0)"><span class="icon"><i class="fas fa-clipboard-check" aria-hidden="true"></i></span> Career Assessments</a>
                <ul class="submenu">
                    <li><a href="aptitude-test.html" class="${activePage === 'aptitude' ? 'active' : ''}">Aptitude Test</a></li>
                    <li><a href="mock-interview.html" class="${activePage === 'mock' ? 'active' : ''}">Mock Interview</a></li>
                </ul>
            </li>
            <li><a href="ai-chat.html" class="${activePage === 'chat' ? 'active' : ''}"><span class="icon"><i class="fas fa-robot" aria-hidden="true"></i></span> AI Chat</a></li>
            <li><a href="settings.html" class="${activePage === 'settings' ? 'active' : ''}"><span class="icon"><i class="fas fa-sliders" aria-hidden="true"></i></span> Settings</a></li>
        `;
    } else if (sector === 'government') {
        // <i class="fas fa-check-circle" aria-hidden="true"></i> UPDATED: Mock interview removed, aptitude practice added
        menuItems = `
            <li><a href="government-dashboard.html" class="${activePage === 'gov-dashboard' ? 'active' : ''}"><span class="icon"><i class="fas fa-landmark" aria-hidden="true"></i></span> Govt Dashboard</a></li>
            <li><a href="government-jobs.html" class="${activePage === 'gov-jobs' ? 'active' : ''}"><span class="icon"><i class="fas fa-clipboard-list" aria-hidden="true"></i></span> All Govt Jobs</a></li>
            <li><a href="government-bookmarks.html" class="${activePage === 'gov-bookmarks' ? 'active' : ''}"><span class="icon"><i class="fas fa-bookmark" aria-hidden="true"></i></span> My Bookmarks</a></li>
            <li><a href="government-aptitude.html" class="${activePage === 'gov-aptitude' ? 'active' : ''}"><span class="icon"><i class="fas fa-pen-square" aria-hidden="true"></i></span> AI Exam Practice</a></li>
            <li><a href="resource-center.html" class="${activePage === 'resources' ? 'active' : ''}"><span class="icon"><i class="fas fa-book-open" aria-hidden="true"></i></span> AI Resource Center</a></li>
            <li><a href="ai-chat.html" class="${activePage === 'chat' ? 'active' : ''}"><span class="icon"><i class="fas fa-robot" aria-hidden="true"></i></span> AI Chat</a></li>
            <li><a href="profile.html" class="${activePage === 'profile' ? 'active' : ''}"><span class="icon"><i class="fas fa-user" aria-hidden="true"></i></span> Profile</a></li>
            <li><a href="settings.html" class="${activePage === 'settings' ? 'active' : ''}"><span class="icon"><i class="fas fa-cog" aria-hidden="true"></i></span> Settings</a></li>
        `;
    }

    const sidebarHTML = `
        <aside class="sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <div class="logo-icon">
                        <img data-theme-logo data-dark-logo="photos/datapath-logo-dark.png" data-light-logo="photos/datapath-logo-light.png" src="photos/datapath-logo-light.png" alt="DataPath Navigator" class="logo-image"
                            >
                    </div>
                </div>
                <div class="sidebar-user">
                    <div class="sidebar-user-avatar"><span>${userInitial}</span></div>
                    <div class="sidebar-user-info">
                        <span class="sidebar-user-name">${userName}</span>
                        <span class="sidebar-user-role">
                            ${user?.role === 'admin' ? '<i class="fas fa-crown" aria-hidden="true"></i> Admin' :
                              sector === 'government' ? '<i class="fas fa-landmark" aria-hidden="true"></i> Govt Jobs' : '<i class="fas fa-laptop-code" aria-hidden="true"></i> IT Jobs'}
                        </span>
                    </div>
                </div>
            </div>
            <ul class="sidebar-menu">${menuItems}</ul>
        </aside>
    `;
    document.body.insertAdjacentHTML("afterbegin", sidebarHTML);
}


function injectTopHeader() {
    const main = document.querySelector('.main-content');
    if (!main || main.querySelector('.top-header')) return;
    const user = api.getUser();
    const userName = user?.full_name || 'Student';
    const initial = userName.charAt(0).toUpperCase();
    const pageTitles = {
        dashboard:'Career Overview', profile:'My Profile', aptitude:'Career Assessment', mock:'Mock Interview',
        recs:'AI Recommendations', roadmap:'Career Roadmap', skillgap:'Skill Gap Analysis', resources:'Resource Center',
        chat:'AI Career Assistant', settings:'Settings', 'gov-dashboard':'Government Jobs', 'gov-jobs':'All Government Jobs',
        'gov-bookmarks':'Saved Government Jobs', 'gov-aptitude':'AI Exam Practice', 'gov-detail':'Job Details',
        admin:'Admin Dashboard', 'admin-scraper':'Job Data Manager'
    };
    const page = document.body.dataset.page || 'dashboard';
    const title = pageTitles[page] || 'Career Navigator';
    main.insertAdjacentHTML('afterbegin', `
        <header class="top-header">
            <div style="display:flex;align-items:center;gap:.8rem;min-width:0">
                <button class="menu-toggle" type="button" aria-label="Open menu" onclick="document.querySelector('.sidebar')?.classList.toggle('open')"><i class="fas fa-bars"></i></button>
                <div style="min-width:0"><div style="font-size:.72rem;color:#66748d;font-weight:650;text-transform:uppercase;letter-spacing:1px">DataPath Navigator</div><strong style="display:block;font-size:.98rem;letter-spacing:-.02em;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${title}</strong></div>
            </div>
            <button class="theme-toggle header-theme-toggle" data-theme-toggle aria-label="Toggle theme"></button><div class="header-user" onclick="toggleUserMenu()">
                <div class="header-user-avatar">${initial}</div><span class="header-user-name">${userName}</span><i class="fas fa-chevron-down header-user-arrow"></i>
                <div class="header-user-menu" id="headerUserMenu">
                    <div class="menu-header"><strong>${userName}</strong><small>${user?.role === 'admin' ? 'Administrator' : 'Career Explorer'}</small></div>
                    <div class="menu-divider"></div><a class="menu-item" href="profile.html"><i class="fas fa-user"></i> Profile</a><a class="menu-item" href="settings.html"><i class="fas fa-cog"></i> Settings</a><a class="menu-item danger" href="javascript:logout()"><i class="fas fa-sign-out-alt"></i> Logout</a>
                </div>
            </div>
        </header>
    `);
}

function toggleUserMenu() {
    const menu = document.getElementById("headerUserMenu");
    if (menu) menu.classList.toggle("show");
}

document.addEventListener("click", (e) => {
    const userEl = document.querySelector(".header-user");
    if (userEl && !userEl.contains(e.target)) {
        const menu = document.getElementById("headerUserMenu");
        if (menu) menu.classList.remove("show");
    }
});

document.addEventListener("DOMContentLoaded", () => {
    if (document.querySelector(".app-container")) {
        const page = document.body.dataset.page || "dashboard";
        injectSidebar(page);
        injectTopHeader();
    }
});
