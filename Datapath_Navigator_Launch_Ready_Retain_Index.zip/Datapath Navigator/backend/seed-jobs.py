from datetime import datetime, timedelta, timezone
from database import SessionLocal
from models import GovernmentJob


db = SessionLocal()

try:
    # Check existing government jobs
    existing_jobs = db.query(GovernmentJob).count()

    if existing_jobs > 0:
        print(f"Government jobs already exist: {existing_jobs}")
        print("No new jobs inserted.")
    else:
        jobs = [
            {
                "title": "IBPS RRB Office Assistant",
                "department": "Banking",
                "organization": "IBPS",
                "qualification": "Bachelor's Degree",
                "age_limit_min": 18,
                "age_limit_max": 28,
                "salary_range": "₹35,000+",
                "location": "All India",
                "state": "All India",
                "exam_type": "IBPS RRB",
                "vacancies": 8183,
                "apply_link": "https://ibps.in/",
                "description": "Recruitment for Office Assistant posts under Regional Rural Banks.",
                "eligibility": "Bachelor's degree from a recognized university.",
                "exam_pattern": "Prelims and Mains",
                "syllabus_link": "https://ibps.in/",
                "posted_date": datetime.now(timezone.utc),
                "last_date": datetime.now(timezone.utc) + timedelta(days=20),
                "is_active": True,
            },
            {
                "title": "IBPS RRB Officer Scale I",
                "department": "Banking",
                "organization": "IBPS",
                "qualification": "Bachelor's Degree",
                "age_limit_min": 18,
                "age_limit_max": 30,
                "salary_range": "₹45,000+",
                "location": "All India",
                "state": "All India",
                "exam_type": "IBPS RRB",
                "vacancies": 4256,
                "apply_link": "https://ibps.in/",
                "description": "Recruitment for Officer Scale I posts in Regional Rural Banks.",
                "eligibility": "Bachelor's degree from a recognized university.",
                "exam_pattern": "Prelims and Mains",
                "syllabus_link": "https://ibps.in/",
                "posted_date": datetime.now(timezone.utc),
                "last_date": datetime.now(timezone.utc) + timedelta(days=20),
                "is_active": True,
            },
            {
                "title": "IBPS RRB Officer Scale II IT",
                "department": "Banking",
                "organization": "IBPS",
                "qualification": "Bachelor's / Master's Degree in IT or Computer Science",
                "age_limit_min": 21,
                "age_limit_max": 32,
                "salary_range": "₹50,000+",
                "location": "All India",
                "state": "All India",
                "exam_type": "IBPS RRB",
                "vacancies": 182,
                "apply_link": "https://ibps.in/",
                "description": "IT specialist officer recruitment for Regional Rural Banks.",
                "eligibility": "Relevant qualification in IT, Computer Science or related field.",
                "exam_pattern": "Single Online Examination and Interview",
                "syllabus_link": "https://ibps.in/",
                "posted_date": datetime.now(timezone.utc),
                "last_date": datetime.now(timezone.utc) + timedelta(days=20),
                "is_active": True,
            },
        ]

        for job_data in jobs:
            db.add(GovernmentJob(**job_data))

        db.commit()

        print(f"Successfully inserted {len(jobs)} government jobs.")

except Exception as e:
    db.rollback()
    print("ERROR: Unable to seed government jobs.")
    print(f"Reason: {e}")

finally:
    db.close()