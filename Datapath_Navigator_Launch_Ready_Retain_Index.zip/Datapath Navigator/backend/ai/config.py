# ai/config.py
import os
from dotenv import load_dotenv

load_dotenv()
load_dotenv(dotenv_path=os.path.join(os.path.dirname(__file__), '..', '.env'))


# ============================================================
# Define blocklist at module level FIRST (before class)
# ============================================================
BLOCKED_MODELS = {
    "groq/compound",
    "groq/compound-mini",
    "qwen/qwen3-32b",
    "qwen/qwen3.6-27b",
    "qwen/qwen-3.6-27b",  # safety: catch the original typo from your list too
}

VERIFIED_MODELS = {
    "openai/gpt-oss-120b",
    "openai/gpt-oss-20b",
    "openai/gpt-oss-safeguard-20b",
    "meta-llama/llama-prompt-guard-2-86m",
    "meta-llama/llama-prompt-guard-2-22m",
    "canopylabs/orpheus-v1-english",
    "canopylabs/orpheus-arabic-saudi",
    "whisper-large-v3-turbo",
    "whisper-large-v3",
}

GROQ_MODELS_ALL = [
    # Reasoning / chat
    "openai/gpt-oss-120b",
    "openai/gpt-oss-20b",
    "openai/gpt-oss-safeguard-20b",
    # Safety
    "meta-llama/llama-prompt-guard-2-86m",
    "meta-llama/llama-prompt-guard-2-22m",
    # Audio
    "whisper-large-v3",
    "whisper-large-v3-turbo",
    "canopylabs/orpheus-v1-english",
    "canopylabs/orpheus-arabic-saudi",
    # Compound (gated)
    "groq/compound",
    "groq/compound-mini",
]

# Filter the full list (works at module level, not class level)
GROQ_MODELS = [m for m in GROQ_MODELS_ALL if m not in BLOCKED_MODELS]


class AIConfig:
    GROQ_API_KEY = os.getenv("GROQ_API_KEY", "").strip()

    # ============================================================
    # OPERATION-SPECIFIC MODEL MAPPING
    # ============================================================
    # High-quality reasoning (120B) for nuanced tasks
    MODEL_CHAT = "openai/gpt-oss-120b"
    MODEL_SKILL_GAP = "openai/gpt-oss-120b"
    MODEL_INTERVIEW = "openai/gpt-oss-120b"
    MODEL_EVAL = "openai/gpt-oss-120b"

    # Compound models are blocked → use 120B
    MODEL_RECOMMENDATIONS = "openai/gpt-oss-120b"
    MODEL_ROADMAP = "openai/gpt-oss-120b"
    MODEL_RESUME = "openai/gpt-oss-120b"

    # Fast structured output
    MODEL_APTITUDE = "openai/gpt-oss-20b"

    # Courses: was qwen/qwen3-32b (404) → use 20B
    MODEL_COURSES = "openai/gpt-oss-20b"
    MODEL_GOVT_APTITUDE = "openai/gpt-oss-20b"
    MODEL_GOVT_RESOURCES = "openai/gpt-oss-20b"
    MODEL_GOVT_JOB = "openai/gpt-oss-120b"
    MODEL_DEFAULT = "openai/gpt-oss-20b"

    # Safety
    MODEL_SAFEGUARD = "openai/gpt-oss-safeguard-20b"
    MODEL_PROMPT_GUARD = "meta-llama/llama-prompt-guard-2-86m"
    MODEL_PROMPT_GUARD_TINY = "meta-llama/llama-prompt-guard-2-22m"

    # Audio
    MODEL_STT = "whisper-large-v3-turbo"
    MODEL_STT_LARGE = "whisper-large-v3"
    MODEL_TTS = "canopylabs/orpheus-v1-english"
    MODEL_TTS_ARABIC = "canopylabs/orpheus-arabic-saudi"

    # Reference the module-level constants
    BLOCKED_MODELS = BLOCKED_MODELS
    VERIFIED_MODELS = VERIFIED_MODELS
    GROQ_MODELS = GROQ_MODELS

    # Defaults
    AI_PROVIDER = "groq"
    MODEL_NAME = "openai/gpt-oss-120b"
    AI_TEMPERATURE = float(os.getenv("AI_TEMPERATURE", "0.7"))
    AI_MAX_TOKENS = int(os.getenv("AI_MAX_TOKENS", "1500"))

    USE_GROQ = bool(
        GROQ_API_KEY and
        len(GROQ_API_KEY) > 20 and
        GROQ_API_KEY.startswith("gsk_")
    )
    USE_GEMINI = False
    USE_AI = USE_GROQ

    MAX_CONVERSATION_HISTORY = 10
    RECOMMENDATION_TOP_N = 5
    SKILL_MATCH_THRESHOLD = 30.0

    ENABLE_INPUT_GUARD = os.getenv("ENABLE_INPUT_GUARD", "true").lower() == "true"
    ENABLE_OUTPUT_SAFEGUARD = os.getenv("ENABLE_OUTPUT_SAFEGUARD", "true").lower() == "true"

    DEFAULT_VOICE = os.getenv("DEFAULT_VOICE", "allison")


PROFICIENCY_WEIGHTS = {"Beginner": 0.4, "Intermediate": 0.7, "Advanced": 1.0}
IMPORTANCE_WEIGHTS = {"Low": 0.5, "Medium": 1.0, "High": 1.5}


if __name__ == "__main__":
    print(f"GROQ available: {AIConfig.USE_GROQ}")
    print(f"Provider: {AIConfig.AI_PROVIDER}")
    print(f"\n� Operation → Model mapping:")
    print(f"   💬 Chat:           {AIConfig.MODEL_CHAT}")
    print(f"   🎯 Recommendations: {AIConfig.MODEL_RECOMMENDATIONS}")
    print(f"   📊 Skill Gap:      {AIConfig.MODEL_SKILL_GAP}")
    print(f"   🗺️  Roadmap:        {AIConfig.MODEL_ROADMAP}")
    print(f"   📝 Aptitude Qs:    {AIConfig.MODEL_APTITUDE}")
    print(f"   🏛️ Govt Aptitude:  {AIConfig.MODEL_GOVT_APTITUDE}")
    print(f"   📚 Govt Resources: {AIConfig.MODEL_GOVT_RESOURCES}")
    print(f"   🎯 Govt Job AI:    {AIConfig.MODEL_GOVT_JOB}")
    print(f"   🎤 Interview Qs:   {AIConfig.MODEL_INTERVIEW}")
    print(f"   ⚖️  Evaluation:     {AIConfig.MODEL_EVAL}")
    print(f"   📄 Resume:         {AIConfig.MODEL_RESUME}")
    print(f"   📚 Courses:        {AIConfig.MODEL_COURSES}")
    print(f"   🛡️  Safeguard:      {AIConfig.MODEL_SAFEGUARD}")
    print(f"   🚧 Prompt Guard:   {AIConfig.MODEL_PROMPT_GUARD}")
    print(f"   🎙️ STT:            {AIConfig.MODEL_STT}")
    print(f"   🔊 TTS:            {AIConfig.MODEL_TTS}")
    print(f"\n🚫 Blocked: {AIConfig.BLOCKED_MODELS}")
