# routers/auth.py
import os
import secrets
from urllib.parse import quote
from datetime import timedelta

from fastapi import APIRouter, Depends, HTTPException, status, Request
from fastapi.security import OAuth2PasswordRequestForm
from fastapi.responses import RedirectResponse
from sqlalchemy.orm import Session
from authlib.integrations.starlette_client import OAuth

from database import get_db
from models import User
from schemas import UserCreate, UserResponse
from utils.hashing import verify_password, hash_password
from utils.token import create_access_token
from crud import create_user, get_user_by_email
from oauth2 import get_current_user

router = APIRouter(prefix="/auth", tags=["Authentication"])

# OAuth clients are optional. Normal email/password authentication still works
# when the Google/Facebook credentials have not been configured.
oauth = OAuth()
FRONTEND_URL = os.getenv("FRONTEND_URL", "http://127.0.0.1:5500").rstrip("/")
BACKEND_URL = os.getenv("BACKEND_URL", "http://localhost:8000").rstrip("/")

GOOGLE_CLIENT_ID = os.getenv("GOOGLE_CLIENT_ID")
GOOGLE_CLIENT_SECRET = os.getenv("GOOGLE_CLIENT_SECRET")
FACEBOOK_CLIENT_ID = os.getenv("FACEBOOK_CLIENT_ID")
FACEBOOK_CLIENT_SECRET = os.getenv("FACEBOOK_CLIENT_SECRET")

if GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET:
    oauth.register(
        name="google",
        client_id=GOOGLE_CLIENT_ID,
        client_secret=GOOGLE_CLIENT_SECRET,
        server_metadata_url="https://accounts.google.com/.well-known/openid-configuration",
        client_kwargs={"scope": "openid email profile"},
    )

if FACEBOOK_CLIENT_ID and FACEBOOK_CLIENT_SECRET:
    oauth.register(
        name="facebook",
        client_id=FACEBOOK_CLIENT_ID,
        client_secret=FACEBOOK_CLIENT_SECRET,
        access_token_url="https://graph.facebook.com/oauth/access_token",
        authorize_url="https://www.facebook.com/dialog/oauth",
        api_base_url="https://graph.facebook.com/",
        client_kwargs={"scope": "email public_profile"},
    )


def _frontend_callback(token: str, user: User):
    """Send the JWT to a tiny frontend callback page, then continue to preferences."""
    role = user.role or "student"
    name = (user.full_name or "Student").replace("\\", "\\\\").replace('"', '\\"')
    url = (
        f"{FRONTEND_URL}/oauth-callback.html"
        f"?access_token={token}&user_id={user.user_id}&role={role}"
        f"&name={quote(name)}"
    )
    return RedirectResponse(url=url, status_code=302)


def _login_user(user: User):
    token = create_access_token(
        data={"user_id": user.user_id, "role": user.role},
        expires_delta=timedelta(minutes=60),
    )
    return {
        "access_token": token,
        "token_type": "bearer",
        "user_id": user.user_id,
        "role": user.role,
    }


def _get_or_create_social_user(db: Session, email: str, name: str):
    """Create a normal student record for a new OAuth account."""
    email = (email or "").strip().lower()
    if not email:
        raise HTTPException(
            status_code=400,
            detail="The social account did not provide an email address."
        )

    user = get_user_by_email(db, email)
    if user:
        return user

    user = User(
        full_name=(name or "Student")[:100],
        email=email,
        # OAuth accounts do not use this password. A random hash keeps the
        # existing database schema compatible with normal login.
        password=hash_password(secrets.token_urlsafe(32)),
        role="student",
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


@router.post("/register", response_model=UserResponse, status_code=status.HTTP_201_CREATED)
def register(user: UserCreate, db: Session = Depends(get_db)):
    if get_user_by_email(db, user.email):
        raise HTTPException(status_code=400, detail="Email already registered")
    return create_user(db=db, user=user)


@router.post("/login")
def login(credentials: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == credentials.username).first()
    if not user or not verify_password(credentials.password, user.password):
        raise HTTPException(status_code=401, detail="Invalid email or password")
    if user.is_active is False:
        raise HTTPException(status_code=403, detail="Account is disabled")
    return _login_user(user)


@router.get("/me", response_model=UserResponse)
def get_me(current_user: User = Depends(get_current_user)):
    return current_user


@router.get("/google")
async def google_login(request: Request):
    if not GOOGLE_CLIENT_ID or not GOOGLE_CLIENT_SECRET:
        raise HTTPException(
            status_code=503,
            detail="Google Login is not configured. Add GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET to backend/.env."
        )
    redirect_uri = f"{BACKEND_URL}/auth/google/callback"
    return await oauth.google.authorize_redirect(request, redirect_uri)


@router.get("/google/callback")
async def google_callback(request: Request, db: Session = Depends(get_db)):
    try:
        token = await oauth.google.authorize_access_token(request)
        userinfo = token.get("userinfo")
        if not userinfo:
            userinfo = await oauth.google.userinfo(token=token)

        user = _get_or_create_social_user(
            db,
            userinfo.get("email"),
            userinfo.get("name") or userinfo.get("given_name") or "Student",
        )
        jwt_token = _login_user(user)["access_token"]
        return _frontend_callback(jwt_token, user)
    except Exception as exc:
        print(f"Google OAuth error: {exc}")
        return RedirectResponse(
            url=f"{FRONTEND_URL}/login.html?oauth_error=Google%20login%20failed",
            status_code=302,
        )


@router.get("/facebook")
async def facebook_login(request: Request):
    if not FACEBOOK_CLIENT_ID or not FACEBOOK_CLIENT_SECRET:
        raise HTTPException(
            status_code=503,
            detail="Facebook Login is not configured. Add FACEBOOK_CLIENT_ID and FACEBOOK_CLIENT_SECRET to backend/.env."
        )
    redirect_uri = f"{BACKEND_URL}/auth/facebook/callback"
    return await oauth.facebook.authorize_redirect(request, redirect_uri)


@router.get("/facebook/callback")
async def facebook_callback(request: Request, db: Session = Depends(get_db)):
    try:
        token = await oauth.facebook.authorize_access_token(request)
        response = await oauth.facebook.get(
            "me",
            token=token,
            params={"fields": "id,name,email"},
        )
        profile = response.json()

        user = _get_or_create_social_user(
            db,
            profile.get("email"),
            profile.get("name") or "Student",
        )
        jwt_token = _login_user(user)["access_token"]
        return _frontend_callback(jwt_token, user)
    except Exception as exc:
        print(f"Facebook OAuth error: {exc}")
        return RedirectResponse(
            url=f"{FRONTEND_URL}/login.html?oauth_error=Facebook%20login%20failed",
            status_code=302,
        )
