from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import Optional
from database import get_db
from oauth2 import get_current_user, get_current_admin
from models import User, GovernmentJob, JobBookmark
from schemas import GovernmentJobCreate, GovernmentJobResponse
from crud import get_all_government_jobs,get_government_job,create_government_job,add_job_bookmark,get_user_job_bookmarks,remove_job_bookmark
from ai.ai_service import AIService
router=APIRouter(prefix="/government-jobs",tags=["Government Jobs"])
@router.get("/my/bookmarks")
def my_bookmarks(db:Session=Depends(get_db),current_user:User=Depends(get_current_user)):
    result=[]
    for b in get_user_job_bookmarks(db,current_user.user_id):
        if b.job_type!="government": continue
        job=get_government_job(db,b.job_id)
        if job: result.append({"bookmark_id":b.id,"job":{"job_id":job.job_id,"title":job.title,"department":job.department,"organization":job.organization,"state":job.state,"location":job.location,"qualification":job.qualification,"last_date":str(job.last_date) if job.last_date else None,"apply_link":job.apply_link,"exam_type":job.exam_type}})
    return result
@router.get("/bookmark/status/{job_id}")
def bookmark_status(job_id:int,db:Session=Depends(get_db),current_user:User=Depends(get_current_user)):
    exists=db.query(JobBookmark).filter(JobBookmark.user_id==current_user.user_id,JobBookmark.job_id==job_id,JobBookmark.job_type=="government").first(); return {"bookmarked":bool(exists)}
@router.post("/bookmark")
def bookmark_job(payload:dict,db:Session=Depends(get_db),current_user:User=Depends(get_current_user)):
    job_id=payload.get("job_id")
    if not job_id: raise HTTPException(400,"job_id required")
    job=get_government_job(db,int(job_id))
    if not job or not job.is_active: raise HTTPException(404,"Government job not found")
    existing=db.query(JobBookmark).filter(JobBookmark.user_id==current_user.user_id,JobBookmark.job_id==int(job_id),JobBookmark.job_type=="government").first()
    if existing: db.delete(existing); db.commit(); return {"message":"Bookmark removed","bookmarked":False}
    bm=add_job_bookmark(db,current_user.user_id,int(job_id),"government"); return {"message":"Bookmarked","bookmark_id":bm.id,"bookmarked":True}
@router.delete("/bookmark/{job_id}")
def remove_bookmark(job_id:int,db:Session=Depends(get_db),current_user:User=Depends(get_current_user)):
    if not remove_job_bookmark(db,current_user.user_id,job_id,"government"): raise HTTPException(404,"Bookmark not found")
    return {"message":"Removed","bookmarked":False}
@router.post("/{job_id}/ai-analysis")
def analyze_job(job_id:int,db:Session=Depends(get_db),current_user:User=Depends(get_current_user)):
    job=get_government_job(db,job_id)
    if not job: raise HTTPException(404,"Job not found")
    skills=[]; qualification=""
    try:
        from crud import get_student_by_user,get_student_skills
        student=get_student_by_user(db,current_user.user_id)
        if student:
            qualification=student.degree or ""; skills=[x.skill.skill_name for x in get_student_skills(db,student.student_id) if getattr(x,"skill",None)]
    except Exception: pass
    data={"title":job.title,"organization":job.organization,"qualification":job.qualification,"age_limit":f"{job.age_limit_min}-{job.age_limit_max}","exam_type":job.exam_type,"exam_pattern":job.exam_pattern,"eligibility":job.eligibility,"description":job.description}
    return AIService().analyze_government_job(data,skills,[],qualification)
@router.get("/",response_model=list[GovernmentJobResponse])
def list_jobs(skip:int=0,limit:int=100,search:Optional[str]=None,state:Optional[str]=None,exam_type:Optional[str]=None,qualification:Optional[str]=None,db:Session=Depends(get_db),_:User=Depends(get_current_user)): return get_all_government_jobs(db,skip,limit,search,state,exam_type,qualification)
@router.get("/{job_id}",response_model=GovernmentJobResponse)
def get_job(job_id:int,db:Session=Depends(get_db),_:User=Depends(get_current_user)):
    job=get_government_job(db,job_id)
    if not job: raise HTTPException(404,"Job not found")
    return job
@router.post("/",response_model=GovernmentJobResponse,status_code=201)
def create_job(job:GovernmentJobCreate,db:Session=Depends(get_db),_:User=Depends(get_current_admin)): return create_government_job(db,job)
