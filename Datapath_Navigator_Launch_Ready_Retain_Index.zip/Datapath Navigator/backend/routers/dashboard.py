# routers/dashboard.py
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import func
from datetime import datetime, timedelta

from database import get_db
from oauth2 import get_current_user, get_current_admin
from models import (
    User, Student, Career, Skill, Course,
    CareerRecommendation, Assessment, StudentSkill,
    GovernmentJob, PrivateJob, JobBookmark, Notification
)
from crud import get_student_by_user, get_student_skills

router = APIRouter(prefix="/dashboard", tags=["Dashboard"])


def _profile_completion(student, skills_count, recommendations_count):
    fields = [
        student.age,
        student.degree,
        student.department,
        student.year_of_study,
        student.cgpa,
        skills_count > 0,
        recommendations_count > 0,
    ]
    return round(sum(bool(x) for x in fields) / len(fields) * 100)


@router.get("/student")
def student_dashboard(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    student = get_student_by_user(db, current_user.user_id)
    if not student:
        return {
            "error": "Create profile first",
            "student": {
                "name": current_user.full_name,
                "degree": None, "department": None,
                "year_of_study": None, "cgpa": None
            },
            "stats": {
                "total_skills": 0, "total_recommendations": 0,
                "assessments_taken": 0, "bookmarks": 0
            },
            "profile_completion": 14,
            "proficiency_distribution": {"Beginner": 0, "Intermediate": 0, "Advanced": 0},
            "latest_assessment": None,
            "top_career": None,
            "recommendations": [],
            "recent_jobs": [],
            "notifications": [],
            "job_counts": {"government": 0, "private": 0},
            "next_steps": [
                {"title": "Complete your profile", "text": "Add your education and skills.", "link": "profile.html", "icon": "user"},
                {"title": "Get career recommendations", "text": "Discover careers matching your profile.", "link": "ai-recommendations.html", "icon": "bullseye"}
            ]
        }

    skills = get_student_skills(db, student.student_id)
    prof_dist = {"Beginner": 0, "Intermediate": 0, "Advanced": 0}
    for s in skills:
        prof_dist[s.proficiency] = prof_dist.get(s.proficiency, 0) + 1

    recommendations_q = db.query(CareerRecommendation).filter(
        CareerRecommendation.student_id == student.student_id
    )
    recommendation_count = recommendations_q.count()

    latest = db.query(Assessment).filter(
        Assessment.student_id == student.student_id
    ).order_by(Assessment.assessment_date.desc()).first()

    top = recommendations_q.order_by(
        CareerRecommendation.match_percentage.desc()
    ).first()

    top_recs = recommendations_q.join(Career).order_by(
        CareerRecommendation.match_percentage.desc()
    ).limit(3).all()

    bookmark_count = db.query(JobBookmark).filter(
        JobBookmark.user_id == current_user.user_id
    ).count()

    gov_count = db.query(GovernmentJob).filter(
        GovernmentJob.is_active == True
    ).count()
    private_count = db.query(PrivateJob).filter(
        PrivateJob.is_active == True
    ).count()

    recent_jobs = []
    for job in db.query(GovernmentJob).filter(
        GovernmentJob.is_active == True
    ).order_by(GovernmentJob.posted_date.desc()).limit(4).all():
        recent_jobs.append({
            "id": job.job_id,
            "title": job.title,
            "organization": job.organization or job.department or "Government",
            "location": job.location or job.state or "India",
            "type": "government",
            "apply_link": job.apply_link
        })

    notifications = db.query(Notification).filter(
        Notification.user_id == current_user.user_id
    ).order_by(Notification.created_at.desc()).limit(4).all()

    completion = _profile_completion(
        student, len(skills), recommendation_count
    )

    next_steps = []
    if completion < 100:
        next_steps.append({
            "title": "Complete your profile",
            "text": f"Your profile is {completion}% complete.",
            "link": "profile.html", "icon": "user"
        })
    if recommendation_count == 0:
        next_steps.append({
            "title": "Get AI recommendations",
            "text": "Find career paths based on your skills.",
            "link": "ai-recommendations.html", "icon": "bullseye"
        })
    if not latest:
        next_steps.append({
            "title": "Take an assessment",
            "text": "Measure your aptitude and core skills.",
            "link": "aptitude-test.html", "icon": "clipboard-check"
        })
    if len(skills) > 0:
        next_steps.append({
            "title": "Check your skill gap",
            "text": "See what to learn for your target career.",
            "link": "skill-gap.html", "icon": "chart-line"
        })
    next_steps = next_steps[:3]

    return {
        "student": {
            "name": current_user.full_name,
            "degree": student.degree,
            "department": student.department,
            "year_of_study": student.year_of_study,
            "cgpa": float(student.cgpa) if student.cgpa else None
        },
        "stats": {
            "total_skills": len(skills),
            "total_recommendations": recommendation_count,
            "assessments_taken": db.query(Assessment).filter(
                Assessment.student_id == student.student_id
            ).count(),
            "bookmarks": bookmark_count
        },
        "profile_completion": completion,
        "proficiency_distribution": prof_dist,
        "latest_assessment": {
            "aptitude": float(latest.aptitude_score),
            "logical": float(latest.logical_score),
            "communication": float(latest.communication_score),
            "programming": float(latest.programming_score),
            "date": str(latest.assessment_date) if latest.assessment_date else None
        } if latest else None,
        "top_career": {
            "name": top.career.career_name,
            "match": float(top.match_percentage)
        } if top else None,
        "recommendations": [
            {
                "name": r.career.career_name,
                "match": float(r.match_percentage)
            } for r in top_recs
        ],
        "job_counts": {"government": gov_count, "private": private_count},
        "recent_jobs": recent_jobs,
        "notifications": [
            {
                "title": n.title,
                "message": n.message,
                "type": n.type,
                "is_read": n.is_read,
                "created_at": str(n.created_at) if n.created_at else None
            } for n in notifications
        ],
        "next_steps": next_steps
    }


@router.get("/admin")
def admin_dashboard(
    db: Session = Depends(get_db),
    _: User = Depends(get_current_admin)
):
    week_ago = datetime.utcnow() - timedelta(days=7)

    top_skills = db.query(
        Skill.skill_name, func.count(StudentSkill.student_skill_id).label('c')
    ).join(StudentSkill, Skill.skill_id == StudentSkill.skill_id
    ).group_by(Skill.skill_id).order_by(func.count(StudentSkill.student_skill_id).desc()).limit(10).all()

    top_careers = db.query(
        Career.career_name, func.count(CareerRecommendation.recommendation_id).label('c')
    ).join(CareerRecommendation, Career.career_id == CareerRecommendation.career_id
    ).group_by(Career.career_id).order_by(func.count(CareerRecommendation.recommendation_id).desc()).limit(10).all()

    avg = db.query(
        func.avg(Assessment.aptitude_score),
        func.avg(Assessment.logical_score),
        func.avg(Assessment.communication_score),
        func.avg(Assessment.programming_score)
    ).first()

    return {
        "overview": {
            "total_users": db.query(User).count(),
            "total_students": db.query(Student).count(),
            "total_careers": db.query(Career).count(),
            "total_skills": db.query(Skill).count(),
            "total_courses": db.query(Course).count(),
            "total_assessments": db.query(Assessment).count(),
            "total_recommendations": db.query(CareerRecommendation).count(),
            "recent_signups_7d": db.query(User).filter(User.created_at >= week_ago).count()
        },
        "top_skills": [{"name": s[0], "count": s[1]} for s in top_skills],
        "top_careers": [{"name": c[0], "recommendations": c[1]} for c in top_careers],
        "average_assessment_scores": {
            "aptitude": round(float(avg[0] or 0), 2),
            "logical": round(float(avg[1] or 0), 2),
            "communication": round(float(avg[2] or 0), 2),
            "programming": round(float(avg[3] or 0), 2)
        }
    }
