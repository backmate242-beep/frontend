# routers/student.py
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from database import get_db
from oauth2 import get_current_user
from models import User, Skill
from schemas import (
    StudentCreate, StudentResponse, StudentSkillResponse,
    StudentSkillCreate, CustomStudentSkillCreate
)
from crud import (
    get_student, get_student_by_user, get_all_students,
    create_student, update_student, get_student_skills,
    add_student_skill, remove_student_skill, get_skill_by_name, create_skill
)
from schemas import StudentUpdate

router = APIRouter(prefix="/students", tags=["Students"])


@router.post("/", response_model=StudentResponse, status_code=status.HTTP_201_CREATED)
def create_profile(
    student: StudentCreate, db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    if get_student_by_user(db, current_user.user_id):
        raise HTTPException(status_code=400, detail="Profile already exists")
    return create_student(db=db, student=student)


@router.get("/me", response_model=StudentResponse)
def get_my_profile(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    student = get_student_by_user(db, current_user.user_id)
    if not student:
        raise HTTPException(status_code=404, detail="Student profile not found")
    return student


@router.get("/{student_id}", response_model=StudentResponse)
def get_by_id(
    student_id: int, db: Session = Depends(get_db),
    _: User = Depends(get_current_user)
):
    student = get_student(db, student_id)
    if not student:
        raise HTTPException(status_code=404, detail="Not found")
    return student


@router.put("/me", response_model=StudentResponse)
def update_my_profile(
    student: StudentUpdate, db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    s = get_student_by_user(db, current_user.user_id)
    if not s:
        raise HTTPException(status_code=404, detail="Profile not found")
    return update_student(db, s.student_id, student)


@router.get("/", response_model=list[StudentResponse])
def list_students(
    skip: int = 0, limit: int = 50, db: Session = Depends(get_db),
    _: User = Depends(get_current_user)
):
    return get_all_students(db, skip, limit)


# ===== Student Skills =====

@router.post("/me/skills", response_model=StudentSkillResponse, status_code=status.HTTP_201_CREATED)
def add_skill(
    payload: StudentSkillCreate, db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    student = get_student_by_user(db, current_user.user_id)
    if not student:
        raise HTTPException(status_code=404, detail="Create profile first")
    return add_student_skill(db, student.student_id, payload.skill_id, payload.proficiency)




@router.post("/me/skills/custom", response_model=StudentSkillResponse, status_code=status.HTTP_201_CREATED)
def add_custom_skill(
    payload: CustomStudentSkillCreate, db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Create a missing skill in the shared skills list and add it to the current student."""
    student = get_student_by_user(db, current_user.user_id)
    if not student:
        raise HTTPException(status_code=404, detail="Create profile first")

    skill_name = " ".join(payload.skill_name.strip().split())
    if not skill_name:
        raise HTTPException(status_code=400, detail="Skill name cannot be empty")
    if len(skill_name) > 100:
        raise HTTPException(status_code=400, detail="Skill name must be 100 characters or less")

    # Match existing skills case-insensitively so duplicates like "Python"/"python" are avoided.
    from sqlalchemy import func
    skill = db.query(Skill).filter(func.lower(Skill.skill_name) == skill_name.lower()).first()
    if not skill:
        skill = Skill(skill_name=skill_name)
        db.add(skill)
        db.commit()
        db.refresh(skill)

    return add_student_skill(db, student.student_id, skill.skill_id, payload.proficiency)

@router.get("/me/skills", response_model=list[StudentSkillResponse])
def get_my_skills(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    student = get_student_by_user(db, current_user.user_id)
    if not student:
        raise HTTPException(status_code=404, detail="Profile not found")
    return get_student_skills(db, student.student_id)


@router.delete("/me/skills/{student_skill_id}", status_code=status.HTTP_204_NO_CONTENT)
def remove_skill(
    student_skill_id: int, db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    if not remove_student_skill(db, student_skill_id):
        raise HTTPException(status_code=404, detail="Not found")
    return None
