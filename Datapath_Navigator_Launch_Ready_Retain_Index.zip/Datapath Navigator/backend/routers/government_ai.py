from fastapi import APIRouter,Depends
from pydantic import BaseModel,Field
from typing import List
from sqlalchemy.orm import Session
from database import get_db
from oauth2 import get_current_user
from models import User
from ai.ai_service import AIService
router=APIRouter(prefix="/government-ai",tags=["Government AI"])
class ResourceRequest(BaseModel):
    exam_name:str=Field(...,min_length=2)
    exam_type:str="General"
    job_role:str=""
    skills:List[str]=[]
    interests:List[str]=[]
    qualification:str=""
@router.post("/resources")
def resources(req:ResourceRequest,current_user:User=Depends(get_current_user),db:Session=Depends(get_db)):
    skills=req.skills[:30]; qualification=req.qualification
    try:
        from crud import get_student_by_user,get_student_skills
        student=get_student_by_user(db,current_user.user_id)
        if student:
            qualification=qualification or student.degree or ""
            if not skills: skills=[x.skill.skill_name for x in get_student_skills(db,student.student_id) if getattr(x,"skill",None)]
    except Exception: pass
    return AIService().analyze_government_exam_resources(req.exam_name,req.exam_type,skills,req.interests,qualification,req.job_role)
