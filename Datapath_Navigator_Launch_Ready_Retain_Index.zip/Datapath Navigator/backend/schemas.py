# schemas.py
from pydantic import BaseModel, EmailStr, ConfigDict
from decimal import Decimal
from typing import Optional, List
from datetime import datetime


# Reusable config (DRY principle)
ORM_CONFIG = ConfigDict(from_attributes=True)


# ===== User Schemas =====

class UserBase(BaseModel):
    full_name: str
    email: EmailStr
    role: str = "student"


class UserCreate(UserBase):
    password: str


class UserResponse(UserBase):
    user_id: int
    created_at: datetime
    model_config = ORM_CONFIG  # ← Fixed


# ===== Student Schemas =====

class StudentBase(BaseModel):
    age: Optional[int] = None
    gender: Optional[str] = None
    degree: Optional[str] = None
    department: Optional[str] = None
    year_of_study: Optional[int] = None
    cgpa: Optional[Decimal] = None


class StudentCreate(StudentBase):
    user_id: int


class StudentUpdate(BaseModel):
    age: Optional[int] = None
    gender: Optional[str] = None
    degree: Optional[str] = None
    department: Optional[str] = None
    year_of_study: Optional[int] = None
    cgpa: Optional[Decimal] = None


class StudentResponse(StudentBase):
    student_id: int
    user_id: int
    model_config = ORM_CONFIG  # ← Fixed


# ===== Skill Schemas =====

class SkillBase(BaseModel):
    skill_name: str


class SkillCreate(SkillBase):
    pass


class SkillResponse(SkillBase):
    skill_id: int
    model_config = ORM_CONFIG  # ← Fixed


# ===== Student Skill Schemas =====

class StudentSkillBase(BaseModel):
    student_id: int
    skill_id: int
    proficiency: str


class StudentSkillCreate(BaseModel):
    skill_id: int
    proficiency: str

class CustomStudentSkillCreate(BaseModel):
    skill_name: str
    proficiency: str = "Intermediate"


class StudentSkillResponse(BaseModel):
    student_skill_id: int
    student_id: int
    skill_id: int
    proficiency: str
    model_config = ORM_CONFIG  # ← Fixed


# ===== Career Schemas =====

class CareerBase(BaseModel):
    career_name: str
    description: Optional[str] = None
    average_salary: Optional[Decimal] = None
    required_degree: Optional[str] = None


class CareerCreate(CareerBase):
    pass


class CareerUpdate(BaseModel):
    career_name: Optional[str] = None
    description: Optional[str] = None
    average_salary: Optional[Decimal] = None
    required_degree: Optional[str] = None


class CareerResponse(CareerBase):
    career_id: int
    model_config = ORM_CONFIG  # ← Fixed


# ===== Career Skill Schemas =====

class CareerSkillBase(BaseModel):
    career_id: int
    skill_id: int
    importance_level: str


class CareerSkillCreate(BaseModel):
    skill_id: int
    importance_level: str


class CareerSkillResponse(BaseModel):
    career_skill_id: int
    career_id: int
    skill_id: int
    importance_level: str
    model_config = ORM_CONFIG  # ← Fixed


# ===== Career Recommendation Schemas =====

class CareerRecommendationBase(BaseModel):
    student_id: int
    career_id: int
    match_percentage: Decimal


class CareerRecommendationCreate(CareerRecommendationBase):
    pass


class CareerRecommendationResponse(BaseModel):
    recommendation_id: int
    student_id: int
    career_id: int
    match_percentage: Decimal
    recommendation_date: datetime
    model_config = ORM_CONFIG  # ← Fixed


class AIRecommendationItem(BaseModel):
    career_id: int
    career_name: str
    description: Optional[str] = None
    average_salary: Optional[float] = None
    match_percentage: float
    weighted_score: float
    cosine_score: float
    jaccard_score: float
    missing_skills: list
    matched_skills_count: int
    required_skills_count: int
    ai_explanation: str


# ===== Course Schemas =====

class CourseBase(BaseModel):
    course_name: str
    platform: str
    course_link: str
    skill_id: int


class CourseCreate(CourseBase):
    pass


class CourseResponse(CourseBase):
    course_id: int
    model_config = ORM_CONFIG  # ← Fixed


# ===== Roadmap Schemas =====

class RoadmapBase(BaseModel):
    career_id: int
    roadmap_title: str
    roadmap_description: str


class RoadmapCreate(RoadmapBase):
    pass


class RoadmapResponse(RoadmapBase):
    roadmap_id: int
    model_config = ORM_CONFIG  # ← Fixed


# ===== Assessment Schemas =====

class AssessmentBase(BaseModel):
    student_id: int
    aptitude_score: Decimal
    logical_score: Decimal
    communication_score: Decimal
    programming_score: Decimal


class AssessmentCreate(BaseModel):
    aptitude_score: Decimal
    logical_score: Decimal
    communication_score: Decimal
    programming_score: Decimal


class AssessmentResponse(AssessmentBase):
    assessment_id: int
    assessment_date: datetime
    model_config = ORM_CONFIG  # ← Fixed


# ===== AI Schemas =====

class ChatMessage(BaseModel):
    message: str
    history: Optional[List[dict]] = None


class ChatResponse(BaseModel):
    response: str
    powered_by: str
    intent: Optional[str] = None
    model: Optional[str] = None


class SkillGapRequest(BaseModel):
    career_id: int


class RoadmapRequest(BaseModel):
    career_name: str
    current_skills: List[str] = []
    education: str = "Bachelor's"
    hours_per_day: int = 2


class InterviewRequest(BaseModel):
    career_name: str
    num_questions: int = 10


class ResumeAnalysisRequest(BaseModel):
    resume_text: str
    target_career: str


class CourseRecommendationRequest(BaseModel):
    skill_name: str
    current_level: str = "Beginner"
    hours_per_week: int = 5
    budget: str = "Free"


class QuizSubmission(BaseModel):
    answers: List[dict]


# ===== Notification Schemas =====

class NotificationCreate(BaseModel):
    user_id: int
    title: str
    message: str
    type: str = "info"


class NotificationResponse(BaseModel):
    notification_id: int
    title: str
    message: str
    type: str
    is_read: bool
    created_at: datetime
    model_config = ORM_CONFIG  # ← Fixed


# ===== Bookmark Schemas =====

class BookmarkCreate(BaseModel):
    career_id: int


# ===== Login Response (NEW with sector) =====

class LoginResponse(BaseModel):
    access_token: str
    token_type: str
    user_id: int
    role: str
    sector: str


# ===== Government Job Schemas (NEW) =====

class GovernmentJobBase(BaseModel):
    title: str
    department: Optional[str] = None
    organization: Optional[str] = None
    qualification: Optional[str] = None
    age_limit_min: Optional[int] = None
    age_limit_max: Optional[int] = None
    salary_range: Optional[str] = None
    location: Optional[str] = None
    state: Optional[str] = None
    exam_type: Optional[str] = None
    vacancies: Optional[int] = None
    apply_link: Optional[str] = None
    description: Optional[str] = None
    eligibility: Optional[str] = None
    exam_pattern: Optional[str] = None
    syllabus_link: Optional[str] = None
    last_date: Optional[datetime] = None


class GovernmentJobCreate(GovernmentJobBase):
    pass


class GovernmentJobResponse(GovernmentJobBase):
    job_id: int
    posted_date: datetime
    model_config = ORM_CONFIG  # ← Fixed


# ===== Private Job Schemas (NEW) =====

class PrivateJobBase(BaseModel):
    title: str
    company: Optional[str] = None
    industry: Optional[str] = None
    skills_required: Optional[str] = None
    experience_min: Optional[int] = None
    experience_max: Optional[int] = None
    salary_min: Optional[float] = None
    salary_max: Optional[float] = None
    location: Optional[str] = None
    job_type: Optional[str] = None
    apply_link: Optional[str] = None
    description: Optional[str] = None
    company_logo: Optional[str] = None
    last_date: Optional[datetime] = None


class PrivateJobCreate(PrivateJobBase):
    pass


class PrivateJobResponse(PrivateJobBase):
    job_id: int
    posted_date: datetime
    model_config = ORM_CONFIG  # ← Fixed


class JobBookmarkCreate(BaseModel):
    job_id: int
    job_type: str
