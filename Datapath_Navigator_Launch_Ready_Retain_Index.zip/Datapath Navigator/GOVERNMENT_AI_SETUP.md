# Government Portal AI Features

## New AI capabilities
- Government job AI match analysis
- Government exam/job-role resource planning
- Personalized skill-gap analysis
- AI-generated government aptitude questions
- Aptitude filters: exam, category, topic and difficulty
- YouTube learning searches generated from the AI resource plan
- Modern government portal styling and login styling

## Groq model mapping
- Government job analysis: `openai/gpt-oss-120b`
- Government exam resources: `openai/gpt-oss-20b`
- Government aptitude questions: `openai/gpt-oss-20b`
- General career/chat/reasoning: existing configured models

## Run
1. Copy `backend/.env.example` to `backend/.env`.
2. Set your own `GROQ_API_KEY` and MySQL settings.
3. Install dependencies:
   `pip install -r backend/requirements.txt`
4. Start FastAPI from the `backend` directory.
5. Open the frontend through your existing local web server.

The generated YouTube links are search links based on AI-selected topics; they do not claim that a particular video is officially endorsed.
