(function(){
  const KEY='datapath-theme';
  function getInitial(){
    const saved=localStorage.getItem(KEY);
    if(saved==='light'||saved==='dark') return saved;
    return window.matchMedia && window.matchMedia('(prefers-color-scheme: light)').matches ? 'light':'dark';
  }
  function setTheme(theme, persist=true){
    document.documentElement.dataset.theme=theme;
    document.body && (document.body.dataset.theme=theme);
    if(persist) localStorage.setItem(KEY,theme);
    document.querySelectorAll('[data-theme-toggle]').forEach(btn=>{
      btn.setAttribute('aria-pressed',theme==='dark');
      btn.setAttribute('title',theme==='dark'?'Switch to light mode':'Switch to dark mode');
      btn.innerHTML=theme==='dark' ? '<i class="fas fa-sun" aria-hidden="true"></i><span class="theme-toggle-label">Light</span>' : '<i class="fas fa-moon" aria-hidden="true"></i><span class="theme-toggle-label">Dark</span>';
    });
    document.querySelectorAll('[data-theme-logo]').forEach(img=>{
      const next=theme==='dark'?img.dataset.darkLogo:img.dataset.lightLogo;
      if(next) img.src=next;
    });
    window.dispatchEvent(new CustomEvent('datapath:themechange',{detail:{theme}}));
  }
  document.documentElement.dataset.theme=getInitial();
  window.DataPathTheme={set:setTheme,toggle:function(){setTheme(document.documentElement.dataset.theme==='dark'?'light':'dark')}};
  document.addEventListener('click',e=>{
    const btn=e.target.closest('[data-theme-toggle]');
    if(btn){e.preventDefault();window.DataPathTheme.toggle();}
  });
  function refreshThemeAssets(){
    const theme=document.documentElement.dataset.theme || 'light';
    document.querySelectorAll('[data-theme-logo]').forEach(img=>{
      const next=theme==='dark'?img.dataset.darkLogo:img.dataset.lightLogo;
      if(next && img.getAttribute('src')!==next) img.setAttribute('src',next);
    });
  }

  document.addEventListener('DOMContentLoaded',()=>{
    setTheme(document.documentElement.dataset.theme,false);
    if(!document.querySelector('[data-theme-toggle]') && !document.querySelector('.lux-landing')){
      const b=document.createElement('button'); b.className='theme-toggle global-theme-toggle'; b.setAttribute('data-theme-toggle',''); b.setAttribute('aria-label','Toggle theme'); document.body.appendChild(b); setTheme(document.documentElement.dataset.theme,false);
    }
    refreshThemeAssets();
  });

  if(window.MutationObserver){
    const observer=new MutationObserver(()=>refreshThemeAssets());
    observer.observe(document.documentElement,{childList:true,subtree:true});
  }
})();
