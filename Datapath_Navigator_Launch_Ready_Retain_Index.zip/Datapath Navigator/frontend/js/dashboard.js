// Interactive student dashboard
(function () {
    if (!requireAuth()) return;

    const esc = (value) => String(value ?? "")
        .replace(/&/g, "&amp;").replace(/</g, "&lt;")
        .replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");

    const setText = (id, value) => {
        const el = document.getElementById(id);
        if (el) el.textContent = value;
    };

    const animateNumber = (id, target) => {
        const el = document.getElementById(id);
        if (!el) return;
        const end = Number(target) || 0;
        const start = 0;
        const duration = 550;
        const started = performance.now();
        function tick(now) {
            const p = Math.min((now - started) / duration, 1);
            const eased = 1 - Math.pow(1 - p, 3);
            el.textContent = Math.round(start + (end - start) * eased);
            if (p < 1) requestAnimationFrame(tick);
        }
        requestAnimationFrame(tick);
    };

    function renderProfile(data) {
        const percent = Math.max(0, Math.min(100, Number(data.profile_completion || 0)));
        setText("profilePercent", `${percent}%`);
        const ring = document.getElementById("profileRing");
        if (ring) {
            ring.style.background = `conic-gradient(var(--accent-yellow) ${percent * 3.6}deg, rgba(148,163,184,.14) ${percent * 3.6}deg)`;
        }

        let status = "Let's get started";
        if (percent >= 100) status = "Profile complete 🎉";
        else if (percent >= 75) status = "Almost there!";
        else if (percent >= 45) status = "Good progress!";
        setText("profileStatus", status);

        const msg = percent >= 100
            ? "Your profile is ready for more accurate career matching."
            : `Complete the remaining profile details to improve your AI match accuracy.`;
        setText("profileMessage", msg);
    }

    function renderTopCareer(career) {
        const el = document.getElementById("topCareer");
        if (!el) return;
        if (!career) {
            el.className = "top-match-empty";
            el.innerHTML = `<i class="fas fa-compass"></i><p>Run AI recommendations to discover your best career match.</p><a href="ai-recommendations.html" class="mini-action">Get recommendations</a>`;
            return;
        }
        const match = Math.max(0, Math.min(100, Number(career.match || 0)));
        el.className = "match-main";
        el.innerHTML = `
            <span class="section-kicker">AI MATCH</span>
            <h3>${esc(career.name)}</h3>
            <div class="match-bar"><i style="width:${match}%"></i></div>
            <div class="match-score">Compatibility <strong>${match}%</strong></div>
        `;
    }

    function renderSkills(dist) {
        const values = [
            ["Beginner", "beginnerCount", "beginnerBar"],
            ["Intermediate", "intermediateCount", "intermediateBar"],
            ["Advanced", "advancedCount", "advancedBar"]
        ];
        const total = Object.values(dist || {}).reduce((a, b) => a + Number(b || 0), 0);
        values.forEach(([name, countId, barId]) => {
            const count = Number((dist || {})[name] || 0);
            setText(countId, count);
            const bar = document.getElementById(barId);
            if (bar) bar.style.width = `${total ? count / total * 100 : 0}%`;
        });
    }

    function renderAssessment(a) {
        const panel = document.getElementById("assessmentPanel");
        if (!panel) return;
        if (!a) {
            panel.innerHTML = `<div class="assessment-empty"><i class="fas fa-clipboard-check"></i><p>No assessment yet. Take a test to see your performance.</p></div>`;
            setText("assessmentHint", "Take your first test");
            return;
        }
        const scores = [
            ["Aptitude", a.aptitude], ["Logical", a.logical],
            ["Communication", a.communication], ["Programming", a.programming]
        ];
        panel.innerHTML = scores.map(([name, score]) => `
            <div class="score-box"><strong>${Number(score || 0).toFixed(0)}%</strong><span>${name}</span></div>
        `).join("");
        setText("assessmentHint", "Latest scores");
    }

    function renderSteps(steps) {
        const el = document.getElementById("nextSteps");
        if (!el) return;
        if (!steps?.length) {
            el.innerHTML = `<div class="step-card"><div class="step-icon"><i class="fas fa-check"></i></div><div><h3>You're on track!</h3><p>Explore new jobs and keep building your skills.</p></div></div>`;
            return;
        }
        el.innerHTML = steps.map(s => `
            <a class="step-card" href="${esc(s.link)}">
                <div class="step-icon"><i class="fas fa-${esc(s.icon || "arrow-right")}"></i></div>
                <div><h3>${esc(s.title)}</h3><p>${esc(s.text)}</p></div>
            </a>
        `).join("");
    }

    function renderJobs(data) {
        setText("govJobCount", data.job_counts?.government || 0);
        setText("savedJobCount", data.stats?.bookmarks || 0);

        const el = document.getElementById("recentJobs");
        if (!el) return;
        if (!data.recent_jobs?.length) {
            el.innerHTML = `<div class="assessment-empty">No government jobs available right now.</div>`;
            return;
        }
        el.innerHTML = data.recent_jobs.map(job => `
            <div class="job-line">
                <div><strong>${esc(job.title)}</strong><span>${esc(job.organization)} · ${esc(job.location)}</span></div>
                ${job.apply_link ? `<a href="${esc(job.apply_link)}" target="_blank" rel="noopener">View</a>` : ""}
            </div>
        `).join("");
    }

    function renderRecommendations(items) {
        const el = document.getElementById("recommendationList");
        if (!el) return;
        if (!items?.length) {
            el.innerHTML = `<div class="assessment-empty"><i class="fas fa-bullseye"></i><p>Your AI career matches will appear here.</p><a href="ai-recommendations.html" class="mini-action">Find careers</a></div>`;
            return;
        }
        el.innerHTML = items.map(item => `
            <div class="rec-line">
                <div><strong>${esc(item.name)}</strong><small>Recommended career path</small></div>
                <span class="rec-percent">${Number(item.match || 0).toFixed(0)}%</span>
            </div>
        `).join("");
    }

    async function loadDashboard() {
        try {
            const userInfo = await api.get("/users/me");
            setText("userName", userInfo.full_name || "Student");

            const data = await api.get("/dashboard/student");
            animateNumber("statSkills", data.stats?.total_skills);
            animateNumber("statRecs", data.stats?.total_recommendations);
            animateNumber("statAssessments", data.stats?.assessments_taken);
            animateNumber("statBookmarks", data.stats?.bookmarks);

            renderProfile(data);
            renderTopCareer(data.top_career);
            renderSkills(data.proficiency_distribution);
            renderAssessment(data.latest_assessment);
            renderSteps(data.next_steps);
            renderJobs(data);
            renderRecommendations(data.recommendations);
        } catch (err) {
            console.error("Dashboard loading error:", err);
            const el = document.getElementById("topCareer");
            if (el) el.innerHTML = `<div class="assessment-empty"><i class="fas fa-triangle-exclamation"></i><p>Unable to load dashboard data. Please refresh.</p></div>`;
        }
    }

    loadDashboard();
})();
