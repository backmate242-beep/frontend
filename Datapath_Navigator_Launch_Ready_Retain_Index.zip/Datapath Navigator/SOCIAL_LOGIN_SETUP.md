# DataPath Navigator - Social Login Setup

The project now includes Google and Facebook OAuth buttons on both Login and Register.

## 1. Install backend packages

From the `backend` folder:

```bash
pip install -r requirements.txt
```

The OAuth dependencies are `authlib` and `itsdangerous` (Starlette SessionMiddleware requires `itsdangerous`).

## 2. Install / repair dependencies

If you already installed the project, run:

```bash
pip install itsdangerous authlib
```

Then verify:

```bash
pip show itsdangerous
pip show authlib
```

## 3. Start the backend

```bash
uvicorn main:app --reload
```

Default backend:
`http://localhost:8000`

## 4. Serve the frontend over HTTP

Do not open the HTML files directly with `file://`.

For VS Code, Live Server can serve the `frontend` folder, normally at:

`http://127.0.0.1:5500`

If your frontend uses another port, change `FRONTEND_URL` in `backend/.env`.

## 5. Google Login

Create a Google OAuth Web Application and add this Authorized Redirect URI:

`http://localhost:8000/auth/google/callback`

Put the credentials in `backend/.env`:

```env
GOOGLE_CLIENT_ID=your_google_client_id
GOOGLE_CLIENT_SECRET=your_google_client_secret
```

## 6. Facebook Login

Create a Facebook Login/Web application and add this Valid OAuth Redirect URI:

`http://localhost:8000/auth/facebook/callback`

Put the credentials in `backend/.env`:

```env
FACEBOOK_CLIENT_ID=your_facebook_app_id
FACEBOOK_CLIENT_SECRET=your_facebook_app_secret
```

The Facebook app must request `email` and `public_profile`.

## 7. Frontend/backend URLs

```env
FRONTEND_URL=http://127.0.0.1:5500
BACKEND_URL=http://localhost:8000
```

If your browser opens the frontend as `http://localhost:5500`, you can use that exact origin instead.

## 8. OAuth flow

Login/Register -> Google/Facebook -> Provider consent -> FastAPI callback -> JWT created -> frontend callback -> preferences page.

For a new social account, DataPath Navigator creates a normal student user automatically. The existing MySQL schema is reused; no new OAuth database table is required.

## Dashboard improvements

The student dashboard now loads live API data for:
- Profile completion
- Skills and proficiency
- AI career matches
- Assessment scores
- Saved jobs
- Government job count
- Recent government jobs
- Smart next steps

Normal email/password login remains unchanged.
