let QUESTIONS = [];
let currentQ = 0;
let userAnswers = [];
let timerInterval;
let startTime;
let sessionToken = null;
let selectedExamType = null;
let timeLimit = 1800;
let previousQuestionsText = [];

const STORAGE_KEY = "govt_aptitude_history";

document.addEventListener("DOMContentLoaded", async () => {
    if (!requireAuth()) return;
    try {
        previousQuestionsText = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
    } catch (e) { previousQuestionsText = []; }
    await loadExamTypes();
});

async function loadExamTypes() {
    try {
        const data = await api.get("/govt-aptitude/exam-types");
        const container = document.getElementById("examSelector");
        container.innerHTML = data.exam_types.map(exam => `
            <div class="exam-card" data-code="${exam.code}" onclick="selectExam('${exam.code}')">
                <div class="icon">${exam.icon}</div>
                <div class="code">${exam.code}</div>
                <div class="name">${exam.name}</div>
                <span class="badge badge-yellow">${exam.difficulty}</span>
            </div>
        `).join("");
    } catch (err) {
        showToast("Failed to load exam types", "error");
    }
}

function selectExam(code) {
    selectedExamType = code;
    document.querySelectorAll(".exam-card").forEach(c => {
        c.classList.toggle("selected", c.dataset.code === code);
    });
    document.getElementById("startBtn").disabled = false;
}

async function startTest() {
    if (!selectedExamType) {
        showToast("Please select an exam first", "warning");
        return;
    }

    const numQuestions = parseInt(document.getElementById("numQuestions").value);
    timeLimit = parseInt(document.getElementById("timeLimit").value);

    document.getElementById("examSelectionScreen").style.display = "none";
    document.getElementById("loadingState").style.display = "block";
    document.getElementById("loadingExam").textContent = selectedExamType;

    try {
        const data = await api.post("/govt-aptitude/generate", {
            exam_type: selectedExamType,
            num_questions: numQuestions,
            previous_questions: previousQuestionsText.slice(-100)
        });

        QUESTIONS = data.questions;
        sessionToken = data.session_token;
        userAnswers = new Array(QUESTIONS.length).fill(null);
        currentQ = 0;

        document.getElementById("loadingState").style.display = "none";
        document.getElementById("testUI").style.display = "block";
        document.getElementById("examLabel").textContent = `EXAM: ${data.exam_name}`;
        document.getElementById("poweredLabel").textContent = `⚡ ${data.powered_by}`;
        document.getElementById("qTotal").textContent = QUESTIONS.length;
        document.getElementById("totalQuestions").textContent = QUESTIONS.length;

        renderNavGrid();
        renderQuestion();
        startTimer();
        startTime = Date.now();
        updateProgress();
        showToast(`Generated ${QUESTIONS.length} questions for ${data.exam_name}! 🎉`, "success");
    } catch (err) {
        document.getElementById("loadingState").style.display = "none";
        document.getElementById("examSelectionScreen").style.display = "block";
        showToast(err.message || "Failed to generate questions", "error");
    }
}

function renderNavGrid() {
    const grid = document.getElementById("navGrid");
    grid.style.gridTemplateColumns = `repeat(${Math.min(QUESTIONS.length, 20)}, 1fr)`;
    grid.innerHTML = QUESTIONS.map((_, i) => `
        <button class="nav-btn ${userAnswers[i] !== null ? 'answered' : ''} ${i === currentQ ? 'current' : ''}"
            onclick="goToQ(${i})">${i + 1}</button>
    `).join("");
}

function renderQuestion() {
    const q = QUESTIONS[currentQ];
    if (!q) return;

    document.getElementById("qNum").textContent = currentQ + 1;
    document.getElementById("questionText").textContent = q.question;
    document.getElementById("questionMeta").innerHTML = `
        <span class="badge" style="font-size: 0.7rem;">${q.category || "General"}</span>
        ${q.topic ? `<span class="badge" style="font-size: 0.7rem;">${q.topic}</span>` : ''}
        <span class="badge badge-yellow" style="font-size: 0.7rem;">${q.difficulty || "Medium"}</span>
    `;
    document.getElementById("optionsContainer").innerHTML = q.options.map((opt, i) => `
        <label class="option">
            <input type="radio" name="opt" value="${i}" ${userAnswers[currentQ] === i ? 'checked' : ''}
                onchange="selectAnswer(${i})">
            <span><strong>${String.fromCharCode(65 + i)})</strong> ${opt}</span>
        </label>
    `).join("");
}

function selectAnswer(idx) {
    if (currentQ >= 0 && currentQ < userAnswers.length) {
        userAnswers[currentQ] = idx;
        renderNavGrid();
        updateProgress();
    }
}

function goToQ(idx) {
    if (idx >= 0 && idx < QUESTIONS.length) {
        currentQ = idx;
        renderQuestion();
        renderNavGrid();
    }
}

function prevQ() { if (currentQ > 0) goToQ(currentQ - 1); }

function saveNext() {
    if (currentQ < QUESTIONS.length - 1) goToQ(currentQ + 1);
    else showToast("Last question! Click SUBMIT TEST below.", "info");
}

function startTimer() {
    let timeLeft = timeLimit;
    timerInterval = setInterval(() => {
        timeLeft--;
        const m = Math.floor(timeLeft / 60);
        const s = timeLeft % 60;
        document.getElementById("timer").textContent = `${m}:${s.toString().padStart(2, '0')}`;
        if (timeLeft <= 0) {
            clearInterval(timerInterval);
            submitTest();
        }
    }, 1000);
}

function updateProgress() {
    const answered = userAnswers.filter(a => a !== null).length;
    document.getElementById("answeredCount").textContent = answered;
}

async function submitTest() {
    if (!sessionToken) return;
    const unanswered = QUESTIONS.length - userAnswers.filter(a => a !== null).length;

    if (unanswered > 0) {
        if (!confirm(`${unanswered} questions unanswered. Submit anyway?`)) return;
    } else {
        if (!confirm("Submit your test?")) return;
    }

    clearInterval(timerInterval);
    const submitBtn = document.getElementById("submitBtn");
    submitBtn.disabled = true;
    submitBtn.innerHTML = "⏳ Submitting...";

    const timeTaken = Math.floor((Date.now() - startTime) / 1000);

    document.getElementById("testUI").style.display = "none";
    document.getElementById("resultScreen").style.display = "block";
    document.getElementById("scoreValue").textContent = "...";

    try {
        const result = await api.post("/govt-aptitude/submit", {
            session_token: sessionToken,
            user_answers: userAnswers,
            time_taken_seconds: timeTaken
        });

        saveToHistory(QUESTIONS.map(q => q.question));
        showResult(result);
    } catch (err) {
        showToast(err.message || "Failed to submit", "error");
        submitBtn.disabled = false;
        submitBtn.innerHTML = "✅ Submit Test";
    }
}

function showResult(result) {
    const pct = result.overall_score || 0;
    document.getElementById("scoreValue").textContent = pct + "%";
    document.getElementById("scoreCircle").style.setProperty("--pct", pct + "%");
    document.getElementById("performanceMessage").textContent = result.performance_message;
    document.getElementById("scoreDetails").textContent =
        `${result.correct}/${result.total} correct • ${result.exam_name}`;

    // Readiness badge
    const r = result.exam_readiness;
    const colorMap = { success: "#22c55e", warning: "#f59e0b", danger: "#ef4444" };
    document.getElementById("readinessBadge").innerHTML = `
        <div style="display: inline-block; padding: 1rem 2rem; background: ${colorMap[r.color]}22; border: 2px solid ${colorMap[r.color]}; border-radius: 9999px;">
            <strong style="color: ${colorMap[r.color]};">${r.level}:</strong>
            <span style="color: var(--text-secondary); margin-left: 0.5rem;">${r.message}</span>
        </div>
    `;

    // Categories
    document.getElementById("categoryGrid").innerHTML = Object.entries(result.category_breakdown).map(([cat, data]) => `
        <div class="card text-center">
            <div class="text-muted">${cat}</div>
            <h2 style="color: var(--accent-yellow);">${data.score}%</h2>
            <small class="text-muted">${data.correct}/${data.total}</small>
        </div>
    `).join("");

    // Weak topics
    if (result.weak_topics && result.weak_topics.length > 0) {
        document.getElementById("weakTopicsCard").style.display = "block";
        document.getElementById("weakTopicsList").innerHTML = result.weak_topics.map(t => `
            <div class="flex-between" style="padding: 0.5rem 0; border-bottom: 1px solid var(--card-border);">
                <span>📚 ${t.topic}</span>
                <span class="badge" style="background: rgba(239, 68, 68, 0.2); color: #ef4444;">${t.score}%</span>
            </div>
        `).join("");
    }

    // Recommendations
    if (result.recommendations && result.recommendations.length > 0) {
        document.getElementById("recommendationsCard").style.display = "block";
        document.getElementById("recommendationsList").innerHTML = result.recommendations.map(r => `<li>${r}</li>`).join("");
    }
}

function saveToHistory(questions) {
    try {
        const history = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
        history.push(...questions);
        localStorage.setItem(STORAGE_KEY, JSON.stringify(history.slice(-200)));
    } catch (e) {}
}

async function retakeTest() {
    document.getElementById("resultScreen").style.display = "none";
    document.getElementById("examSelectionScreen").style.display = "block";
    sessionToken = null;
    selectedExamType = null;
    document.querySelectorAll(".exam-card").forEach(c => c.classList.remove("selected"));
}
