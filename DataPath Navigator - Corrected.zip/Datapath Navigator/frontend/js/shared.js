function injectSidebar(activePage) {
    const user = api.getUser();
    const userName = user?.full_name || "User";
    const userInitial = userName.charAt(0).toUpperCase();
    const sector = localStorage.getItem('preferred_sector') || 'career';

    let menuItems = '';

    if (sector === 'career') {
        menuItems = `
            <li><a href="dashboard.html" class="${activePage === 'dashboard' ? 'active' : ''}"><span class="icon">📊</span> Dashboard</a></li>
            <li><a href="profile.html" class="${activePage === 'profile' ? 'active' : ''}"><span class="icon">👤</span> Profile</a></li>
            <li><a href="javascript:void(0)"><span class="icon">📋</span> Career Assessments</a>
                <ul class="submenu">
                    <li><a href="aptitude-test.html" class="${activePage === 'aptitude' ? 'active' : ''}">Aptitude Test</a></li>
                    <li><a href="mock-interview.html" class="${activePage === 'mock' ? 'active' : ''}">Mock Interview</a></li>
                </ul>
            </li>
            <li><a href="ai-recommendations.html" class="${activePage === 'recs' ? 'active' : ''}"><span class="icon">🎯</span> AI Recommendation</a></li>
            <li><a href="roadmap.html" class="${activePage === 'roadmap' ? 'active' : ''}"><span class="icon">🗺️</span> Skill Up</a></li>
            <li><a href="skill-gap.html" class="${activePage === 'skillgap' ? 'active' : ''}"><span class="icon">📈</span> Skill Gap Analysis</a></li>
            <li><a href="resource-center.html" class="${activePage === 'resources' ? 'active' : ''}"><span class="icon">📚</span> Resource Center</a></li>
            <li><a href="ai-chat.html" class="${activePage === 'chat' ? 'active' : ''}"><span class="icon">🤖</span> AI Chat</a></li>
            <li><a href="settings.html" class="${activePage === 'settings' ? 'active' : ''}"><span class="icon">⚙️</span> Settings</a></li>
        `;
    } else if (sector === 'government') {
        // ✅ UPDATED: Mock interview removed, aptitude practice added
        menuItems = `
            <li><a href="government-dashboard.html" class="${activePage === 'gov-dashboard' ? 'active' : ''}"><span class="icon">🏛️</span> Govt Dashboard</a></li>
            <li><a href="government-jobs.html" class="${activePage === 'gov-jobs' ? 'active' : ''}"><span class="icon">📋</span> All Govt Jobs</a></li>
            <li><a href="government-bookmarks.html" class="${activePage === 'gov-bookmarks' ? 'active' : ''}"><span class="icon">🔖</span> My Bookmarks</a></li>
            <li><a href="government-aptitude.html" class="${activePage === 'gov-aptitude' ? 'active' : ''}"><span class="icon">📝</span> Exam Practice</a></li>
            <li><a href="resource-center.html" class="${activePage === 'resources' ? 'active' : ''}"><span class="icon">📚</span> Resource Center</a></li>
            <li><a href="ai-chat.html" class="${activePage === 'chat' ? 'active' : ''}"><span class="icon">🤖</span> AI Chat</a></li>
            <li><a href="profile.html" class="${activePage === 'profile' ? 'active' : ''}"><span class="icon">👤</span> Profile</a></li>
            <li><a href="settings.html" class="${activePage === 'settings' ? 'active' : ''}"><span class="icon">⚙️</span> Settings</a></li>
        `;
    }

    const sidebarHTML = `
        <aside class="sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <div class="logo-icon">
                        <img src="photos/main-logo.png" alt="DataPath Navigator" class="logo-image"
                             onerror="this.style.display='none'; this.parentElement.innerHTML='🧭';">
                    </div>
                    <div class="logo-text">
                        <span class="main">DataPath</span>
                        <span class="sub">NAVIGATOR</span>
                    </div>
                </div>
                <div class="sidebar-user">
                    <div class="sidebar-user-avatar"><span>${userInitial}</span></div>
                    <div class="sidebar-user-info">
                        <span class="sidebar-user-name">${userName}</span>
                        <span class="sidebar-user-role">
                            ${user?.role === 'admin' ? '👑 Admin' :
                              sector === 'government' ? '🏛️ Govt Jobs' : '💻 IT Jobs'}
                        </span>
                    </div>
                </div>
            </div>
            <ul class="sidebar-menu">${menuItems}</ul>
        </aside>
    `;
    document.body.insertAdjacentHTML("afterbegin", sidebarHTML);
}

function toggleUserMenu() {
    const menu = document.getElementById("headerUserMenu");
    if (menu) menu.classList.toggle("show");
}

document.addEventListener("click", (e) => {
    const userEl = document.querySelector(".header-user");
    if (userEl && !userEl.contains(e.target)) {
        const menu = document.getElementById("headerUserMenu");
        if (menu) menu.classList.remove("show");
    }
});

document.addEventListener("DOMContentLoaded", () => {
    if (document.querySelector(".app-container")) {
        const page = document.body.dataset.page || "dashboard";
        injectSidebar(page);
        injectTopHeader();
    }
});
