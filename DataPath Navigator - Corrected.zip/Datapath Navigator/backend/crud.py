from sqlalchemy.orm import Session
from sqlalchemy import or_, func
from models import (
    User, Student, Skill, StudentSkill, Career,
    CareerSkill, CareerRecommendation, Course,
    Roadmap, Assessment, Notification, Bookmark
)
from schemas import (
    UserCreate, StudentCreate, StudentUpdate, SkillCreate,
    StudentSkillCreate, CareerCreate, CareerUpdate,
    CareerSkillCreate, CareerRecommendationCreate,
    CourseCreate, RoadmapCreate, AssessmentCreate,
    NotificationCreate
)
from utils.hashing import hash_password


# ===== User CRUD =====

def get_user_by_email(db: Session, email: str):
    return db.query(User).filter(User.email == email).first()


def get_user(db: Session, user_id: int):
    return db.query(User).filter(User.user_id == user_id).first()


def get_all_users(db: Session, skip: int = 0, limit: int = 100, search: str = None, role: str = None):
    query = db.query(User)
    if search:
        query = query.filter(or_(User.full_name.contains(search), User.email.contains(search)))
    if role:
        query = query.filter(User.role == role)
    return query.offset(skip).limit(limit).all()


def create_user(db: Session, user: UserCreate):
    db_user = User(
        full_name=user.full_name,
        email=user.email,
        password=hash_password(user.password),
        role=user.role
    )
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user


def update_user(db: Session, user_id: int, updates: dict):
    user = get_user(db, user_id)
    if user:
        for key, value in updates.items():
            if value is not None:
                setattr(user, key, value)
        db.commit()
        db.refresh(user)
    return user


def delete_user(db: Session, user_id: int):
    user = get_user(db, user_id)
    if user:
        db.delete(user)
        db.commit()
    return user


# ===== Student CRUD =====

def get_student(db: Session, student_id: int):
    return db.query(Student).filter(Student.student_id == student_id).first()


def get_student_by_user(db: Session, user_id: int):
    return db.query(Student).filter(Student.user_id == user_id).first()


def get_all_students(db: Session, skip: int = 0, limit: int = 100):
    return db.query(Student).offset(skip).limit(limit).all()


def create_student(db: Session, student: StudentCreate):
    db_student = Student(**student.model_dump())
    db.add(db_student)
    db.commit()
    db.refresh(db_student)
    return db_student


def update_student(db: Session, student_id: int, updates: StudentUpdate):
    student = get_student(db, student_id)
    if student:
        for key, value in updates.model_dump(exclude_unset=True).items():
            if value is not None:
                setattr(student, key, value)
        db.commit()
        db.refresh(student)
    return student


# ===== Skill CRUD =====

def get_skill(db: Session, skill_id: int):
    return db.query(Skill).filter(Skill.skill_id == skill_id).first()


def get_skill_by_name(db: Session, skill_name: str):
    return db.query(Skill).filter(Skill.skill_name == skill_name).first()


def get_all_skills(db: Session, skip: int = 0, limit: int = 200, search: str = None):
    query = db.query(Skill)
    if search:
        query = query.filter(Skill.skill_name.contains(search))
    return query.offset(skip).limit(limit).all()


def create_skill(db: Session, skill: SkillCreate):
    db_skill = Skill(skill_name=skill.skill_name)
    db.add(db_skill)
    db.commit()
    db.refresh(db_skill)
    return db_skill


# ===== Student Skill CRUD =====

def get_student_skills(db: Session, student_id: int):
    return db.query(StudentSkill).filter(StudentSkill.student_id == student_id).all()


def add_student_skill(db: Session, student_id: int, skill_id: int, proficiency: str):
    existing = db.query(StudentSkill).filter(
        StudentSkill.student_id == student_id,
        StudentSkill.skill_id == skill_id
    ).first()
    if existing:
        existing.proficiency = proficiency
        db.commit()
        db.refresh(existing)
        return existing

    db_ss = StudentSkill(student_id=student_id, skill_id=skill_id, proficiency=proficiency)
    db.add(db_ss)
    db.commit()
    db.refresh(db_ss)
    return db_ss


def remove_student_skill(db: Session, student_skill_id: int):
    ss = db.query(StudentSkill).filter(StudentSkill.student_skill_id == student_skill_id).first()
    if ss:
        db.delete(ss)
        db.commit()
    return ss


# ===== Career CRUD =====

def get_career(db: Session, career_id: int):
    return db.query(Career).filter(Career.career_id == career_id).first()


def get_all_careers(db: Session, skip: int = 0, limit: int = 100, search: str = None):
    query = db.query(Career)
    if search:
        query = query.filter(or_(Career.career_name.contains(search), Career.description.contains(search)))
    return query.offset(skip).limit(limit).all()


def create_career(db: Session, career: CareerCreate):
    db_career = Career(**career.model_dump())
    db.add(db_career)
    db.commit()
    db.refresh(db_career)
    return db_career


def update_career(db: Session, career_id: int, updates: CareerUpdate):
    career = get_career(db, career_id)
    if career:
        for key, value in updates.model_dump(exclude_unset=True).items():
            if value is not None:
                setattr(career, key, value)
        db.commit()
        db.refresh(career)
    return career


def delete_career(db: Session, career_id: int):
    career = get_career(db, career_id)
    if career:
        db.delete(career)
        db.commit()
    return career


# ===== Career Skill CRUD =====

def get_career_skills(db: Session, career_id: int):
    return db.query(CareerSkill).filter(CareerSkill.career_id == career_id).all()


def add_career_skill(db: Session, career_id: int, skill_id: int, importance_level: str):
    existing = db.query(CareerSkill).filter(
        CareerSkill.career_id == career_id,
        CareerSkill.skill_id == skill_id
    ).first()
    if existing:
        existing.importance_level = importance_level
        db.commit()
        db.refresh(existing)
        return existing

    db_cs = CareerSkill(career_id=career_id, skill_id=skill_id, importance_level=importance_level)
    db.add(db_cs)
    db.commit()
    db.refresh(db_cs)
    return db_cs


# ===== Recommendation CRUD =====

def get_recommendations_for_student(db: Session, student_id: int):
    return db.query(CareerRecommendation).filter(
        CareerRecommendation.student_id == student_id
    ).order_by(CareerRecommendation.match_percentage.desc()).all()


def create_recommendation(db: Session, rec: CareerRecommendationCreate):
    db_rec = CareerRecommendation(**rec.model_dump())
    db.add(db_rec)
    db.commit()
    db.refresh(db_rec)
    return db_rec


def clear_recommendations(db: Session, student_id: int):
    db.query(CareerRecommendation).filter(
        CareerRecommendation.student_id == student_id
    ).delete()
    db.commit()


# ===== Course CRUD =====

def get_course(db: Session, course_id: int):
    return db.query(Course).filter(Course.course_id == course_id).first()


def get_courses_by_skill(db: Session, skill_id: int):
    return db.query(Course).filter(Course.skill_id == skill_id).all()


def get_all_courses(db: Session, skip: int = 0, limit: int = 200):
    return db.query(Course).offset(skip).limit(limit).all()


def create_course(db: Session, course: CourseCreate):
    db_course = Course(**course.model_dump())
    db.add(db_course)
    db.commit()
    db.refresh(db_course)
    return db_course


# ===== Roadmap CRUD =====

def get_roadmap(db: Session, roadmap_id: int):
    return db.query(Roadmap).filter(Roadmap.roadmap_id == roadmap_id).first()


def get_roadmaps_by_career(db: Session, career_id: int):
    return db.query(Roadmap).filter(Roadmap.career_id == career_id).all()


def create_roadmap(db: Session, roadmap: RoadmapCreate):
    db_roadmap = Roadmap(**roadmap.model_dump())
    db.add(db_roadmap)
    db.commit()
    db.refresh(db_roadmap)
    return db_roadmap


# ===== Assessment CRUD =====

def get_assessments_for_student(db: Session, student_id: int):
    return db.query(Assessment).filter(
        Assessment.student_id == student_id
    ).order_by(Assessment.assessment_date.desc()).all()


def create_assessment(db: Session, assessment: AssessmentCreate, student_id: int):
    db_assessment = Assessment(
        student_id=student_id,
        aptitude_score=assessment.aptitude_score,
        logical_score=assessment.logical_score,
        communication_score=assessment.communication_score,
        programming_score=assessment.programming_score
    )
    db.add(db_assessment)
    db.commit()
    db.refresh(db_assessment)
    return db_assessment


# ===== Notification CRUD =====

def get_notifications(db: Session, user_id: int, unread_only: bool = False):
    query = db.query(Notification).filter(Notification.user_id == user_id)
    if unread_only:
        query = query.filter(Notification.is_read == False)
    return query.order_by(Notification.created_at.desc()).all()


def mark_notification_read(db: Session, notification_id: int, user_id: int):
    notif = db.query(Notification).filter(
        Notification.notification_id == notification_id,
        Notification.user_id == user_id
    ).first()
    if notif:
        notif.is_read = True
        db.commit()
    return notif


def mark_all_read(db: Session, user_id: int):
    db.query(Notification).filter(
        Notification.user_id == user_id,
        Notification.is_read == False
    ).update({"is_read": True})
    db.commit()


def create_notification(db: Session, notif: NotificationCreate):
    db_notif = Notification(
        user_id=notif.user_id,
        title=notif.title,
        message=notif.message,
        type=notif.type
    )
    db.add(db_notif)
    db.commit()
    db.refresh(db_notif)
    return db_notif


# ===== Bookmark CRUD =====

def add_bookmark(db: Session, user_id: int, career_id: int):
    existing = db.query(Bookmark).filter(
        Bookmark.user_id == user_id,
        Bookmark.career_id == career_id
    ).first()
    if existing:
        return existing
    bookmark = Bookmark(user_id=user_id, career_id=career_id)
    db.add(bookmark)
    db.commit()
    db.refresh(bookmark)
    return bookmark


def get_bookmarks(db: Session, user_id: int):
    return db.query(Bookmark, Career).join(
        Career, Bookmark.career_id == Career.career_id
    ).filter(Bookmark.user_id == user_id).all()


def remove_bookmark(db: Session, user_id: int, career_id: int):
    bookmark = db.query(Bookmark).filter(
        Bookmark.user_id == user_id,
        Bookmark.career_id == career_id
    ).first()
    if bookmark:
        db.delete(bookmark)
        db.commit()
    return bookmark

# Add to crud.py

# ===== Government Job CRUD =====

def get_all_government_jobs(db: Session, skip: int = 0, limit: int = 100,
                            search: str = None, state: str = None,
                            exam_type: str = None, qualification: str = None):
    from models import GovernmentJob
    query = db.query(GovernmentJob).filter(GovernmentJob.is_active == True)
    if search:
        query = query.filter(or_(
            GovernmentJob.title.contains(search),
            GovernmentJob.department.contains(search),
            GovernmentJob.organization.contains(search)
        ))
    if state:
        query = query.filter(GovernmentJob.state == state)
    if exam_type:
        query = query.filter(GovernmentJob.exam_type == exam_type)
    if qualification:
        query = query.filter(GovernmentJob.qualification.contains(qualification))
    return query.order_by(GovernmentJob.posted_date.desc()).offset(skip).limit(limit).all()


def get_government_job(db: Session, job_id: int):
    from models import GovernmentJob
    return db.query(GovernmentJob).filter(GovernmentJob.job_id == job_id).first()


def create_government_job(db: Session, job):
    from models import GovernmentJob
    db_job = GovernmentJob(**job.model_dump())
    db.add(db_job)
    db.commit()
    db.refresh(db_job)
    return db_job


def update_government_job(db: Session, job_id: int, job):
    from models import GovernmentJob
    db_job = db.query(GovernmentJob).filter(GovernmentJob.job_id == job_id).first()
    if not db_job:
        return None
    for key, value in job.model_dump(exclude_unset=True).items():
        setattr(db_job, key, value)
    db.commit()
    db.refresh(db_job)
    return db_job


def delete_government_job(db: Session, job_id: int):
    from models import GovernmentJob, JobBookmark
    db_job = db.query(GovernmentJob).filter(GovernmentJob.job_id == job_id).first()
    if not db_job:
        return False
    db.query(JobBookmark).filter(JobBookmark.job_id == job_id, JobBookmark.job_type == "government").delete(synchronize_session=False)
    db.delete(db_job)
    db.commit()
    return True


# ===== Private Job CRUD =====

def get_all_private_jobs(db: Session, skip: int = 0, limit: int = 100,
                         search: str = None, industry: str = None,
                         location: str = None, job_type: str = None):
    from models import PrivateJob
    query = db.query(PrivateJob).filter(PrivateJob.is_active == True)
    if search:
        query = query.filter(or_(
            PrivateJob.title.contains(search),
            PrivateJob.company.contains(search),
            PrivateJob.skills_required.contains(search)
        ))
    if industry:
        query = query.filter(PrivateJob.industry == industry)
    if location:
        query = query.filter(PrivateJob.location.contains(location))
    if job_type:
        query = query.filter(PrivateJob.job_type == job_type)
    return query.order_by(PrivateJob.posted_date.desc()).offset(skip).limit(limit).all()


def get_private_job(db: Session, job_id: int):
    from models import PrivateJob
    return db.query(PrivateJob).filter(PrivateJob.job_id == job_id).first()


def create_private_job(db: Session, job):
    from models import PrivateJob
    db_job = PrivateJob(**job.model_dump())
    db.add(db_job)
    db.commit()
    db.refresh(db_job)
    return db_job


# ===== Job Bookmark CRUD =====

def add_job_bookmark(db: Session, user_id: int, job_id: int, job_type: str):
    from models import JobBookmark
    existing = db.query(JobBookmark).filter(
        JobBookmark.user_id == user_id,
        JobBookmark.job_id == job_id,
        JobBookmark.job_type == job_type
    ).first()
    if existing:
        return existing
    bm = JobBookmark(user_id=user_id, job_id=job_id, job_type=job_type)
    db.add(bm)
    db.commit()
    db.refresh(bm)
    return bm


def get_user_job_bookmarks(db: Session, user_id: int):
    from models import JobBookmark
    return db.query(JobBookmark).filter(JobBookmark.user_id == user_id).all()


def remove_job_bookmark(db: Session, user_id: int, job_id: int, job_type: str):
    from models import JobBookmark
    bm = db.query(JobBookmark).filter(
        JobBookmark.user_id == user_id,
        JobBookmark.job_id == job_id,
        JobBookmark.job_type == job_type
    ).first()
    if bm:
        db.delete(bm)
        db.commit()
    return bm
