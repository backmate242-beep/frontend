SYSTEM_PROMPT_CAREER_GUIDE = """You are an expert career counselor for the "AI Career Navigator" platform.
Help students with career guidance, skill development, interview prep, and industry insights.
Be friendly, encouraging, and provide actionable advice. Keep responses under 300 words unless detail is needed."""


CAREER_EXPLANATION_PROMPT = """You are a career counselor explaining a career match.

Student: {degree} in {department}, Year {year_of_study}, CGPA {cgpa}
Skills: {skills}
Assessment: {assessments}

Career: {career_name} ({match_percentage}% match)
Description: {career_description}
Required Skills: {required_skills}

Provide:
1. Why this career matches (2-3 sentences)
2. Top 3 student strengths for this career
3. Top 3 skills to develop
4. 3 actionable next steps

Keep it under 250 words, friendly and motivating tone."""


SKILL_GAP_ANALYSIS_PROMPT = """You are a career advisor analyzing a skill gap.

Target Career: {career_name}
Description: {career_description}

Student's Current Skills:
{current_skills}

Required Skills:
{required_skills}

Match: {match_percentage}%

Provide:
1. Skills the student has (with proficiency)
2. Critical skills missing
3. Nice-to-have skills
4. 90-day learning plan
5. Free/affordable resources

Under 400 words, specific and actionable."""


ROADMAP_GENERATION_PROMPT = """Create a detailed 6-month learning roadmap for {career_name}.

Student Background:
- Current Skills: {current_skills}
- Education: {education}
- Daily Time: {hours_per_day} hours

Structure:

**Month 1-2: Foundation**
- Topics, resources, projects, milestones

**Month 3-4: Intermediate**
- Advanced topics, real projects, portfolio

**Month 5-6: Advanced & Job Prep**
- Specialization, interviews, networking

For each month include weekly goals, 2-3 projects, key resources. Use markdown."""


INTERVIEW_QUESTIONS_PROMPT = """Generate 10 interview questions for a {career_name} position.

Include:
- 3 Easy (foundational)
- 4 Medium (practical scenarios)
- 3 Hard (advanced)

For each: question, category, difficulty, brief guidance. Format clearly."""


RESUME_ANALYSIS_PROMPT = """You are an expert resume reviewer.

Target Career: {target_career}
Skills: {skills}
Education: {education}

Resume:
{resume_text}

Provide:
1. Overall assessment (strengths/weaknesses)
2. Top 5 improvements
3. Missing sections
4. ATS keyword optimization
5. Format suggestions

Under 350 words, specific and constructive."""


COURSE_RECOMMENDATION_PROMPT = """Learning advisor for {skill_name}.

Student level: {current_level}
Time: {hours_per_week} hours/week
Budget: {budget}

Recommend:
1. Top 3 Free Resources
2. Top 2 Paid Courses
3. Practice platforms
4. YouTube channels
5. Communities to join

Be specific with names. Under 250 words."""


PERSONALITY_ANALYSIS_PROMPT = """Analyze student's personality from responses.

Responses: {responses}

Provide:
1. Personality type
2. Top 3 strengths
3. Top 3 development areas
4. Best work environment
5. Top 3 career families
6. Work style

Structured, encouraging, under 300 words."""
# Add these to ai/prompts.py

APTITUDE_QUESTIONS_PROMPT = """Generate {num_questions} unique aptitude test questions for assessing a {career_focus} candidate.

Student's Skills: {user_skills}

IMPORTANT: Avoid these previously asked questions:
{previous_questions}

Create questions across these categories:
- Quantitative Aptitude (math, percentages, sequences, ratios)
- Logical Reasoning (patterns, analogies, deductions, puzzles)
- Verbal Ability (comprehension, vocabulary, sentence correction)
- Technical Knowledge (related to {career_focus})
- Situational Judgement (problem-solving scenarios)

Difficulty Distribution:
- 30% Easy (basic concepts)
- 50% Medium (intermediate)
- 20% Hard (advanced)

For EACH question, output in this EXACT format:

Q<n>: [question text]
A) [option 1]
B) [option 2]
C) [option 3]
D) [option 4]
ANSWER: [correct letter]
CATEGORY: [category name]
DIFFICULTY: [Easy/Medium/Hard]
EXPLANATION: [brief 1-line explanation]

Separate each question with a blank line. Make every question completely different and original. Test real-world reasoning, not memorization."""

INTERVIEW_QUESTIONS_DETAILED_PROMPT = """Generate {num_questions} interview questions for a {career_name} position.

Difficulty level: {difficulty}

Include a mix of:
- Behavioral questions (past experiences)
- Technical questions (role-specific knowledge)
- Situational questions (hypothetical scenarios)
- HR questions (motivation, fit)

For EACH question, output in this EXACT JSON format:
[
  {{
    "question": "Tell me about a time when you...",
    "category": "Behavioral",
    "difficulty": "Easy",
    "hint": "Use the STAR method to structure your answer"
  }}
]

Difficulty distribution:
- 30% Easy
- 50% Medium  
- 20% Hard

Return ONLY the JSON array, no markdown."""

# Add these to ai/prompts.py

GOVT_APTITUDE_PROMPT = """Generate {num_questions} unique multiple-choice questions for {exam_name} preparation in India.

EXAM TYPE: {exam_type}
DIFFICULTY: {difficulty}

CATEGORIES TO COVER:
{categories}

KEY TOPICS:
{topics}

AVOID THESE PREVIOUSLY ASKED QUESTIONS:
{previous_questions}

QUESTION DISTRIBUTION:
- 30% Easy (basic concepts, memorization)
- 50% Medium (typical exam level, application)
- 20% Hard (analytical, challenging)

For EACH question, output in this EXACT format (no markdown):

Q<n>: [question text - clear and concise]
A) [option 1]
B) [option 2]
C) [option 3]
D) [option 4]
ANSWER: [correct letter - A, B, C, or D]
CATEGORY: [one of: {categories}]
TOPIC: [specific topic]
DIFFICULTY: [Easy/Medium/Hard]
EXPLANATION: [brief 1-line explanation]

Separate each question with a blank line. Focus on CURRENT AFFAIRS, Indian Polity, History, Geography, Economics, Science, Maths, Reasoning - whichever applies to the exam type. Make every question different and original."""

GOVT_JOB_GENERATION_PROMPT = """You are a government job notification generator. Create {count} realistic, currently-trending government job notifications for {exam_name} in India.

Current Period: {current_month} {current_year}

EXAM CONTEXT:
- Type: {exam_name}
- Real examples in this category: {examples}
- Typical departments: {departments}
- Typical qualifications: {qualifications}
- Typical salary ranges: {salary_ranges}
- Age range: {age_min}-{age_max} years

OUTPUT FORMAT (STRICT JSON array, no markdown, no preamble):
[
  {{
    "title": "Exact official exam title with year",
    "department": "Issuing department",
    "organization": "Conducting organization",
    "qualification": "Required qualification",
    "age_limit_min": {age_min},
    "age_limit_max": {age_max},
    "salary_range": "Realistic pay scale (e.g., '₹25,500 - ₹1,51,100')",
    "location": "Job location (e.g., 'All India', 'Maharashtra', 'Delhi')",
    "state": "Central or specific state",
    "vacancies": realistic_integer,
    "apply_link": "Real official URL (e.g., https://ssc.nic.in)",
    "description": "2-3 line description of the role",
    "eligibility": "Detailed eligibility (education, age, nationality)",
    "exam_pattern": "Stages of exam (Prelims/Mains/Interview etc.)",
    "syllabus_link": "URL or null",
    "days_until_deadline": integer_between_5_and_60
  }}
]

Make these look 100% authentic and current. Use proper 7th CPC pay scales, real official websites, and realistic vacancy numbers. Return ONLY the JSON array."""
