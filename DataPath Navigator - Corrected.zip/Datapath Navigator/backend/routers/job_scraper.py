from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime, timedelta
import secrets

from database import get_db
from oauth2 import get_current_user, get_current_admin
from models import User, GovernmentJob
from ai.ai_service import AIService
from ai.config import AIConfig

router = APIRouter(prefix="/job-scraper", tags=["AI Job Scraper"])


# ===== Exam templates for realistic job generation =====
EXAM_TEMPLATES = {
    "SSC": {
        "name": "SSC (Staff Selection Commission)",
        "examples": ["SSC CGL", "SSC CHSL", "SSC MTS", "SSC GD Constable", "SSC JE", "SSC CPO"],
        "departments": ["Staff Selection Commission", "Central Government Ministries", "Income Tax Dept", "CBI", "CAG"],
        "qualifications": ["10th Pass", "12th Pass", "Graduate", "B.Tech"],
        "salary_ranges": ["₹18,000 - ₹56,900", "₹25,500 - ₹1,51,100", "₹35,400 - ₹1,12,400", "₹44,900 - ₹1,42,400"],
        "age_min": 18,
        "age_max": 32,
    },
    "UPSC": {
        "name": "UPSC Civil Services",
        "examples": ["UPSC CSE", "UPSC NDA", "UPSC CDS", "UPSC CAPF AC", "UPSC IES", "UPSC ESE"],
        "departments": ["IAS", "IPS", "IFS", "Indian Revenue Service", "Indian Engineering Services"],
        "qualifications": ["Graduate", "B.Tech", "Any Degree"],
        "salary_ranges": ["₹56,100 - ₹2,50,000", "₹67,700 - ₹2,08,700", "₹44,900 - ₹1,42,400"],
        "age_min": 21,
        "age_max": 35,
    },
    "Banking": {
        "name": "Banking Sector",
        "examples": ["IBPS PO", "IBPS Clerk", "SBI PO", "SBI Clerk", "RBI Grade B", "IBPS RRB"],
        "departments": ["SBI", "IBPS", "RBI", "Public Sector Banks", "NABARD"],
        "qualifications": ["Graduate", "Any Degree", "B.Com", "BBA", "B.Tech"],
        "salary_ranges": ["₹26,000 - ₹52,000", "₹41,960 - ₹1,32,000", "₹35,400 - ₹99,000"],
        "age_min": 20,
        "age_max": 30,
    },
    "Railway": {
        "name": "Railway (RRB)",
        "examples": ["RRB ALP", "RRB Technician", "RRB JE", "RRB NTPC", "RRB Group D", "RRB Paramedical"],
        "departments": ["Indian Railways", "Railway Zones", "Railway Board", "RRB Regional"],
        "qualifications": ["10th", "12th", "ITI", "Diploma", "B.Tech", "Graduate"],
        "salary_ranges": ["₹19,900 - ₹63,200", "₹35,400 - ₹1,12,400", "₹29,200 - ₹92,300"],
        "age_min": 18,
        "age_max": 33,
    },
    "Defence": {
        "name": "Defence Services",
        "examples": ["NDA", "CDS", "AFCAT", "Indian Army Bharti", "Indian Navy SSR", "Indian Air Force"],
        "departments": ["Indian Army", "Indian Navy", "Indian Air Force", "Para Military Forces", "Coast Guard"],
        "qualifications": ["12th", "Graduate", "B.Tech", "Any Degree"],
        "salary_ranges": ["₹35,400 - ₹1,12,400", "₹56,100 - ₹1,77,500", "₹44,900 - ₹1,42,400"],
        "age_min": 16,
        "age_max": 30,
    },
    "State PSC": {
        "name": "State Public Service Commission",
        "examples": ["MPSC", "UPPSC", "BPSC", "MPPSC", "KPSC", "TNPSC", "APPSC", "GPSC"],
        "departments": ["State Civil Services", "State Police", "State Education", "State Revenue"],
        "qualifications": ["Graduate", "Any Degree", "B.Tech"],
        "salary_ranges": ["₹35,400 - ₹1,12,400", "₹44,900 - ₹1,42,400", "₹29,200 - ₹92,300"],
        "age_min": 21,
        "age_max": 40,
    }
}


# ===== Request Models =====
class GenerateJobsRequest(BaseModel):
    exam_types: List[str]
    count_per_type: int = 3
    current_year: Optional[int] = None


# ===== Endpoints =====
@router.get("/exam-templates")
async def get_templates(_: User = Depends(get_current_admin)):
    """Return available exam templates."""
    return {
        "exam_types": [
            {"code": code, "name": info["name"], "examples": info["examples"][:4]}
            for code, info in EXAM_TEMPLATES.items()
        ]
    }


@router.post("/generate")
async def generate_trending_jobs(
    request: GenerateJobsRequest,
    _: User = Depends(get_current_admin)
):
    """AI generates trending govt jobs from real exam patterns."""
    invalid = [t for t in request.exam_types if t not in EXAM_TEMPLATES]
    if invalid:
        raise HTTPException(status_code=400, detail=f"Invalid exam types: {invalid}")

    if request.count_per_type > 10:
        raise HTTPException(status_code=400, detail="Maximum 10 jobs per type allowed")

    current_year = request.current_year or datetime.utcnow().year
    ai = AIService()

    all_generated = []
    errors = []

    for exam_type in request.exam_types:
        template = EXAM_TEMPLATES[exam_type]

        try:
            jobs = ai.generate_trending_govt_jobs(
                exam_type=exam_type,
                exam_name=template["name"],
                examples=template["examples"],
                departments=template["departments"],
                qualifications=template["qualifications"],
                salary_ranges=template["salary_ranges"],
                age_min=template["age_min"],
                age_max=template["age_max"],
                count=request.count_per_type,
                current_year=current_year
            )

            for job in jobs:
                job["exam_type"] = exam_type
                job["generated_at"] = datetime.utcnow().isoformat()
                all_generated.append(job)

        except Exception as e:
            errors.append(f"{exam_type}: {str(e)}")
            print(f"Error generating {exam_type} jobs: {e}")

    if not all_generated:
        raise HTTPException(status_code=500, detail=f"Failed to generate any jobs. Errors: {errors}")

    batch_id = secrets.token_urlsafe(16)

    return {
        "batch_id": batch_id,
        "generated_count": len(all_generated),
        "jobs": all_generated,
        "powered_by": "Groq AI",
        "errors": errors,
        "message": f"Generated {len(all_generated)} trending jobs. Review and save to publish."
    }


@router.post("/save-batch")
async def save_job_batch(
    payload: dict,
    db: Session = Depends(get_db),
    _: User = Depends(get_current_admin)
):
    """Save selected jobs from a batch to the database."""
    jobs = payload.get("jobs", [])
    if not jobs:
        raise HTTPException(status_code=400, detail="No jobs provided")

    saved = 0
    failed = []

    for idx, job_data in enumerate(jobs):
        try:
            days = job_data.get("days_until_deadline", 30)
            last_date = datetime.utcnow() + timedelta(days=max(days, 1))

            db_job = GovernmentJob(
                title=job_data["title"],
                department=job_data.get("department", ""),
                organization=job_data.get("organization", ""),
                qualification=job_data.get("qualification", ""),
                age_limit_min=job_data.get("age_limit_min", 18),
                age_limit_max=job_data.get("age_limit_max", 40),
                salary_range=job_data.get("salary_range", ""),
                location=job_data.get("location", "All India"),
                state=job_data.get("state", "Central"),
                exam_type=job_data.get("exam_type", "Other"),
                vacancies=job_data.get("vacancies", 0),
                apply_link=job_data.get("apply_link", ""),
                description=job_data.get("description", ""),
                eligibility=job_data.get("eligibility", ""),
                exam_pattern=job_data.get("exam_pattern", ""),
                syllabus_link=job_data.get("syllabus_link"),
                last_date=last_date,
                is_active=True
            )
            db.add(db_job)
            saved += 1
        except Exception as e:
            failed.append({"index": idx, "error": str(e), "title": job_data.get("title", "Unknown")})

    try:
        db.commit()
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Database commit failed: {str(e)}")

    return {
        "saved": saved,
        "failed": len(failed),
        "failed_details": failed,
        "message": f"✅ Saved {saved} jobs successfully. {len(failed)} failed."
    }


@router.get("/recent-ai-jobs")
async def get_recent_ai_jobs(
    days: int = 7,
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user)
):
    """Get jobs added by AI in the last N days."""
    cutoff = datetime.utcnow() - timedelta(days=days)
    recent = db.query(GovernmentJob).filter(
        GovernmentJob.posted_date >= cutoff,
        GovernmentJob.is_active == True
    ).order_by(GovernmentJob.posted_date.desc()).all()

    return {
        "count": len(recent),
        "jobs": [
            {
                "job_id": j.job_id,
                "title": j.title,
                "department": j.department,
                "exam_type": j.exam_type,
                "vacancies": j.vacancies,
                "last_date": str(j.last_date) if j.last_date else None,
                "posted_date": str(j.posted_date)
            }
            for j in recent
        ]
    }
