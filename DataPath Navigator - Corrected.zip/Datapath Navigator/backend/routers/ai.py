# routers/ai.py
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form
from sqlalchemy.orm import Session
from typing import List
from pydantic import BaseModel

from database import get_db
from oauth2 import get_current_user
from models import User, Student, StudentSkill, Skill, Career, CareerSkill
from crud import get_student_by_user
from ai.ai_service import AIService
from ai.config import AIConfig

router = APIRouter(prefix="/ai", tags=["AI Features"])


# ===== Request Models =====
class ChatMessage(BaseModel):
    message: str
    history: list = []


class SkillGapRequest(BaseModel):
    career_id: int


class RoadmapRequest(BaseModel):
    career_name: str
    current_skills: list = []
    education: str = "Bachelor's"
    hours_per_day: int = 2


class InterviewRequest(BaseModel):
    career_name: str
    num_questions: int = 10


class ResumeAnalysisRequest(BaseModel):
    resume_text: str
    target_career: str


class CourseRecommendationRequest(BaseModel):
    skill_name: str
    current_level: str = "Beginner"
    hours_per_week: int = 5
    budget: str = "Free"


class TTSRequest(BaseModel):
    text: str
    voice: str = None
    language: str = "english"


class GuardRequest(BaseModel):
    text: str



class ResourceRecommendationRequest(BaseModel):
    mode: str = "career"  # career or government
    target: str
    interests: str = ""

@router.post("/resource-recommendations")
def resource_recommendations(request: ResourceRecommendationRequest, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    student = get_student_by_user(db, current_user.user_id)
    skills = []
    education = "N/A"
    if student:
        education = f"{student.degree or ''} in {student.department or ''}".strip(" in") or "N/A"
        skill_rows = db.query(StudentSkill).filter(StudentSkill.student_id == student.student_id).all()
        all_skills = {x.skill_id: x.skill_name for x in db.query(Skill).all()}
        skills = [all_skills[x.skill_id] for x in skill_rows if x.skill_id in all_skills]

    mode = request.mode.lower().strip()
    if mode not in {"career", "government"}:
        raise HTTPException(status_code=400, detail="mode must be career or government")

    prompt = f"""Create a practical learning-resource plan for an Indian student.
Mode: {mode}
Target: {request.target}
Education: {education}
Current skills: {', '.join(skills) or 'None'}
Interests: {request.interests or 'Not provided'}

For government exams, focus on the likely exam subjects/topics and preparation resources.
For job roles, focus on required skills, identify likely skill gaps, and recommend courses.
Return ONLY valid JSON with keys: required_skills (array), skill_gaps (array), courses (array of objects with title, skill, level, free), youtube_topics (array), study_plan (array).
Keep it concise and useful."""

    ai = AIService()
    try:
        raw = ai.generate_content(prompt, temperature=0.4, max_tokens=1400, model=AIConfig.MODEL_COURSES)
        text = raw.strip().replace("```json", "").replace("```", "").strip()
        import json
        result = json.loads(text)
    except Exception:
        # Reliable fallback so Resource Center remains usable without AI/API access.
        target = request.target.strip()
        if mode == "government":
            topics = ["Quantitative Aptitude", "Reasoning", "English", "General Awareness", target]
            result = {"required_skills": topics[:-1], "skill_gaps": topics[:-1],
                      "courses": [{"title": f"{x} Preparation", "skill": x, "level": "Beginner", "free": True} for x in topics[:-1]],
                      "youtube_topics": topics, "study_plan": [f"Study {topics[i]} and practice previous-year questions" for i in range(min(4, len(topics)))]}
        else:
            skills_target = [target, "Communication", "Problem Solving"]
            result = {"required_skills": skills_target, "skill_gaps": [x for x in skills_target if x.lower() not in {s.lower() for s in skills}],
                      "courses": [{"title": f"{x} Course", "skill": x, "level": "Beginner", "free": True} for x in skills_target],
                      "youtube_topics": skills_target, "study_plan": [f"Learn {x} and build a small project" for x in skills_target]}

    result["youtube_searches"] = [f"https://www.youtube.com/results?search_query={__import__('urllib.parse').parse.quote(str(t))}" for t in result.get("youtube_topics", [])]
    result["target"] = request.target
    result["mode"] = mode
    result["current_skills"] = skills
    result["education"] = education
    return result


# ===== Status =====
@router.get("/status")
def ai_status():
    return {
        "provider": "groq",
        "gemini_enabled": False,
        "groq_enabled": AIConfig.USE_GROQ,
        "active": AIConfig.USE_AI,
        "models_per_operation": {
            "chat": AIConfig.MODEL_CHAT,
            "recommendations": AIConfig.MODEL_RECOMMENDATIONS,
            "skill_gap": AIConfig.MODEL_SKILL_GAP,
            "roadmap": AIConfig.MODEL_ROADMAP,
            "aptitude": AIConfig.MODEL_APTITUDE,
            "interview": AIConfig.MODEL_INTERVIEW,
            "resume": AIConfig.MODEL_RESUME,
            "courses": AIConfig.MODEL_COURSES,
            "evaluation": AIConfig.MODEL_EVAL,
        },
        "safety": {
            "input_guard": AIConfig.MODEL_PROMPT_GUARD,
            "safeguard": AIConfig.MODEL_SAFEGUARD,
            "input_guard_enabled": AIConfig.ENABLE_INPUT_GUARD,
            "safeguard_enabled": AIConfig.ENABLE_OUTPUT_SAFEGUARD,
        },
        "audio": {
            "stt": AIConfig.MODEL_STT,
            "tts": AIConfig.MODEL_TTS,
            "tts_arabic": AIConfig.MODEL_TTS_ARABIC,
        },
        "fallback_available": True
    }


# ===== Chat =====
@router.post("/chat")
def chat(payload: ChatMessage, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    ai = AIService()
    context = {"name": current_user.full_name}
    student = get_student_by_user(db, current_user.user_id)
    if student:
        context.update({"degree": student.degree, "department": student.department})
    result = ai.chat(payload.message, payload.history, context)
    return result


# ===== Recommendations =====
@router.post("/recommendations")
def get_recommendations(top_n: int = 5, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    student = get_student_by_user(db, current_user.user_id)
    if not student:
        raise HTTPException(status_code=404, detail="Create profile first")

    student_skills_db = db.query(StudentSkill).filter(StudentSkill.student_id == student.student_id).all()
    all_skills = {s.skill_id: s.skill_name for s in db.query(Skill).all()}
    user_skills = [all_skills[ss.skill_id] for ss in student_skills_db if ss.skill_id in all_skills]

    careers_db = db.query(Career).all()
    careers = [{
        "career_id": c.career_id,
        "career_name": c.career_name,
        "description": c.description,
        "average_salary": float(c.average_salary) if c.average_salary else None
    } for c in careers_db]

    ai = AIService()
    recs = ai.get_recommendations(user_skills, top_n, careers)
    return recs


# ===== Skill Gap =====
@router.post("/skill-gap")
def skill_gap(request: SkillGapRequest, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    student = get_student_by_user(db, current_user.user_id)
    career = db.query(Career).filter(Career.career_id == request.career_id).first()
    if not student: raise HTTPException(status_code=404, detail="Profile not found")
    if not career: raise HTTPException(status_code=404, detail="Career not found")

    student_skills_db = db.query(StudentSkill).filter(StudentSkill.student_id == student.student_id).all()
    all_skills = {s.skill_id: s.skill_name for s in db.query(Skill).all()}
    user_skills = [all_skills[ss.skill_id] for ss in student_skills_db if ss.skill_id in all_skills]

    career_skills_db = db.query(CareerSkill).filter(CareerSkill.career_id == career.career_id).all()
    required_skills = [all_skills[cs.skill_id] for cs in career_skills_db if cs.skill_id in all_skills]

    matched = list(set([s.lower() for s in user_skills]) & set([s.lower() for s in required_skills]))
    missing = [s for s in required_skills if s.lower() not in matched]
    match_pct = (len(matched) / max(len(required_skills), 1) * 100) if required_skills else 0

    ai = AIService()
    result = ai.analyze_skill_gap(user_skills, career.career_name, required_skills)
    return {
        "gap_analysis": {
            "career_name": career.career_name,
            "total_required_skills": len(required_skills),
            "matched_skills": matched,
            "missing_skills": missing,
            "match_percentage": round(match_pct, 2)
        },
        "ai_advice": result["ai_advice"],
        "model": result.get("model")
    }


# ===== Roadmap =====
@router.post("/roadmap/generate")
def roadmap(request: RoadmapRequest, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    if not request.current_skills:
        student = get_student_by_user(db, current_user.user_id)
        if student:
            student_skills_db = db.query(StudentSkill).filter(StudentSkill.student_id == student.student_id).all()
            all_skills = {s.skill_id: s.skill_name for s in db.query(Skill).all()}
            request.current_skills = [all_skills[ss.skill_id] for ss in student_skills_db if ss.skill_id in all_skills]
            if student.degree:
                request.education = f"{student.degree} in {student.department or 'N/A'}"

    ai = AIService()
    text = ai.generate_roadmap(request.career_name, request.current_skills, request.education, request.hours_per_day)
    return {"career": request.career_name, "roadmap": text, "powered_by": "Groq", "model": AIConfig.MODEL_ROADMAP}


# ===== Interview Questions =====
@router.post("/interview/questions")
def interview_questions(request: InterviewRequest, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    ai = AIService()
    questions = ai.generate_interview_questions(request.career_name, request.num_questions)
    return {"career": request.career_name, "questions": questions, "total": len(questions), "model": AIConfig.MODEL_INTERVIEW}


# ===== Resume =====
@router.post("/resume/analyze")
def analyze_resume(request: ResumeAnalysisRequest, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    student = get_student_by_user(db, current_user.user_id)
    user_skills, education = [], "N/A"
    if student:
        student_skills_db = db.query(StudentSkill).filter(StudentSkill.student_id == student.student_id).all()
        all_skills = {s.skill_id: s.skill_name for s in db.query(Skill).all()}
        user_skills = [all_skills[ss.skill_id] for ss in student_skills_db if ss.skill_id in all_skills]
        education = f"{student.degree or ''} in {student.department or ''}".strip()

    ai = AIService()
    feedback = ai.analyze_resume(request.resume_text, request.target_career, user_skills, education)
    return {"target_career": request.target_career, "feedback": feedback, "powered_by": "Groq", "model": AIConfig.MODEL_RESUME}


# ===== Courses =====
@router.post("/courses/recommend")
def recommend_courses(request: CourseRecommendationRequest, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    ai = AIService()
    text = ai.recommend_courses(request.skill_name, request.current_level, request.hours_per_week, request.budget)
    return {"skill": request.skill_name, "recommendations": text, "model": AIConfig.MODEL_COURSES}


# ============================================================
# 🛡️ SAFETY: Input guard
# ============================================================
@router.post("/guard-input")
def guard_input(payload: GuardRequest, current_user: User = Depends(get_current_user)):
    """Check if user input is safe (prompt injection / jailbreak detection)."""
    ai = AIService()
    result = ai.guard_input(payload.text)
    return result


# ============================================================
# 🛡️ SAFETY: Output safeguard
# ============================================================
@router.post("/safeguard")
def safeguard_output(payload: GuardRequest, current_user: User = Depends(get_current_user)):
    """Check if content is safe to show user (moderation)."""
    ai = AIService()
    result = ai.safeguard_output(payload.text)
    return result


# ============================================================
# 🎙️ AUDIO: Speech-to-Text (Whisper)
# ============================================================
@router.post("/transcribe")
async def transcribe_audio(
    file: UploadFile = File(...),
    language: str = Form("en"),
    model: str = Form(None),
    current_user: User = Depends(get_current_user)
):
    """Transcribe audio file to text using Whisper."""
    import tempfile, os
    ai = AIService()

    # Save uploaded file temporarily
    suffix = os.path.splitext(file.filename)[1] or ".wav"
    with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
        content = await file.read()
        tmp.write(content)
        tmp_path = tmp.name

    try:
        result = ai.transcribe_audio(tmp_path, language=language, model=model)
        return result
    finally:
        if os.path.exists(tmp_path):
            os.remove(tmp_path)


# ============================================================
# 🔊 AUDIO: Text-to-Speech (Orpheus)
# ============================================================
@router.post("/speak")
def text_to_speech(payload: TTSRequest, current_user: User = Depends(get_current_user)):
    """Convert text to speech using Orpheus TTS."""
    ai = AIService()
    result = ai.text_to_speech(payload.text, voice=payload.voice, language=payload.language)
    return result
