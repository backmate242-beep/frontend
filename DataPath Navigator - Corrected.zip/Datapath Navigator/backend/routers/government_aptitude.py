from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel, Field
from typing import List, Optional
from datetime import datetime, timedelta
import secrets

from database import get_db
from oauth2 import get_current_user
from models import User
from ai.ai_service import AIService
from ai.config import AIConfig

router = APIRouter(prefix="/govt-aptitude", tags=["Government Aptitude Practice"])


# ===== Exam definitions with realistic patterns =====
EXAM_PATTERNS = {
    "SSC": {
        "name": "SSC (Staff Selection Commission)",
        "categories": ["General Intelligence & Reasoning", "General Awareness", "Quantitative Aptitude", "English Comprehension"],
        "topics": ["Indian Polity", "Geography", "Indian History", "Current Affairs", "Quantitative Maths", "Analytical Reasoning", "English Vocabulary", "Census & Economy"],
        "difficulty": "Medium",
        "icon": "📋"
    },
    "UPSC": {
        "name": "UPSC Civil Services (IAS/IPS/IFS)",
        "categories": ["Indian Polity & Governance", "History (India & World)", "Geography", "Economy", "Environment & Ecology", "Current Affairs", "General Science"],
        "topics": ["Constitution", "Modern History", "World History", "Physical & Economic Geography", "Budget & Economic Survey", "Biodiversity", "Science & Tech"],
        "difficulty": "Hard",
        "icon": "🏆"
    },
    "Banking": {
        "name": "Banking (IBPS / SBI / RBI)",
        "categories": ["Reasoning Ability", "Quantitative Aptitude", "English Language", "Banking Awareness", "Computer Knowledge", "General Awareness"],
        "topics": ["Banking Terminology", "Financial Awareness", "Monetary Policy", "Current Affairs", "Number Series", "Data Interpretation", "Reading Comprehension"],
        "difficulty": "Medium",
        "icon": "🏦"
    },
    "Railway": {
        "name": "Railway (RRB ALP / NTPC / JE)",
        "categories": ["Mathematics", "General Intelligence & Reasoning", "General Awareness", "General Science"],
        "topics": ["Basic Maths", "Physics", "Chemistry", "Biology", "Current Affairs", "Railway History & GK"],
        "difficulty": "Easy-Medium",
        "icon": "🚂"
    },
    "Defence": {
        "name": "Defence (NDA / CDS / AFCAT)",
        "categories": ["Mathematics", "General Knowledge", "English", "Current Affairs"],
        "topics": ["Algebra & Trigonometry", "Defence Knowledge", "History", "Geography", "General English", "Current Affairs"],
        "difficulty": "Medium-Hard",
        "icon": "🛡️"
    },
    "State PSC": {
        "name": "State Public Service Commission",
        "categories": ["General Studies", "State GK", "Current Affairs", "Aptitude"],
        "topics": ["State History", "State Geography", "Indian Polity", "Constitution", "Economy"],
        "difficulty": "Medium",
        "icon": "📜"
    }
}


# ===== In-memory session storage =====
_answer_store = {}


# ===== Request Models =====
class GenerateRequest(BaseModel):
    exam_type: str
    num_questions: int = 25
    previous_questions: List[str] = []


class SubmitRequest(BaseModel):
    session_token: str
    user_answers: List[Optional[int]]
    time_taken_seconds: int = 0


# ===== Endpoints =====
@router.get("/exam-types")
async def get_exam_types():
    """Return available exam types."""
    return {
        "exam_types": [
            {
                "code": code,
                "name": info["name"],
                "icon": info["icon"],
                "difficulty": info["difficulty"],
                "category_count": len(info["categories"])
            }
            for code, info in EXAM_PATTERNS.items()
        ]
    }


@router.post("/generate")
async def generate_questions(
    request: GenerateRequest,
    current_user: User = Depends(get_current_user)
):
    """Generate AI-powered exam-specific aptitude questions."""
    if request.exam_type not in EXAM_PATTERNS:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid exam type. Choose from: {list(EXAM_PATTERNS.keys())}"
        )

    exam_info = EXAM_PATTERNS[request.exam_type]

    if request.num_questions > 50:
        raise HTTPException(status_code=400, detail="Maximum 50 questions allowed")

    ai = AIService()
    questions = ai.generate_govt_aptitude_questions(
        exam_type=request.exam_type,
        exam_name=exam_info["name"],
        categories=exam_info["categories"],
        topics=exam_info["topics"],
        difficulty=exam_info["difficulty"],
        num_questions=request.num_questions,
        previous_questions=request.previous_questions
    )

    if not questions or len(questions) < 5:
        raise HTTPException(status_code=500, detail="Failed to generate enough questions")

    # Store session
    session_token = secrets.token_urlsafe(32)
    _answer_store[session_token] = {
        "user_id": current_user.user_id,
        "exam_type": request.exam_type,
        "exam_name": exam_info["name"],
        "questions": questions,
        "created_at": datetime.utcnow()
    }

    # Cleanup old sessions
    cutoff = datetime.utcnow() - timedelta(hours=2)
    expired = [k for k, v in list(_answer_store.items()) if v["created_at"] < cutoff]
    for k in expired:
        del _answer_store[k]

    # Strip answers before sending to client
    public_questions = [
        {
            "id": i,
            "question": q["question"],
            "options": q["options"],
            "category": q.get("category", "General"),
            "topic": q.get("topic", ""),
            "difficulty": q.get("difficulty", "Medium")
        }
        for i, q in enumerate(questions)
    ]

    return {
        "questions": public_questions,
        "session_token": session_token,
        "total": len(public_questions),
        "exam_type": request.exam_type,
        "exam_name": exam_info["name"],
        "powered_by": "Groq AI" if AIConfig.USE_GROQ else "AI Engine"
    }


@router.post("/submit")
async def submit_answers(
    request: SubmitRequest,
    current_user: User = Depends(get_current_user)
):
    """Submit answers and get detailed scoring."""
    if request.session_token not in _answer_store:
        raise HTTPException(status_code=400, detail="Invalid or expired session")

    session = _answer_store[request.session_token]
    if session["user_id"] != current_user.user_id:
        raise HTTPException(status_code=403, detail="Session mismatch")

    questions = session["questions"]
    exam_type = session["exam_type"]
    user_answers = request.user_answers
    del _answer_store[request.session_token]

    if len(questions) != len(user_answers):
        raise HTTPException(
            status_code=400,
            detail=f"Answers count mismatch: got {len(user_answers)}, expected {len(questions)}"
        )

    total = len(questions)
    correct = 0
    unanswered = 0
    category_scores = {}
    topic_scores = {}

    for i, q in enumerate(questions):
        cat = q.get("category", "General")
        topic = q.get("topic", "General")
        category_scores.setdefault(cat, {"correct": 0, "total": 0})
        category_scores[cat]["total"] += 1
        topic_scores.setdefault(topic, {"correct": 0, "total": 0})
        topic_scores[topic]["total"] += 1

        user_ans = user_answers[i] if i < len(user_answers) else None
        if user_ans is None or user_ans == -1:
            unanswered += 1
        elif user_ans == q["answer"]:
            correct += 1
            category_scores[cat]["correct"] += 1
            topic_scores[topic]["correct"] += 1

    overall_score = (correct / total * 100) if total > 0 else 0

    def pct(s):
        return round(s["correct"] / s["total"] * 100, 1) if s["total"] > 0 else 0

    return {
        "overall_score": round(overall_score, 2),
        "correct": correct,
        "total": total,
        "unanswered": unanswered,
        "time_taken_seconds": request.time_taken_seconds,
        "exam_type": exam_type,
        "exam_name": session["exam_name"],
        "category_breakdown": {
            cat: {"score": pct(s), "correct": s["correct"], "total": s["total"]}
            for cat, s in category_scores.items()
        },
        "weak_topics": [
            {"topic": t, "score": pct(s)}
            for t, s in sorted(topic_scores.items(), key=lambda x: pct(x[1]))
            if pct(s) < 60
        ][:5],
        "exam_readiness": get_exam_readiness(overall_score, exam_type),
        "performance_message": get_performance_message(overall_score),
        "recommendations": generate_recommendations(category_scores, overall_score, exam_type)
    }


def get_exam_readiness(score, exam_type):
    """Determine exam readiness based on typical cutoff."""
    cutoffs = {
        "SSC": 75,
        "UPSC": 65,
        "Banking": 70,
        "Railway": 70,
        "Defence": 70,
        "State PSC": 70
    }
    threshold = cutoffs.get(exam_type, 70)
    if score >= threshold + 15:
        return {"ready": True, "level": "Highly Ready", "message": f"🎯 Excellent! You're well above the {threshold}% threshold.", "color": "success"}
    elif score >= threshold:
        return {"ready": True, "level": "Ready", "message": f"✅ You meet the {threshold}% threshold. Keep practicing!", "color": "success"}
    elif score >= threshold - 15:
        return {"ready": False, "level": "Almost Ready", "message": f"📈 You're close! Need {round(threshold - score, 1)} more points to clear {threshold}% threshold.", "color": "warning"}
    else:
        return {"ready": False, "level": "Needs Practice", "message": f"📚 Focus on fundamentals. Target: {threshold}%", "color": "danger"}


def get_performance_message(score):
    if score >= 85:
        return "Outstanding! 🌟 You're exam-ready!"
    elif score >= 70:
        return "Great job! 🎉 Strong performance!"
    elif score >= 55:
        return "Good effort! 👍 Solid foundation."
    elif score >= 40:
        return "Keep practicing! 💪 Review weak areas."
    else:
        return "Don't give up! 🚀 Review fundamentals."


def generate_recommendations(category_scores, score, exam_type):
    weak_cats = sorted(
        [(cat, s["correct"] / s["total"] * 100) for cat, s in category_scores.items() if s["total"] > 0],
        key=lambda x: x[1]
    )[:2]

    recs = []
    for cat, cat_score in weak_cats:
        recs.append(f"Focus on {cat} - your score was {round(cat_score, 1)}%")

    if score < 50:
        recs.append(f"Revise fundamentals for {exam_type} exam basics")
        recs.append("Take at least 5 more practice tests before the actual exam")
    elif score < 75:
        recs.append("Solve previous year question papers")
        recs.append("Practice time management - aim for <1 min per question")
    else:
        recs.append("Great work! Take mock tests weekly to maintain your edge")

    return recs
