// js/government-jobs.js
// Shared logic for government jobs pages

async function loadJobs() {
    const container = document.getElementById('jobsContainer');
    if (!container) return;

    const search = document.getElementById('searchInput')?.value || '';
    const state = document.getElementById('stateFilter')?.value || '';
    const examType = document.getElementById('examFilter')?.value || '';
    const qualification = document.getElementById('qualFilter')?.value || '';

    container.innerHTML = '<p class="text-muted text-center" style="padding:2rem;">⏳ Loading...</p>';

    try {
        const params = { limit: 50 };
        if (search) params.search = search;
        if (state) params.state = state;
        if (examType) params.exam_type = examType;
        if (qualification) params.qualification = qualification;

        const jobs = await api.get('/government-jobs/', params);

        if (!jobs.length) {
            container.innerHTML = '<div class="empty-state"><div style="font-size:3rem;">📭</div><p>No jobs match your filters.</p></div>';
            return;
        }

        // Sort
        const sortBy = document.getElementById('sortBy')?.value || 'latest';
        if (sortBy === 'closing') {
            jobs.sort((a, b) => new Date(a.last_date || '2099') - new Date(b.last_date || '2099'));
        } else if (sortBy === 'vacancies') {
            jobs.sort((a, b) => (b.vacancies || 0) - (a.vacancies || 0));
        }

        container.innerHTML = jobs.map(job => renderJobCard(job, sortBy === 'closing')).join('');

        // Update dashboard stats if those elements exist
        const totalEl = document.getElementById('statTotal');
        if (totalEl) {
            totalEl.textContent = jobs.length;
            document.getElementById('statCentral').textContent = jobs.filter(j => j.state === 'Central' || !j.state).length;
            document.getElementById('statState').textContent = jobs.filter(j => j.state && j.state !== 'Central').length;
            const now = new Date();
            document.getElementById('statClosing').textContent = jobs.filter(j => {
                if (!j.last_date) return false;
                const days = (new Date(j.last_date) - now) / (1000*60*60*24);
                return days >= 0 && days <= 7;
            }).length;
        }
    } catch (err) {
        container.innerHTML = '<div class="empty-state"><p style="color:var(--danger);">Failed to load jobs.</p></div>';
        showToast('Failed to load jobs', 'error');
    }
}

function renderJobCard(job, showClosing = false) {
    const deadline = job.last_date ? new Date(job.last_date) : null;
    const daysLeft = deadline ? Math.ceil((deadline - new Date()) / (1000*60*60*24)) : null;
    const closingSoon = daysLeft !== null && daysLeft >= 0 && daysLeft <= 7;

    return `
        <div class="job-card-full">
            <div class="job-title-row">
                <div>
                    <span class="badge-gov">${job.exam_type || 'Govt'}</span>
                    <h3 style="margin-top: 0.5rem;">${job.title}</h3>
                    <p style="color: var(--text-secondary); margin: 0.25rem 0;">
                        <strong>${job.organization || ''}</strong>${job.department ? ' · ' + job.department : ''}
                    </p>
                </div>
                ${closingSoon ? '<span class="closing-soon">⏰ CLOSING SOON</span>' : ''}
            </div>

            <div class="job-meta-grid">
                <div class="meta-cell">
                    <div class="label">Vacancies</div>
                    <div class="value">${job.vacancies || 'N/A'}</div>
                </div>
                <div class="meta-cell">
                    <div class="label">Qualification</div>
                    <div class="value">${job.qualification || 'See details'}</div>
                </div>
                <div class="meta-cell">
                    <div class="label">Age Limit</div>
                    <div class="value">${job.age_limit_min || 18}-${job.age_limit_max || 40} yrs</div>
                </div>
                <div class="meta-cell">
                    <div class="label">Salary</div>
                    <div class="value">${job.salary_range || 'As per norms'}</div>
                </div>
                <div class="meta-cell">
                    <div class="label">Location</div>
                    <div class="value">${job.state || 'All India'}</div>
                </div>
                ${deadline ? `
                <div class="meta-cell">
                    <div class="label">Last Date</div>
                    <div class="value">${deadline.toLocaleDateString('en-IN', {day:'numeric', month:'short', year:'numeric'})}</div>
                </div>
                ` : ''}
            </div>

            ${showClosing && daysLeft !== null && daysLeft >= 0 ? `<div class="last-date">⏳ ${daysLeft} day${daysLeft===1?'':'s'} left to apply</div>` : ''}

            <div class="actions">
                <a href="government-job-detail.html?id=${job.job_id}" class="btn btn-sm btn-primary">View Details</a>
                ${job.apply_link ? `<a href="${job.apply_link}" target="_blank" class="btn btn-sm btn-outline-yellow">Apply Now ↗</a>` : ''}
                <button class="btn btn-sm btn-secondary" onclick="bookmarkGovJob(${job.job_id})">🔖 Save</button>
            </div>
        </div>
    `;
}

async function bookmarkGovJob(jobId) {
    try {
        await api.post('/government-jobs/bookmark', { job_id: jobId });
        showToast('Bookmarked! 🔖', 'success');
    } catch (err) {
        showToast('Failed to bookmark', 'error');
    }
}

function resetFilters() {
    document.getElementById('searchInput').value = '';
    document.getElementById('stateFilter').value = '';
    document.getElementById('examFilter').value = '';
    document.getElementById('qualFilter').value = '';
    if (document.getElementById('sortBy')) document.getElementById('sortBy').value = 'latest';
    loadJobs();
}

// Auto-load on government-jobs pages
document.addEventListener('DOMContentLoaded', () => {
    if (document.getElementById('jobsContainer') && requireAuth()) {
        loadJobs();
    }
});
