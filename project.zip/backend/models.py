from sqlalchemy import (
    Column, Integer, String, Text, DECIMAL, Enum,
    TIMESTAMP, ForeignKey, Boolean
)
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship
from database import Base


class User(Base):
    __tablename__ = "users"

    user_id = Column(Integer, primary_key=True, index=True)
    full_name = Column(String(100), nullable=False)
    email = Column(String(100), unique=True, nullable=False)
    password = Column(String(255), nullable=False)
    role = Column(Enum("student", "admin"), default="student")
    profile_picture = Column(String(500), nullable=True)
    is_active = Column(Boolean, default=True)
    created_at = Column(TIMESTAMP, server_default=func.now())

    student = relationship("Student", back_populates="user", uselist=False)


class Student(Base):
    __tablename__ = "students"

    student_id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.user_id"))
    age = Column(Integer)
    gender = Column(Enum("Male", "Female", "Other"))
    degree = Column(String(100))
    department = Column(String(100))
    year_of_study = Column(Integer)
    cgpa = Column(DECIMAL(3, 2))

    user = relationship("User", back_populates="student")
    skills = relationship("StudentSkill", back_populates="student")
    recommendations = relationship("CareerRecommendation", back_populates="student")
    assessments = relationship("Assessment", back_populates="student")


class Skill(Base):
    __tablename__ = "skills"

    skill_id = Column(Integer, primary_key=True, index=True)
    skill_name = Column(String(100), unique=True, nullable=False)

    student_skills = relationship("StudentSkill", back_populates="skill")
    career_skills = relationship("CareerSkill", back_populates="skill")
    courses = relationship("Course", back_populates="skill")


class StudentSkill(Base):
    __tablename__ = "student_skills"

    student_skill_id = Column(Integer, primary_key=True)
    student_id = Column(Integer, ForeignKey("students.student_id"))
    skill_id = Column(Integer, ForeignKey("skills.skill_id"))
    proficiency = Column(Enum("Beginner", "Intermediate", "Advanced"))

    student = relationship("Student", back_populates="skills")
    skill = relationship("Skill", back_populates="student_skills")


class Career(Base):
    __tablename__ = "careers"

    career_id = Column(Integer, primary_key=True)
    career_name = Column(String(100), nullable=False)
    description = Column(Text)
    average_salary = Column(DECIMAL(12, 2))
    required_degree = Column(String(100))

    career_skills = relationship("CareerSkill", back_populates="career")
    recommendations = relationship("CareerRecommendation", back_populates="career")
    roadmaps = relationship("Roadmap", back_populates="career")


class CareerSkill(Base):
    __tablename__ = "career_skills"

    career_skill_id = Column(Integer, primary_key=True)
    career_id = Column(Integer, ForeignKey("careers.career_id"))
    skill_id = Column(Integer, ForeignKey("skills.skill_id"))
    importance_level = Column(Enum("Low", "Medium", "High"))

    career = relationship("Career", back_populates="career_skills")
    skill = relationship("Skill", back_populates="career_skills")


class CareerRecommendation(Base):
    __tablename__ = "career_recommendations"

    recommendation_id = Column(Integer, primary_key=True)
    student_id = Column(Integer, ForeignKey("students.student_id"))
    career_id = Column(Integer, ForeignKey("careers.career_id"))
    match_percentage = Column(DECIMAL(5, 2))
    recommendation_date = Column(TIMESTAMP, server_default=func.now())

    student = relationship("Student", back_populates="recommendations")
    career = relationship("Career", back_populates="recommendations")


class Course(Base):
    __tablename__ = "courses"

    course_id = Column(Integer, primary_key=True)
    course_name = Column(String(150))
    platform = Column(String(100))
    course_link = Column(String(500))
    skill_id = Column(Integer, ForeignKey("skills.skill_id"))

    skill = relationship("Skill", back_populates="courses")


class Roadmap(Base):
    __tablename__ = "roadmaps"

    roadmap_id = Column(Integer, primary_key=True)
    career_id = Column(Integer, ForeignKey("careers.career_id"))
    roadmap_title = Column(String(150))
    roadmap_description = Column(Text)

    career = relationship("Career", back_populates="roadmaps")


class Assessment(Base):
    __tablename__ = "assessments"

    assessment_id = Column(Integer, primary_key=True)
    student_id = Column(Integer, ForeignKey("students.student_id"))
    aptitude_score = Column(DECIMAL(5, 2))
    logical_score = Column(DECIMAL(5, 2))
    communication_score = Column(DECIMAL(5, 2))
    programming_score = Column(DECIMAL(5, 2))
    assessment_date = Column(TIMESTAMP, server_default=func.now())

    student = relationship("Student", back_populates="assessments")


# ===== Additional Tables =====

class Notification(Base):
    __tablename__ = "notifications"

    notification_id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.user_id"))
    title = Column(String(200), nullable=False)
    message = Column(Text, nullable=False)
    type = Column(String(50), default="info")
    is_read = Column(Boolean, default=False)
    created_at = Column(TIMESTAMP, server_default=func.now())


class Bookmark(Base):
    __tablename__ = "bookmarks"

    bookmark_id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.user_id"))
    career_id = Column(Integer, ForeignKey("careers.career_id"))
    created_at = Column(TIMESTAMP, server_default=func.now())

# Add to models.py

class GovernmentJob(Base):
    __tablename__ = "government_jobs"

    job_id = Column(Integer, primary_key=True)
    title = Column(String(200), nullable=False)
    department = Column(String(150))
    organization = Column(String(150))
    qualification = Column(String(200))         # e.g., "10th Pass", "B.Tech", "Any Graduate"
    age_limit_min = Column(Integer, default=18)
    age_limit_max = Column(Integer, default=40)
    salary_range = Column(String(100))          # e.g., "₹25,000 - ₹1,00,000"
    location = Column(String(150))
    state = Column(String(100))
    exam_type = Column(String(100))             # e.g., "SSC", "UPSC", "Banking", "Railway"
    vacancies = Column(Integer)
    apply_link = Column(String(500))
    description = Column(Text)
    eligibility = Column(Text)
    exam_pattern = Column(Text)
    syllabus_link = Column(String(500))
    posted_date = Column(TIMESTAMP, server_default=func.now())
    last_date = Column(TIMESTAMP)
    is_active = Column(Boolean, default=True)


class PrivateJob(Base):
    __tablename__ = "private_jobs"

    job_id = Column(Integer, primary_key=True)
    title = Column(String(200), nullable=False)
    company = Column(String(150))
    industry = Column(String(100))              # e.g., "IT", "Finance", "EdTech"
    skills_required = Column(Text)              # comma-separated
    experience_min = Column(Integer, default=0)
    experience_max = Column(Integer, default=10)
    salary_min = Column(DECIMAL(12, 2))
    salary_max = Column(DECIMAL(12, 2))
    location = Column(String(150))
    job_type = Column(String(50))               # "Full-time", "Internship", "Remote"
    apply_link = Column(String(500))
    description = Column(Text)
    company_logo = Column(String(500))
    posted_date = Column(TIMESTAMP, server_default=func.now())
    last_date = Column(TIMESTAMP)
    is_active = Column(Boolean, default=True)


class JobBookmark(Base):
    __tablename__ = "job_bookmarks"

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.user_id"))
    job_id = Column(Integer)
    job_type = Column(Enum("government", "private"), nullable=False)
    created_at = Column(TIMESTAMP, server_default=func.now())
