# ai/discover_models.py
"""Discover what models your Groq API key has access to."""
import os
import sys
from dotenv import load_dotenv

load_dotenv()
GROQ_API_KEY = os.getenv("GROQ_API_KEY")

if not GROQ_API_KEY:
    print("❌ GROQ_API_KEY not set in .env")
    sys.exit(1)


def discover_models():
    """Query Groq's /models endpoint and return the list of accessible models."""
    try:
        from groq import Groq
        client = Groq(api_key=GROQ_API_KEY)

        print("🔍 Querying Groq for available models...\n")
        models = client.models.list()

        print(f"✅ Found {len(models.data)} models accessible to your account:\n")
        print("=" * 70)

        # Group by category
        categories = {
            "openai/": [],
            "meta-llama/": [],
            "groq/": [],
            "canopylabs/": [],
            "whisper": [],
            "qwen": [],
            "llama": [],
            "mixtral": [],
            "gemma": [],
            "other": [],
        }

        for m in models.data:
            mid = m.id
            matched = False
            for prefix in categories:
                if mid.startswith(prefix):
                    categories[prefix].append(mid)
                    matched = True
                    break
            if not matched:
                categories["other"].append(mid)

        # Print grouped
        for cat, items in categories.items():
            if items:
                print(f"\n📦 {cat}")
                for item in items:
                    print(f"   • {item}")

        print("\n" + "=" * 70)

        # Save to file for config.py to use
        with open("ai/discovered_models.txt", "w") as f:
            for m in models.data:
                f.write(m.id + "\n")

        print(f"\n� Saved list to ai/discovered_models.txt")
        print(f"\n💡 To use a model, copy its exact name into ai/config.py")
        return [m.id for m in models.data]

    except Exception as e:
        print(f"❌ Error: {e}")
        return []


if __name__ == "__main__":
    discover_models()
