# ai/ai_service.py
"""Unified AI Service using Groq with operation-specific models."""
from typing import Dict, List, Optional
import json
import re
import os
from ai.config import AIConfig


class AIService:
    def __init__(self, db=None):
        self.provider = AIConfig.AI_PROVIDER
        self.groq_client = None

        # Cache of verified-accessible models (auto-populated)
        self._verified_cache = None

        if AIConfig.USE_GROQ:
            try:
                from groq import Groq
                self.groq_client = Groq(api_key=AIConfig.GROQ_API_KEY)
                print("✅ Groq initialized (per-operation models)")
            except Exception as e:
                print(f"⚠️ Groq init failed: {e}")

    def _get_verified_models(self) -> set:
        """
        Query Groq's /models endpoint to get the list of models your key can use.
        Cached after first call.
        """
        if self._verified_cache is not None:
            return self._verified_cache

        if not self.groq_client:
            return set()

        try:
            models = self.groq_client.models.list()
            self._verified_cache = {m.id for m in models.data}
            return self._verified_cache
        except Exception as e:
            print(f"⚠️ Could not verify models: {e}")
            # Fall back to configured verified list
            return set(AIConfig.VERIFIED_MODELS)

    def _is_model_accessible(self, model: str) -> bool:
        """Check if a model is accessible (not in blocked list, ideally verified)."""
        if model in AIConfig.BLOCKED_MODELS:
            return False
        verified = self._get_verified_models()
        if not verified:
            return True  # can't verify, assume ok
        return model in verified

    # ============================================================
    # CORE: Call Groq with auto fallback
    # ============================================================
    def _call_groq_with_model(
        self,
        messages: List[Dict],
        model: str,
        temperature: float = None,
        max_tokens: int = None
    ) -> str:
        if not self.groq_client:
            raise Exception("Groq not available")

        # Build candidate list
        candidates = [model] + [m for m in AIConfig.GROQ_MODELS if m != model]
        candidates = [m for m in candidates if m not in AIConfig.BLOCKED_MODELS]

        # If we know which models are accessible, filter to those first
        verified = self._get_verified_models()
        if verified:
            accessible = [m for m in candidates if m in verified]
            unverified = [m for m in candidates if m not in verified]
            # Try accessible first, then unverified (might work even if /models doesn't list)
            candidates = accessible + unverified

        last_error = None
        for m in candidates:
            try:
                response = self.groq_client.chat.completions.create(
                    model=m,
                    messages=messages,
                    temperature=temperature if temperature is not None else AIConfig.AI_TEMPERATURE,
                    max_tokens=max_tokens or AIConfig.AI_MAX_TOKENS
                )
                # Success — cache this model as accessible
                if verified is not None:
                    verified.add(m)
                return response.choices[0].message.content
            except Exception as e:
                last_error = e
                err = str(e).lower()
                if any(token in err for token in ["403", "404", "400", "not found", "does not exist"]):
                    print(f"⚠️ Model {m} unavailable, trying next...")
                    continue
                raise e

        raise Exception(f"All Groq models failed. Last error: {last_error}")

    # ============================================================
    # �️ SAFETY: Input guard
    # ============================================================
    def guard_input(self, text: str) -> Dict:
        if not AIConfig.USE_GROQ or not AIConfig.ENABLE_INPUT_GUARD:
            return {"safe": True, "action": "allow", "model": "disabled"}

        try:
            response = self.groq_client.chat.completions.create(
                model=AIConfig.MODEL_PROMPT_GUARD,
                messages=[{"role": "user", "content": text}],
                max_tokens=20,
                temperature=0.0
            )
            raw = response.choices[0].message.content.strip()
            try:
                score = float(raw)
                is_safe = score < 0.5
            except ValueError:
                is_safe = "UNSAFE" not in raw.upper()

            return {
                "safe": is_safe,
                "raw": raw,
                "action": "allow" if is_safe else "block",
                "model": AIConfig.MODEL_PROMPT_GUARD
            }
        except Exception as e:
            print(f"Prompt guard error: {e}")
            return {"safe": True, "action": "allow", "error": str(e)}

    # ============================================================
    # 🛡️ SAFETY: Output safeguard
    # ============================================================
    def safeguard_output(self, text: str) -> Dict:
        if not AIConfig.USE_GROQ or not AIConfig.ENABLE_OUTPUT_SAFEGUARD:
            return {"safe": True, "action": "allow", "model": "disabled"}

        try:
            response = self.groq_client.chat.completions.create(
                model=AIConfig.MODEL_SAFEGUARD,
                messages=[
                    {"role": "system", "content": "You are a safety classifier. Respond with ONLY 'SAFE' or 'UNSAFE: <reason>'."},
                    {"role": "user", "content": text[:4000]}
                ],
                max_tokens=50,
                temperature=0.0
            )
            raw = response.choices[0].message.content.strip()
            is_safe = raw.upper().startswith("SAFE")
            return {
                "safe": is_safe,
                "raw": raw,
                "action": "allow" if is_safe else "block",
                "model": AIConfig.MODEL_SAFEGUARD
            }
        except Exception as e:
            print(f"Safeguard error: {e}")
            return {"safe": True, "action": "allow", "error": str(e)}

    # ============================================================
    # 🎙️ AUDIO: STT
    # ============================================================
    def transcribe_audio(self, audio_file_path: str, language: str = "en", model: str = None) -> Dict:
        if not AIConfig.USE_GROQ:
            return {"text": "", "error": "Groq not available"}

        chosen_model = model or AIConfig.MODEL_STT
        try:
            with open(audio_file_path, "rb") as f:
                transcription = self.groq_client.audio.transcriptions.create(
                    file=(os.path.basename(audio_file_path), f.read()),
                    model=chosen_model,
                    language=language,
                    response_format="verbose_json"
                )
            return {
                "text": transcription.text,
                "language": getattr(transcription, "language", language),
                "duration": getattr(transcription, "duration", None),
                "model": chosen_model
            }
        except Exception as e:
            print(f"STT error: {e}")
            return {"text": "", "error": str(e), "model": chosen_model}

    # ============================================================
    # 🔊 AUDIO: TTS
    # ============================================================
    def text_to_speech(self, text: str, voice: str = None, language: str = "english") -> Dict:
        if not AIConfig.USE_GROQ:
            return {"error": "Groq not available"}

        chosen_voice = voice or AIConfig.DEFAULT_VOICE
        chosen_model = (
            AIConfig.MODEL_TTS_ARABIC if language.lower() in ("ar", "arabic", "arab")
            else AIConfig.MODEL_TTS
        )

        try:
            response = self.groq_client.chat.completions.create(
                model=chosen_model,
                messages=[
                    {"role": "system", "content": f"Speak the user's text using the '{chosen_voice}' voice. Output audio only."},
                    {"role": "user", "content": text}
                ]
            )
            return {
                "audio": getattr(response.choices[0].message, "audio", None),
                "text": text,
                "voice": chosen_voice,
                "model": chosen_model
            }
        except Exception as e:
            print(f"TTS error: {e}")
            return {"error": str(e), "model": chosen_model}

    # ============================================================
    # 1. 💬 CHAT
    # ============================================================
    def chat(self, message: str, history: List[Dict] = None, user_context: Dict = None) -> Dict:
        if not AIConfig.USE_GROQ:
            return self._fallback_chat(message)

        guard_result = self.guard_input(message)
        if not guard_result.get("safe", True):
            return {
                "response": "⚠️ Your message was flagged by our safety system. Please rephrase your question.",
                "powered_by": "Groq",
                "model": AIConfig.MODEL_CHAT,
                "blocked_by": "prompt_guard"
            }

        try:
            from ai.prompts import SYSTEM_PROMPT_CAREER_GUIDE
            system = SYSTEM_PROMPT_CAREER_GUIDE
            if user_context:
                system += f"\n\nStudent Info: {user_context.get('name', 'Student')}, {user_context.get('degree', 'N/A')} in {user_context.get('department', 'N/A')}"

            messages = [{"role": "system", "content": system}]
            for msg in (history or [])[-AIConfig.MAX_CONVERSATION_HISTORY:]:
                messages.append(msg)
            messages.append({"role": "user", "content": message})

            response = self._call_groq_with_model(
                messages, model=AIConfig.MODEL_CHAT, temperature=0.7, max_tokens=1200
            )

            safe_result = self.safeguard_output(response)
            if not safe_result.get("safe", True):
                response = "I cannot provide that response. Let's talk about your career goals instead! 🎯"

            return {
                "response": response,
                "powered_by": "Groq",
                "model": AIConfig.MODEL_CHAT,
                "safeguard": safe_result
            }
        except Exception as e:
            print(f"AI chat error: {e}")
            return self._fallback_chat(message)

    def _fallback_chat(self, message: str) -> Dict:
        msg = message.lower()
        responses = {
            ("hi", "hello", "hey"): "Hello! 👋 I'm your AI career counselor. How can I help?",
            ("career", "job"): "Tell me about your skills and interests!",
            ("skill", "learn"): "Start with fundamentals, practice daily, build projects!",
            ("interview",): "Practice DSA, prepare STAR stories, do mock interviews.",
            ("resume", "cv"): "Keep it 1 page, use action verbs, quantify achievements.",
            ("salary",): "Depends on location and skills. Tech freshers: 3-8 LPA.",
            ("roadmap",): "6-month roadmap: Foundation → Intermediate → Advanced + Job Prep.",
        }
        for keys, resp in responses.items():
            if any(k in msg for k in keys):
                return {"response": resp, "powered_by": "Fallback", "model": "fallback", "intent": keys[0]}
        return {"response": "I can help with career, skills, interviews, and resumes!", "powered_by": "Fallback", "model": "fallback", "intent": "general"}

    # ============================================================
    # 2. 🎯 RECOMMENDATIONS
    # ============================================================
    def get_recommendations(self, user_skills: List[str], top_n: int = 5, careers: List[Dict] = None) -> List[Dict]:
        if not AIConfig.USE_GROQ or not careers:
            return self._fallback_recommendations_simple(careers, top_n)

        try:
            career_info = "\n".join([
                f"- {c['career_name']}: {c.get('description', '')[:100]}"
                for c in careers[:15]
            ])

            prompt = f"""Based on these user skills: {', '.join(user_skills) or 'None'}

Rank the top {top_n} careers and return ONLY a JSON array (no markdown):

[{{"career_name": "exact name", "match_percentage": 85, "explanation": "brief reason"}}]

Available careers:
{career_info}

Return ONLY JSON."""

            messages = [
                {"role": "system", "content": "You are a JSON API. Return valid JSON only, no markdown."},
                {"role": "user", "content": prompt}
            ]
            response = self._call_groq_with_model(
                messages, model=AIConfig.MODEL_RECOMMENDATIONS, temperature=0.3, max_tokens=1200
            )
            return self._parse_recommendations(response, careers, top_n, AIConfig.MODEL_RECOMMENDATIONS)
        except Exception as e:
            print(f"AI recommendations error: {e}")
            return self._fallback_recommendations_simple(careers, top_n)

    def _parse_recommendations(self, text, careers, top_n, model):
        text = text.strip()
        text = re.sub(r'```json\s*', '', text)
        text = re.sub(r'```\s*', '', text)
        start, end = text.find('['), text.rfind(']')
        json_text = text[start:end + 1] if start != -1 and end != -1 else text

        try:
            ai_recs = json.loads(json_text)
        except json.JSONDecodeError:
            try:
                ai_recs = json.loads(re.sub(r',(\s*[}\]])', r'\1', json_text))
            except json.JSONDecodeError:
                return self._fallback_recommendations_simple(careers, top_n)

        if not isinstance(ai_recs, list):
            return self._fallback_recommendations_simple(careers, top_n)

        results = []
        for rec in ai_recs[:top_n]:
            if not isinstance(rec, dict):
                continue
            career_name = rec.get("career_name", "").strip()
            if not career_name:
                continue
            career = next((c for c in careers if c["career_name"].lower() == career_name.lower()), None)
            if career:
                results.append({
                    "career_id": career["career_id"],
                    "career_name": career["career_name"],
                    "description": career.get("description"),
                    "average_salary": career.get("average_salary"),
                    "match_percentage": float(rec.get("match_percentage", 50)),
                    "ai_explanation": rec.get("explanation", "Good match based on your skills."),
                    "powered_by": "Groq",
                    "model": model
                })
        return results if results else self._fallback_recommendations_simple(careers, top_n)

    def _fallback_recommendations(self, user_skills, careers, top_n):
        if not careers:
            return []
        user_skills_lower = [s.lower() for s in user_skills]
        scored = []
        for career in careers:
            desc = (career.get("description", "") or "").lower()
            matches = sum(1 for s in user_skills_lower if s in desc)
            score = min(50 + (matches * 10), 95)
            scored.append({
                "career_id": career["career_id"],
                "career_name": career["career_name"],
                "description": career.get("description"),
                "average_salary": career.get("average_salary"),
                "match_percentage": float(score),
                "ai_explanation": f"Match: {int(score)}%. {matches} skills found."
            })
        scored.sort(key=lambda x: x["match_percentage"], reverse=True)
        return scored[:top_n]

    def _fallback_recommendations_simple(self, careers, top_n):
        results = []
        for i, career in enumerate(careers[:top_n] if careers else []):
            results.append({
                "career_id": career["career_id"],
                "career_name": career["career_name"],
                "description": career.get("description"),
                "average_salary": career.get("average_salary"),
                "match_percentage": float(90 - (i * 5)),
                "ai_explanation": f"{career['career_name']} is a great career option.",
                "powered_by": "Fallback",
                "model": "fallback"
            })
        return results

    # ============================================================
    # 3. 📊 SKILL GAP
    # ============================================================
    def analyze_skill_gap(self, user_skills, career_name, required_skills=None):
        gap = {"matched_skills": user_skills, "missing_skills": required_skills or []}
        if not AIConfig.USE_GROQ:
            return {"gap_analysis": gap, "ai_advice": self._fallback_skill_advice(career_name)}

        try:
            prompt = f"""Skill gap analysis for {career_name}.
User skills: {', '.join(user_skills) or 'None'}
Required: {', '.join(required_skills or [])}

Provide:
1. Match percentage (0-100)
2. Top 3 critical missing skills
3. 90-day learning plan (3 bullets)
4. Free learning resources

Keep it under 300 words, friendly tone."""

            response = self._call_groq_with_model(
                [{"role": "user", "content": prompt}],
                model=AIConfig.MODEL_SKILL_GAP, temperature=0.6, max_tokens=700
            )
            return {"gap_analysis": gap, "ai_advice": response, "model": AIConfig.MODEL_SKILL_GAP}
        except Exception:
            return {"gap_analysis": gap, "ai_advice": self._fallback_skill_advice(career_name)}

    def _fallback_skill_advice(self, career_name):
        return f"""🎯 {career_name} Path:

📚 90-Day Plan:
- Month 1: Foundations + 2 mini projects
- Month 2: Deep dive + substantial projects
- Month 3: Portfolio + networking

💡 Resources: YouTube, freeCodeCamp, Coursera, LeetCode

🚀 You've got this!"""

    # ============================================================
    # 4. �️ ROADMAP
    # ============================================================
    def generate_roadmap(self, career_name, current_skills=None, education="Bachelor's", hours_per_day=2):
        if not AIConfig.USE_GROQ:
            return self._fallback_roadmap(career_name, hours_per_day)

        try:
            from ai.prompts import ROADMAP_GENERATION_PROMPT
            prompt = ROADMAP_GENERATION_PROMPT.format(
                career_name=career_name,
                current_skills=", ".join(current_skills or []) or "None",
                education=education,
                hours_per_day=hours_per_day
            )
            response = self._call_groq_with_model(
                [{"role": "user", "content": prompt}],
                model=AIConfig.MODEL_ROADMAP, temperature=0.7, max_tokens=2500
            )
            return response
        except Exception:
            return self._fallback_roadmap(career_name, hours_per_day)

    def _fallback_roadmap(self, career_name, hours_per_day):
        return f"""# 6-Month Roadmap for {career_name}

## Month 1-2: Foundation
- Core fundamentals
- 2 mini projects
- Daily: {hours_per_day} hours

## Month 3-4: Intermediate
- Advanced topics
- 2-3 substantial projects

## Month 5-6: Advanced & Job Prep
- Specialize
- Portfolio site
- Practice DSA
- Apply to jobs

🚀 Stay consistent!"""

    # ============================================================
    # 5. 📝 APTITUDE QUESTIONS
    # ============================================================
    def generate_aptitude_questions(self, user_skills=None, career_focus="general", previous_questions=None, num_questions=20):
        if not AIConfig.USE_GROQ:
            return self._fallback_aptitude_questions(num_questions)

        try:
            from ai.prompts import APTITUDE_QUESTIONS_PROMPT
            prev_q = "\n".join([f"- {q}" for q in (previous_questions or [])[:50]]) or "None"
            prompt = APTITUDE_QUESTIONS_PROMPT.format(
                num_questions=num_questions,
                career_focus=career_focus,
                user_skills=", ".join(user_skills or []) or "Not specified",
                previous_questions=prev_q
            )

            messages = [
                {"role": "system", "content": "Generate aptitude questions. Follow exact format. Be concise."},
                {"role": "user", "content": prompt}
            ]
            response = self._call_groq_with_model(
                messages, model=AIConfig.MODEL_APTITUDE, temperature=0.9, max_tokens=4000
            )
            return self._parse_aptitude_questions(response)
        except Exception as e:
            print(f"AI aptitude error: {e}")
            return self._fallback_aptitude_questions(num_questions)

    def _parse_aptitude_questions(self, text):
        questions = []
        text = text.strip()
        pattern = r'Q\s*(\d+)\s*:\s*(.+?)(?=Q\s*\d+\s*:|$)'
        matches = re.findall(pattern, text, re.DOTALL | re.IGNORECASE)

        if not matches:
            for block in text.split('\n\n'):
                if 'Q' in block[:5] and ':' in block[:5]:
                    q = self._parse_single_question(block)
                    if q:
                        questions.append(q)
        else:
            for _, content in matches:
                q = self._parse_single_question(content)
                if q:
                    questions.append(q)

        return questions if questions else self._fallback_aptitude_questions(20)

    def _parse_single_question(self, block):
        lines = block.strip().split('\n')
        q_text, options, answer, category, difficulty, explanation = "", {}, "", "General", "Medium", ""

        for line in lines:
            line = line.strip()
            if not line: continue
            if not q_text and not re.match(r'^[A-D]\)', line) and not any(line.startswith(p) for p in ['ANSWER', 'CATEGORY', 'DIFFICULTY', 'EXPLANATION']):
                q_text = line
                continue
            if re.match(r'^A\)', line): options['A'] = line[2:].strip()
            elif re.match(r'^B\)', line): options['B'] = line[2:].strip()
            elif re.match(r'^C\)', line): options['C'] = line[2:].strip()
            elif re.match(r'^D\)', line): options['D'] = line[2:].strip()
            if line.startswith('ANSWER:'): answer = line.replace('ANSWER:', '').strip().upper()[:1]
            if line.startswith('CATEGORY:'): category = line.replace('CATEGORY:', '').strip()
            if line.startswith('DIFFICULTY:'): difficulty = line.replace('DIFFICULTY:', '').strip()
            if line.startswith('EXPLANATION:'): explanation = line.replace('EXPLANATION:', '').strip()

        if q_text and len(options) == 4 and answer in ['A', 'B', 'C', 'D']:
            return {
                "question": q_text, "options": [options['A'], options['B'], options['C'], options['D']],
                "answer": ord(answer) - ord('A'), "category": category, "difficulty": difficulty, "explanation": explanation
            }
        return None

    def _fallback_aptitude_questions(self, n):
        pool = [
            {"question": "Next: 2, 6, 12, 20, 30, ?", "options": ["40", "42", "44", "46"], "answer": 1, "category": "Quantitative", "difficulty": "Easy", "explanation": "n(n+1)"},
            {"question": "Missing: 4, 9, 16, 25, ?", "options": ["30", "32", "36", "49"], "answer": 2, "category": "Logical", "difficulty": "Easy", "explanation": "Squares"},
            {"question": "15% of 240?", "options": ["30", "32", "36", "40"], "answer": 2, "category": "Quantitative", "difficulty": "Easy", "explanation": "0.15*240"},
            {"question": "Bird:Fly :: Fish:?", "options": ["Swim", "Walk", "Crawl", "Jump"], "answer": 0, "category": "Verbal", "difficulty": "Easy", "explanation": "Transport"},
            {"question": "Fibonacci: 1, 1, 2, 3, 5, 8, ?", "options": ["11", "12", "13", "14"], "answer": 2, "category": "Logical", "difficulty": "Medium", "explanation": "Sum"},
            {"question": "Seconds in 2 hours?", "options": ["3600", "7200", "10800", "14400"], "answer": 1, "category": "Quantitative", "difficulty": "Easy", "explanation": "2*3600"},
            {"question": "Synonym HAPPY?", "options": ["Sad", "Joyful", "Angry", "Tired"], "answer": 1, "category": "Verbal", "difficulty": "Easy", "explanation": "Same meaning"},
            {"question": "Odd: 3, 5, 7, 11, 14, 17", "options": ["5", "11", "14", "17"], "answer": 2, "category": "Logical", "difficulty": "Medium", "explanation": "14 not prime"},
            {"question": "x+y=10, x-y=4, x*y=?", "options": ["20", "21", "24", "25"], "answer": 1, "category": "Quantitative", "difficulty": "Medium", "explanation": "x=7,y=3"},
            {"question": "25% of 25% of 400?", "options": ["20", "25", "30", "35"], "answer": 1, "category": "Quantitative", "difficulty": "Medium", "explanation": "0.25*0.25*400"},
        ]
        return pool[:min(n, len(pool))] * (n // len(pool) + 1)

    # ============================================================
    # 6. 🎤 INTERVIEW QUESTIONS
    # ============================================================
    def generate_interview_questions(self, career_name, num=10):
        if not AIConfig.USE_GROQ:
            return self._fallback_interview_questions(career_name)
        try:
            from ai.prompts import INTERVIEW_QUESTIONS_PROMPT
            prompt = INTERVIEW_QUESTIONS_PROMPT.format(career_name=career_name)
            response = self._call_groq_with_model(
                [{"role": "user", "content": prompt}],
                model=AIConfig.MODEL_INTERVIEW, temperature=0.7, max_tokens=2000
            )
            return self._parse_interview_questions(response, career_name)
        except Exception as e:
            print(f"Interview Qs error: {e}")
            return self._fallback_interview_questions(career_name)

    def _parse_interview_questions(self, text, career_name):
        questions = []
        pattern = r'(?:^|\n)\s*(?:\d+[\.\)]\s*|Q\d*[:\.\)]\s*)(.+?)(?=(?:\n\s*(?:\d+[\.\)]\s*|Q\d*[:\.\)]|$)))'
        matches = re.findall(pattern, text, re.DOTALL)
        if not matches:
            return [{"question_id": "q1", "question": text.strip(), "category": "Mixed", "difficulty": "Medium", "hint": "Use the STAR method."}]

        for i, m in enumerate(matches, 1):
            questions.append({
                "question_id": f"q{i}",
                "question": m.strip().split('\n')[0],
                "category": "Mixed", "difficulty": "Medium",
                "hint": "Structure your answer using STAR (Situation, Task, Action, Result)."
            })
        return questions

    def _fallback_interview_questions(self, career_name):
        return [
            {"question_id": "q1", "question": f"What interests you about being a {career_name}?", "category": "Behavioral", "difficulty": "Easy", "hint": "Be genuine and specific."},
            {"question_id": "q2", "question": "Tell me about a challenging project.", "category": "Behavioral", "difficulty": "Medium", "hint": "Use the STAR method."},
            {"question_id": "q3", "question": "Where do you see yourself in 5 years?", "category": "HR", "difficulty": "Easy", "hint": "Show ambition aligned with the role."},
            {"question_id": "q4", "question": "What are your strengths?", "category": "HR", "difficulty": "Easy", "hint": "Back them with examples."},
            {"question_id": "q5", "question": "Why should we hire you?", "category": "HR", "difficulty": "Medium", "hint": "Connect your strengths to the role."},
        ]

    def generate_interview_questions_for_career(self, career_name, num_questions=10, difficulty="Medium"):
        return self.generate_interview_questions(career_name, num_questions)

    # ============================================================
    # 7. �️ EVALUATION
    # ============================================================
    def evaluate_interview_answer(self, question, answer, category, career_name):
        if not AIConfig.USE_GROQ:
            return self._fallback_evaluate()

        try:
            prompt = f"""Evaluate this interview answer for a {career_name} role.
Category: {category}

Question: {question}

Candidate's Answer: {answer}

Provide a JSON response with:
- score: 0-100 integer
- feedback: 1-2 sentence summary
- strengths: array of 2-3 short bullet points
- improvements: array of 2-3 actionable suggestions
- sample_answer: 1-2 sentence example

Return ONLY valid JSON, no markdown."""

            messages = [
                {"role": "system", "content": "You are an expert interview coach. Return only valid JSON."},
                {"role": "user", "content": prompt}
            ]
            response = self._call_groq_with_model(
                messages, model=AIConfig.MODEL_EVAL, temperature=0.4, max_tokens=700
            )
            return self._parse_evaluation(response)
        except Exception as e:
            print(f"Eval error: {e}")
            return self._fallback_evaluate()

    def _parse_evaluation(self, text):
        text = text.strip()
        text = re.sub(r'```json\s*', '', text)
        text = re.sub(r'```\s*', '', text)
        start, end = text.find('{'), text.rfind('}')
        if start != -1 and end != -1:
            text = text[start:end+1]
        try:
            data = json.loads(text)
            return {
                "score": int(data.get("score", 75)),
                "feedback": data.get("feedback", "Good answer overall."),
                "strengths": data.get("strengths", ["Clear communication"]),
                "improvements": data.get("improvements", ["Add more specific examples"]),
                "sample_answer": data.get("sample_answer", "")
            }
        except Exception:
            return self._fallback_evaluate()

    def _fallback_evaluate(self):
        return {
            "score": 75,
            "feedback": "Good answer. Consider adding more specific examples using the STAR method.",
            "strengths": ["Clear communication", "Relevant content"],
            "improvements": ["Add quantifiable results", "Provide more specific examples"],
            "sample_answer": ""
        }

    def generate_interview_overall_feedback(self, career_name, answers, average_score):
        if not AIConfig.USE_GROQ:
            return f"Overall score: {average_score:.1f}. Keep practicing!"
        try:
            summary = "\n".join([f"Q: {a.get('question','')[:80]}\nA: {a.get('answer','')[:200]}" for a in answers[:5]])
            prompt = f"""Provide an overall interview performance summary for a {career_name} role.
Average score: {average_score:.1f}/100

Sample answers:
{summary}

Write a 3-4 sentence encouraging summary."""
            response = self._call_groq_with_model(
                [{"role": "user", "content": prompt}],
                model=AIConfig.MODEL_EVAL, temperature=0.6, max_tokens=400
            )
            return response
        except Exception:
            return f"Overall score: {average_score:.1f}. Keep practicing and review your weaker areas."

    def generate_interview_recommendations(self, career_name, average_score, category_scores):
        if not AIConfig.USE_GROQ:
            return self._fallback_interview_recommendations(career_name)
        try:
            weak = sorted(category_scores.items(), key=lambda x: x[1].get("average", 0))[:2]
            weak_cats = ", ".join([w[0] for w in weak]) or "general interview skills"
            prompt = f"""Provide 5 specific, actionable recommendations to improve {career_name} interview performance.
Focus on these weakest categories: {weak_cats}.
Average score: {average_score:.1f}/100.

Return as a numbered list (1. 2. 3. 4. 5.). Be specific. Under 200 words."""
            response = self._call_groq_with_model(
                [{"role": "user", "content": prompt}],
                model=AIConfig.MODEL_EVAL, temperature=0.7, max_tokens=400
            )
            lines = [l.strip() for l in response.split('\n') if l.strip() and (l.strip()[0].isdigit() or l.strip().startswith('-'))]
            cleaned = [re.sub(r'^\d+[\.\)]\s*', '', l).lstrip('- ').strip() for l in lines]
            return cleaned[:5] if cleaned else self._fallback_interview_recommendations(career_name)
        except Exception:
            return self._fallback_interview_recommendations(career_name)

    def _fallback_interview_recommendations(self, career_name):
        return [
            f"Practice {career_name} interview questions daily using mock interviews",
            "Record yourself and review for clarity, filler words, and pace",
            "Prepare 5 STAR method stories covering different competencies",
            "Research the company and role thoroughly before each interview",
            "Take online courses to strengthen weak technical areas"
        ]

    # ============================================================
    # 8. 📄 RESUME
    # ============================================================
    def analyze_resume(self, resume_text, target_career, user_skills=None, education="N/A"):
        if not AIConfig.USE_GROQ:
            return f"Resume Review for {target_career}: 1) Use action verbs 2) Quantify achievements 3) Tailor to job 4) Add projects 5) Keep to 1 page"
        try:
            from ai.prompts import RESUME_ANALYSIS_PROMPT
            prompt = RESUME_ANALYSIS_PROMPT.format(
                target_career=target_career,
                skills=", ".join(user_skills or []),
                education=education,
                resume_text=resume_text
            )
            response = self._call_groq_with_model(
                [{"role": "user", "content": prompt}],
                model=AIConfig.MODEL_RESUME, temperature=0.5, max_tokens=1200
            )
            return response
        except Exception:
            return "Failed to analyze resume."

    # ============================================================
    # 9. 📚 COURSES — uses openai/gpt-oss-20b (was qwen, now broken)
    # ============================================================
    def recommend_courses(self, skill_name, current_level="Beginner", hours_per_week=5, budget="Free"):
        if not AIConfig.USE_GROQ:
            return f"Resources for {skill_name}: YouTube, freeCodeCamp, Coursera, Udemy, LeetCode"
        try:
            from ai.prompts import COURSE_RECOMMENDATION_PROMPT
            prompt = COURSE_RECOMMENDATION_PROMPT.format(
                skill_name=skill_name,
                current_level=current_level,
                hours_per_week=hours_per_week,
                budget=budget
            )
            response = self._call_groq_with_model(
                [{"role": "user", "content": prompt}],
                model=AIConfig.MODEL_COURSES, temperature=0.6, max_tokens=800
            )
            return response
        except Exception:
            return f"Failed to get course recommendations for {skill_name}."

    # ============================================================
    # 10. Generic content generation
    # ============================================================
    def generate_content(self, prompt, system_instruction=None, temperature=0.7, max_tokens=1500, model=None):
        if not AIConfig.USE_GROQ:
            return '{"error": "AI not available"}'
        messages = []
        if system_instruction:
            messages.append({"role": "system", "content": system_instruction})
        messages.append({"role": "user", "content": prompt})
        return self._call_groq_with_model(
            messages, model=model or AIConfig.MODEL_DEFAULT,
            temperature=temperature, max_tokens=max_tokens
        )
