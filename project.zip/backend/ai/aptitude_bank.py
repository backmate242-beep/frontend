# ai/aptitude_bank.py
from ai.ai_service import AIService
from ai.config import AIConfig
import json


class AptitudeTestGenerator:
    def __init__(self):
        self.ai_service = AIService()

    def generate_test(self, topic: str, difficulty: str = "Medium") -> dict:
        prompt = (
            f"Generate 5 multiple-choice questions (MCQs) for a {difficulty} level aptitude and technical test on {topic}. "
            "Return the output strictly in JSON format with fields: question, options (list of 4), correct_answer, and explanation."
        )
        system_instruction = "You are an automated technical assessment generator. Return valid JSON only with no markdown wrapping."
        response_text = self.ai_service.generate_content(
            prompt=prompt,
            system_instruction=system_instruction,
            model=AIConfig.MODEL_APTITUDE,  # openai/gpt-oss-20b
            temperature=0.7,
            max_tokens=1500
        )
        try:
            cleaned_json = response_text.replace("```json", "").replace("```", "").strip()
            return json.loads(cleaned_json)
        except Exception:
            return {"raw_output": response_text}
