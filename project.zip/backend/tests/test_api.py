import sys
from pathlib import Path

# Add backend directory to Python path
BACKEND_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BACKEND_DIR))

from main import app


def test_application_exists():
    assert app is not None


def test_application_has_routes():
    routes = app.routes

    assert len(routes) > 0