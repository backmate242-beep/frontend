import sys
from pathlib import Path

# Add backend directory to Python path
BACKEND_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BACKEND_DIR))

import schemas


def test_schema_module_loads():
    assert schemas is not None


def test_schema_module_contains_classes():
    schema_names = [
        name
        for name in dir(schemas)
        if not name.startswith("_")
    ]

    assert len(schema_names) > 0