import sys
from pathlib import Path

# Get the backend directory
BACKEND_DIR = Path(__file__).resolve().parents[1]

# Add backend directory to Python import path
if str(BACKEND_DIR) not in sys.path:
    sys.path.insert(0, str(BACKEND_DIR))