import sys
from pathlib import Path

# Add backend directory to Python path
BACKEND_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BACKEND_DIR))

from utils import token


def test_token_module_loads():
    assert token is not None


def test_token_module_contains_functions():
    functions = [
        name
        for name in dir(token)
        if not name.startswith("_")
    ]

    assert len(functions) > 0