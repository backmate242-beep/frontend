import sys
from pathlib import Path

# Add backend directory to Python path
BACKEND_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BACKEND_DIR))

from ai import aptitude_bank


def test_aptitude_bank_loads():
    assert aptitude_bank is not None


def test_aptitude_bank_contains_content():
    attributes = dir(aptitude_bank)

    assert len(attributes) > 0