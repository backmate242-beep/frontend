import sys
from pathlib import Path

# Add the backend directory to Python path
BACKEND_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BACKEND_DIR))

from utils.hashing import hash_password, verify_password


def test_password_is_hashed():
    password = "Test@123"

    hashed_password = hash_password(password)

    assert hashed_password != password
    assert isinstance(hashed_password, str)
    assert len(hashed_password) > 0


def test_password_verification_success():
    password = "Test@123"

    hashed_password = hash_password(password)

    assert verify_password(password, hashed_password) is True


def test_password_verification_failure():
    password = "Test@123"
    wrong_password = "WrongPassword"

    hashed_password = hash_password(password)

    assert verify_password(wrong_password, hashed_password) is False


def test_different_hashes_are_generated():
    password = "Test@123"

    hash1 = hash_password(password)
    hash2 = hash_password(password)

    assert hash1 != hash2


def test_empty_password_can_be_hashed():
    password = ""

    hashed_password = hash_password(password)

    assert isinstance(hashed_password, str)
    assert verify_password(password, hashed_password) is True


def test_invalid_hash_returns_false():
    password = "Test@123"
    invalid_hash = "this-is-not-a-valid-bcrypt-hash"

    assert verify_password(password, invalid_hash) is False