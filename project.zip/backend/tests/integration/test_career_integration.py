import pytest
from httpx import AsyncClient, ASGITransport

from main import app


@pytest.mark.asyncio
async def test_career_modules_are_integrated():

    transport = ASGITransport(app=app)

    async with AsyncClient(
        transport=transport,
        base_url="http://test"
    ) as client:

        # Verify that the FastAPI application is running
        response = await client.get("/")

        assert response.status_code == 200

        # Get all registered API paths from OpenAPI
        routes = set(app.openapi()["paths"].keys())

        # Career endpoints
        assert "/careers/" in routes
        assert "/careers/{career_id}" in routes
        assert "/careers/{career_id}/skills" in routes