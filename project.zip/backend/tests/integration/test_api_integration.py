import sys
from pathlib import Path

import pytest
from httpx import ASGITransport, AsyncClient

# Add backend directory
BACKEND_DIR = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(BACKEND_DIR))

from main import app


@pytest.mark.asyncio
async def test_fastapi_application_integration():
    """
    Integration test:
    Test client -> FastAPI application -> routing
    """

    transport = ASGITransport(app=app)

    async with AsyncClient(
        transport=transport,
        base_url="http://test"
    ) as client:

        response = await client.get("/")

        assert response.status_code in [200, 404]


@pytest.mark.asyncio
async def test_invalid_api_route():
    """
    Test that FastAPI correctly handles
    an invalid endpoint.
    """

    transport = ASGITransport(app=app)

    async with AsyncClient(
        transport=transport,
        base_url="http://test"
    ) as client:

        response = await client.get("/invalid-test-endpoint")

        assert response.status_code == 404