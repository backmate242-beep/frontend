from main import app


def test_show_all_routes():
    print("\n\n========== REGISTERED ROUTES ==========")

    for route in app.routes:
        print(
            "TYPE:",
            type(route).__name__,
            "| PATH:",
            getattr(route, "path", "NO PATH"),
            "| NAME:",
            getattr(route, "name", "NO NAME")
        )

    print("=======================================\n")

    assert True