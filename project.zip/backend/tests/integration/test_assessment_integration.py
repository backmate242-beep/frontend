import pytest
from httpx import AsyncClient, ASGITransport

from main import app


@pytest.mark.asyncio
async def test_assessment_routes_are_available():

    transport = ASGITransport(app=app)

    async with AsyncClient(
        transport=transport,
        base_url="http://test"
    ) as client:

        # Verify that the FastAPI application is running
        response = await client.get("/")

        assert response.status_code == 200

        # FastAPI OpenAPI contains all registered router paths
        routes = set(app.openapi()["paths"].keys())

        # Assessment endpoints
        assert "/assessments/" in routes
        assert "/assessments/me" in routes