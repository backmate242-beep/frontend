"""
Database connection configuration.
Supports both individual variables and full URL format.
"""
from sqlalchemy import create_engine
from sqlalchemy.orm import declarative_base, sessionmaker
from dotenv import load_dotenv
import os
import logging

# Load environment variables from .env file
load_dotenv()

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


# ==================== METHOD 1: Build URL from individual vars ====================
def get_database_url() -> str:
    """Build database URL from environment variables."""
    
    # First, check if full DATABASE_URL is provided
    database_url = os.getenv("DATABASE_URL")
    if database_url:
        return database_url
    
    # Otherwise, build from individual variables
    db_user = os.getenv("DB_USER", "root")
    db_password = os.getenv("DB_PASSWORD", "")
    db_host = os.getenv("DB_HOST", "localhost")
    db_port = os.getenv("DB_PORT", "3306")
    db_name = os.getenv("DB_NAME", "ai_career_navigator")
    
    # Validate required fields
    if not db_password:
        raise ValueError(
            "❌ DB_PASSWORD is not set! "
            "Please set it in your .env file."
        )
    
    return f"mysql+pymysql://{db_user}:{db_password}@{db_host}:{db_port}/{db_name}"


# ==================== CREATE ENGINE ====================
try:
    DATABASE_URL = get_database_url()
    
    engine = create_engine(
        DATABASE_URL,
        pool_pre_ping=True,        # Verify connections before use
        pool_recycle=3600,         # Recycle connections every hour
        pool_size=10,              # Max 10 connections in pool
        max_overflow=20,           # Allow 20 extra connections
        echo=False                 # Set True to see SQL queries (debug only)
    )
    
    logger.info("✅ Database engine created successfully")
    
except Exception as e:
    logger.error(f"❌ Failed to create database engine: {e}")
    raise


# ==================== SESSION FACTORY ====================
SessionLocal = sessionmaker(
    autocommit=False,
    autoflush=False,
    bind=engine
)

# Base class for all models
Base = declarative_base()


# ==================== DEPENDENCY INJECTION ====================
def get_db():
    """
    FastAPI dependency that provides a database session.
    Automatically closes the session after the request.
    """
    db = SessionLocal()
    try:
        yield db
    except Exception as e:
        db.rollback()
        logger.error(f"Database error: {e}")
        raise
    finally:
        db.close()


# ==================== CONNECTION TEST ====================
def test_connection():
    """Test database connection. Run this to verify setup."""
    try:
        with engine.connect() as connection:
            from sqlalchemy import text
            connection.execute(text("SELECT 1"))
            logger.info("✅ Database connection successful!")
            return True
    except Exception as e:
        logger.error(f"❌ Database connection failed: {e}")
        return False


if __name__ == "__main__":
    # Run this file directly to test the connection
    test_connection()