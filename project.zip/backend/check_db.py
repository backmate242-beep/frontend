"""Quick test to verify all database operations work."""
from database import SessionLocal, test_connection
from models import Skill, Career, User, CareerSkill
from utils.hashing import hash_password, verify_password


def run_tests():
    print("🧪 Running database tests...\n")
    
    # Test 1: Connection
    print("Test 1: Connection")
    if not test_connection():
        print("❌ FAILED\n")
        return
    print("✅ PASSED\n")
    
    db = SessionLocal()
    try:
        # Test 2: Read skills
        print("Test 2: Read skills")
        skills = db.query(Skill).limit(5).all()
        print(f"   Found {len(skills)} skills:")
        for s in skills:
            print(f"   - {s.skill_name}")
        print("✅ PASSED\n")
        
        # Test 3: Read careers
        print("Test 3: Read careers")
        careers = db.query(Career).limit(5).all()
        print(f"   Found {len(careers)} careers:")
        for c in careers:
            print(f"   - {c.career_name} (₹{c.average_salary:,.0f})")
        print("✅ PASSED\n")
        
        # Test 4: Read career-skill mappings
        print("Test 4: Read career-skill relationships")
        mappings = db.query(CareerSkill).limit(5).all()
        print(f"   Found {len(mappings)} mappings")
        print("✅ PASSED\n")
        
        # Test 5: Create and read user
        print("Test 5: Create user")
        test_email = "test_connection@example.com"
        
        # Delete if exists
        existing = db.query(User).filter(User.email == test_email).first()
        if existing:
            db.delete(existing)
            db.commit()
        
        new_user = User(
            full_name="Test User",
            email=test_email,
            password=hash_password("test123"),
            role="student"
        )
        db.add(new_user)
        db.commit()
        db.refresh(new_user)
        
        # Verify
        found = db.query(User).filter(User.email == test_email).first()
        if found and verify_password("test123", found.password):
            print(f"   Created user: {found.full_name} (ID: {found.user_id})")
            print("✅ PASSED\n")
            
            # Cleanup
            db.delete(found)
            db.commit()
            print("   Test user cleaned up.\n")
        else:
            print("❌ FAILED: User not found or password mismatch\n")
        
        print("=" * 50)
        print("✅ All tests passed! Database is ready to use.")
        print("=" * 50)
        
    except Exception as e:
        print(f"\n❌ Test failed: {e}")
        db.rollback()
    finally:
        db.close()


if __name__ == "__main__":
    run_tests()
