# seed_jobs.py
"""Insert sample government job data."""
from database import SessionLocal
from models import GovernmentJob
from datetime import datetime, timedelta

db = SessionLocal()

sample_jobs = [
    {
        "title": "SSC CGL 2024 - Combined Graduate Level",
        "department": "Staff Selection Commission",
        "organization": "Government of India",
        "qualification": "Graduate",
        "age_limit_min": 18,
        "age_limit_max": 32,
        "salary_range": "₹25,500 - ₹1,51,100",
        "location": "All India",
        "state": "Central",
        "exam_type": "SSC",
        "vacancies": 17727,
        "apply_link": "https://ssc.nic.in",
        "description": "Combined Graduate Level Examination for various Group B and C posts in central government ministries.",
        "eligibility": "Bachelor's degree from recognized university. Age 18-32 (relaxation as per norms).",
        "exam_pattern": "Tier I (Objective), Tier II (Descriptive + Objective), Tier III (Descriptive), Tier IV (Skill Test).",
        "syllabus_link": "https://ssc.nic.in/syllabus",
        "last_date": datetime.utcnow() + timedelta(days=15)
    },
    {
        "title": "IBPS PO 2024 - Probationary Officer",
        "department": "Banking",
        "organization": "Institute of Banking Personnel Selection",
        "qualification": "Graduate",
        "age_limit_min": 20,
        "age_limit_max": 30,
        "salary_range": "�41,960 - ₹1,32,000",
        "location": "All India",
        "state": "Central",
        "exam_type": "Banking",
        "vacancies": 4455,
        "apply_link": "https://ibps.in",
        "description": "Probationary Officer recruitment in public sector banks.",
        "eligibility": "Any graduate with 60% marks. Age 20-30.",
        "exam_pattern": "Preliminary, Main, Interview.",
        "last_date": datetime.utcnow() + timedelta(days=7)
    },
    {
        "title": "UPSC CSE 2025 - Civil Services",
        "department": "UPSC",
        "organization": "Union Public Service Commission",
        "qualification": "Graduate",
        "age_limit_min": 21,
        "age_limit_max": 32,
        "salary_range": "₹56,100 - ₹2,50,000",
        "location": "All India",
        "state": "Central",
        "exam_type": "UPSC",
        "vacancies": 1056,
        "apply_link": "https://upsc.gov.in",
        "description": "Premier examination for IAS, IPS, IFS and other Group A services.",
        "eligibility": "Bachelor's degree. Age 21-32.",
        "exam_pattern": "Preliminary (Objective), Main (Descriptive), Interview.",
        "last_date": datetime.utcnow() + timedelta(days=30)
    },
    {
        "title": "RRB ALP 2024 - Assistant Loco Pilot",
        "department": "Railway",
        "organization": "Indian Railways",
        "qualification": "12th",
        "age_limit_min": 18,
        "age_limit_max": 30,
        "salary_range": "₹19,900 - ₹63,200",
        "location": "All India",
        "state": "Central",
        "exam_type": "Railway",
        "vacancies": 18799,
        "apply_link": "https://indianrailways.gov.in",
        "description": "Recruitment for Assistant Loco Pilot posts across zones.",
        "eligibility": "10th + ITI / Diploma / Degree in Engineering.",
        "exam_pattern": "CBT I, CBT II, Computer-Based Aptitude Test, Document Verification.",
        "last_date": datetime.utcnow() + timedelta(days=20)
    },
    {
        "title": "MPSC State Services 2024",
        "department": "Maharashtra Public Service Commission",
        "organization": "Government of Maharashtra",
        "qualification": "Graduate",
        "age_limit_min": 19,
        "age_limit_max": 38,
        "salary_range": "₹44,900 - ₹1,42,400",
        "location": "Maharashtra",
        "state": "Maharashtra",
        "exam_type": "State PSC",
        "vacancies": 480,
        "apply_link": "https://mpsc.gov.in",
        "description": "Combined competitive examination for state services in Maharashtra.",
        "eligibility": "Graduate, Marathi language proficiency, Maharashtra domicile.",
        "exam_pattern": "Prelims (Objective), Mains (Descriptive), Interview.",
        "last_date": datetime.utcnow() + timedelta(days=3)
    }
]

if db.query(GovernmentJob).count() == 0:
    for job_data in sample_jobs:
        db.add(GovernmentJob(**job_data))
    db.commit()
    print(f"✅ Inserted {len(sample_jobs)} government jobs")
else:
    print("⚠️  Government jobs already exist")

db.close()
