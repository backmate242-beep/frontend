"""
Initialize database - create all tables and insert sample data.
Run this once after creating the database.
"""
from database import engine, Base, SessionLocal, test_connection
from models import (
    User, Student, Skill, StudentSkill, Career,
    CareerSkill, CareerRecommendation, Course,
    Roadmap, Assessment, Notification, Bookmark
)
from utils.hashing import hash_password
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def create_tables():
    """Create all tables defined in models."""
    logger.info("🔨 Creating tables...")
    try:
        Base.metadata.create_all(bind=engine)
        logger.info("✅ All tables created successfully!")
        
        # Show created tables
        from sqlalchemy import inspect
        inspector = inspect(engine)
        tables = inspector.get_table_names()
        logger.info(f"📊 Total tables: {len(tables)}")
        for i, table in enumerate(tables, 1):
            logger.info(f"   {i}. {table}")
            
    except Exception as e:
        logger.error(f"❌ Failed to create tables: {e}")
        raise


def insert_sample_data():
    """Insert sample data for testing."""
    db = SessionLocal()
    try:
        # Check if data already exists
        if db.query(Skill).count() > 0:
            logger.info("⚠️  Sample data already exists. Skipping.")
            return
        
        logger.info("📝 Inserting sample data...")
        
        # Create default admin (password: admin123)
        admin = User(
            full_name="Admin User",
            email="admin@careernav.com",
            password=hash_password("admin123"),
            role="admin"
        )
        db.add(admin)
        
        # Sample skills
        skills_data = [
            "Python", "Java", "JavaScript", "SQL", "React",
            "HTML/CSS", "Machine Learning", "Data Analysis",
            "Communication", "Problem Solving", "Git", "Docker",
            "AWS", "Node.js", "Excel", "Tableau", "Project Management",
            "Leadership", "Critical Thinking", "Teamwork"
        ]
        
        for skill_name in skills_data:
            db.add(Skill(skill_name=skill_name))
        
        # Sample careers
        careers_data = [
            ("Software Engineer", "Designs, develops, and maintains software systems.", 850000.00, "B.Tech in CS/IT"),
            ("Data Scientist", "Analyzes complex data to drive decisions.", 950000.00, "B.Tech/Masters in CS"),
            ("Web Developer", "Builds and maintains websites and web apps.", 600000.00, "B.Tech/BCA"),
            ("Data Analyst", "Interprets data for business insights.", 700000.00, "B.Tech/BBA"),
            ("ML Engineer", "Builds and deploys ML models in production.", 1100000.00, "B.Tech/Masters"),
            ("DevOps Engineer", "Combines development and IT operations.", 900000.00, "B.Tech in CS/IT"),
            ("UI/UX Designer", "Designs user interfaces and experiences.", 750000.00, "Any Degree"),
            ("Product Manager", "Oversees product development lifecycle.", 1200000.00, "Any Degree"),
            ("Business Analyst", "Analyzes business needs and solutions.", 800000.00, "BBA/MBA"),
            ("Cloud Engineer", "Designs and manages cloud systems.", 950000.00, "B.Tech in CS/IT"),
        ]
        
        for name, desc, salary, degree in careers_data:
            db.add(Career(
                career_name=name,
                description=desc,
                average_salary=salary,
                required_degree=degree
            ))
        
        db.commit()
        logger.info("✅ Sample data inserted!")
        
        # Now add career-skill mappings (after commit to get IDs)
        skills = {s.skill_name: s.skill_id for s in db.query(Skill).all()}
        careers = {c.career_name: c.career_id for c in db.query(Career).all()}
        
        career_skill_map = [
            # Software Engineer
            ("Software Engineer", "Python", "High"),
            ("Software Engineer", "JavaScript", "High"),
            ("Software Engineer", "Git", "High"),
            ("Software Engineer", "Problem Solving", "High"),
            ("Software Engineer", "Teamwork", "Medium"),
            
            # Data Scientist
            ("Data Scientist", "Python", "High"),
            ("Data Scientist", "Machine Learning", "High"),
            ("Data Scientist", "Data Analysis", "High"),
            ("Data Scientist", "SQL", "Medium"),
            ("Data Scientist", "Teamwork", "Medium"),
            
            # Web Developer
            ("Web Developer", "JavaScript", "High"),
            ("Web Developer", "HTML/CSS", "High"),
            ("Web Developer", "Node.js", "Medium"),
            ("Web Developer", "Git", "Medium"),
            
            # Data Analyst
            ("Data Analyst", "SQL", "High"),
            ("Data Analyst", "Data Analysis", "High"),
            ("Data Analyst", "Excel", "High"),
            ("Data Analyst", "Tableau", "Medium"),
            
            # ML Engineer
            ("ML Engineer", "Python", "High"),
            ("ML Engineer", "Machine Learning", "High"),
            ("ML Engineer", "Data Analysis", "High"),
            ("ML Engineer", "Docker", "Medium"),
            
            # DevOps Engineer
            ("DevOps Engineer", "Docker", "High"),
            ("DevOps Engineer", "AWS", "High"),
            ("DevOps Engineer", "Git", "High"),
            ("DevOps Engineer", "Java", "Medium"),
            
            # UI/UX Designer
            ("UI/UX Designer", "HTML/CSS", "High"),
            ("UI/UX Designer", "Communication", "High"),
            ("UI/UX Designer", "Teamwork", "Medium"),
            
            # Product Manager
            ("Product Manager", "Communication", "High"),
            ("Product Manager", "Leadership", "High"),
            ("Product Manager", "Project Management", "High"),
            
            # Business Analyst
            ("Business Analyst", "SQL", "High"),
            ("Business Analyst", "Communication", "High"),
            ("Business Analyst", "Critical Thinking", "High"),
            ("Business Analyst", "Excel", "Medium"),
            
            # Cloud Engineer
            ("Cloud Engineer", "AWS", "High"),
            ("Cloud Engineer", "Docker", "High"),
            ("Cloud Engineer", "Python", "Medium"),
        ]
        
        for career_name, skill_name, importance in career_skill_map:
            db.add(CareerSkill(
                career_id=careers[career_name],
                skill_id=skills[skill_name],
                importance_level=importance
            ))
        
        # Sample courses
        courses_data = [
            ("Python for Everybody", "Coursera", "https://www.coursera.org/specializations/python", "Python"),
            ("JavaScript Complete Guide", "Udemy", "https://www.udemy.com/course/javascript-complete/", "JavaScript"),
            ("Machine Learning Specialization", "Coursera", "https://www.coursera.org/specializations/machine-learning", "Machine Learning"),
            ("SQL for Data Science", "Coursera", "https://www.coursera.org/learn/sql-for-data-science", "SQL"),
            ("React - The Complete Guide", "Udemy", "https://www.udemy.com/course/react-the-complete-guide/", "React"),
            ("AWS Certified Solutions Architect", "A Cloud Guru", "https://acloudguru.com/course/aws-certified-solutions-architect", "AWS"),
            ("Docker Mastery", "Udemy", "https://www.udemy.com/course/docker-mastery/", "Docker"),
            ("Data Analysis with Python", "freeCodeCamp", "https://www.freecodecamp.org/learn/data-analysis-with-python/", "Data Analysis"),
        ]
        
        for course_name, platform, link, skill_name in courses_data:
            db.add(Course(
                course_name=course_name,
                platform=platform,
                course_link=link,
                skill_id=skills[skill_name]
            ))
        
        # Sample roadmaps
        roadmap_data = [
            ("Software Engineer Roadmap 2024",
             "Month 1-2: Learn Python/Java, Git, Basic DSA\nMonth 3-4: Build 3 projects, Learn SQL\nMonth 5-6: Apply to internships, Practice DSA on LeetCode",
             "Software Engineer"),
            ("Data Scientist Roadmap",
             "Month 1-2: Python, Statistics, SQL\nMonth 3-4: ML Algorithms, Pandas, NumPy\nMonth 5-6: Kaggle Competitions, Build Portfolio",
             "Data Scientist"),
            ("Web Developer Roadmap",
             "Month 1-2: HTML, CSS, JavaScript basics\nMonth 3-4: React/Node.js, Build projects\nMonth 5-6: Deploy projects, Freelance",
             "Web Developer"),
        ]
        
        for title, desc, career_name in roadmap_data:
            db.add(Roadmap(
                career_id=careers[career_name],
                roadmap_title=title,
                roadmap_description=desc
            ))
        
        db.commit()
        logger.info("✅ All sample data inserted successfully!")
        
        # Summary
        logger.info("\n📊 Database Summary:")
        logger.info(f"   Users: {db.query(User).count()}")
        logger.info(f"   Skills: {db.query(Skill).count()}")
        logger.info(f"   Careers: {db.query(Career).count()}")
        logger.info(f"   Career-Skills: {db.query(CareerSkill).count()}")
        logger.info(f"   Courses: {db.query(Course).count()}")
        logger.info(f"   Roadmaps: {db.query(Roadmap).count()}")
        
    except Exception as e:
        logger.error(f"❌ Failed to insert data: {e}")
        db.rollback()
        raise
    finally:
        db.close()


if __name__ == "__main__":
    print("=" * 60)
    print("🚀 AI Career Navigator - Database Initialization")
    print("=" * 60)
    
    # Test connection first
    if not test_connection():
        print("\n❌ Connection failed! Check your .env settings.")
        print("   - Is MySQL running?")
        print("   - Is the database 'ai_career_navigator' created?")
        print("   - Are your .env credentials correct?")
        exit(1)
    
    # Create tables
    create_tables()
    
    # Insert sample data
    insert_sample_data()
    
    print("\n" + "=" * 60)
    print("✅ Database initialization complete!")
    print("=" * 60)
    print("\n📝 Default Admin Login:")
    print("   Email: admin@careernav.com")
    print("   Password: admin123")
    print("\n🚀 Now run: uvicorn main:app --reload")
