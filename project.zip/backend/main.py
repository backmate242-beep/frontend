from fastapi import FastAPI, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.exceptions import RequestValidationError
from starlette.exceptions import HTTPException as StarletteHTTPException
from sqlalchemy.exc import SQLAlchemyError
import logging
import time
from datetime import datetime

from database import engine
from models import Base
from routers import (
    auth, user, student, skill, career, course,
    roadmap, assessment, recommendation, ai,
    admin, dashboard, notifications, bookmarks,
    upload, assessment_quiz,ai_aptitude,mock_interview,government_jobs, 
)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[logging.FileHandler("app.log"), logging.StreamHandler()]
)
logger = logging.getLogger(__name__)

app = FastAPI(
    title="AI Career Navigator API",
    version="2.0.0",
    description="AI-powered career guidance platform"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.middleware("http")
async def log_requests(request: Request, call_next):
    start = time.time()
    response = await call_next(request)
    response.headers["X-Process-Time"] = str(time.time() - start)
    return response


@app.exception_handler(StarletteHTTPException)
async def http_handler(request: Request, exc: StarletteHTTPException):
    return JSONResponse(
        status_code=exc.status_code,
        content={"success": False, "error": {"code": exc.status_code, "message": exc.detail}}
    )


@app.exception_handler(RequestValidationError)
async def validation_handler(request: Request, exc: RequestValidationError):
    return JSONResponse(
        status_code=422,
        content={"success": False, "error": {"code": 422, "message": "Validation error", "details": exc.errors()}}
    )


@app.exception_handler(Exception)
async def general_handler(request: Request, exc: Exception):
    logger.error(f"Error: {str(exc)}", exc_info=True)
    return JSONResponse(
        status_code=500,
        content={"success": False, "error": {"code": 500, "message": "Internal server error"}}
    )


@app.on_event("startup")
async def startup():
    Base.metadata.create_all(bind=engine)
    logger.info("✅ Database tables ready")


# Register all routers
app.include_router(auth.router)
app.include_router(user.router)
app.include_router(student.router)
app.include_router(skill.router)
app.include_router(career.router)
app.include_router(course.router)
app.include_router(roadmap.router)
app.include_router(assessment.router)
app.include_router(recommendation.router)
app.include_router(ai.router)
app.include_router(admin.router)
app.include_router(dashboard.router)
app.include_router(notifications.router)
app.include_router(bookmarks.router)
app.include_router(upload.router)
app.include_router(assessment_quiz.router)
app.include_router(ai_aptitude.router)
app.include_router(mock_interview.router)
app.include_router(government_jobs.router)


@app.get("/")
def home():
    return {
        "message": "Welcome to AI Career Navigator API 🚀",
        "version": "2.0.0",
        "docs": "/docs"
    }


@app.get("/health")
def health():
    return {"status": "healthy", "timestamp": datetime.utcnow().isoformat()}
