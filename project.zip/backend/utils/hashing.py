"""Password hashing using bcrypt directly (no passlib needed)."""
import bcrypt


def hash_password(password: str) -> str:
    """Hash a plain text password using bcrypt."""
    # Convert string to bytes
    password_bytes = password.encode('utf-8')
    # Truncate to 72 bytes (bcrypt limit) just in case
    password_bytes = password_bytes[:72]
    # Generate salt and hash
    salt = bcrypt.gensalt()
    hashed = bcrypt.hashpw(password_bytes, salt)
    # Return as string for database storage
    return hashed.decode('utf-8')


def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Verify a plain password against the hashed one."""
    try:
        password_bytes = plain_password.encode('utf-8')[:72]
        hashed_bytes = hashed_password.encode('utf-8')
        return bcrypt.checkpw(password_bytes, hashed_bytes)
    except Exception:
        return False
