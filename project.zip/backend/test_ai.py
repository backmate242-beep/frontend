# test_ai.py
import os
import sys
from dotenv import load_dotenv

load_dotenv()
GROQ_API_KEY = os.getenv("GROQ_API_KEY")

print("=" * 60)
print("🚀 Groq Multi-Model Test Suite (FIXED v3)")
print("=" * 60 + "\n")

if not GROQ_API_KEY:
    print("❌ FATAL: GROQ_API_KEY not found")
    sys.exit(1)


def test_model(name, model, prompt, purpose, max_tokens=100):
    print(f"[{name}] Testing {purpose} ({model})...")
    try:
        from groq import Groq
        client = Groq(api_key=GROQ_API_KEY)
        response = client.chat.completions.create(
            model=model, messages=[{"role": "user", "content": prompt}],
            max_tokens=max_tokens
        )
        result = response.choices[0].message.content[:60]
        print(f"   ✅ OK: {result}...\n")
        return True
    except Exception as e:
        print(f"   ❌ Error: {str(e)[:100]}\n")
        return False


def discover_first():
    """Discover accessible models first."""
    print("🔍 Step 1: Discovering your accessible models...\n")
    try:
        from groq import Groq
        client = Groq(api_key=GROQ_API_KEY)
        models = client.models.list()
        ids = sorted([m.id for m in models.data])
        print(f"   ✅ Found {len(ids)} accessible models")
        # Save
        with open("ai/discovered_models.txt", "w") as f:
            for mid in ids:
                f.write(mid + "\n")
        return ids
    except Exception as e:
        print(f"   ❌ Discovery failed: {e}")
        return []


# Discover first
accessible = discover_first()
print()

# Run tests with verified-accessible models
print("--- Operation-specific models ---\n")
ok = []
ok.append(test_model("1/8", "openai/gpt-oss-120b", "Say 'Chat works' in 3 words", "CHAT"))
ok.append(test_model("2/8", "openai/gpt-oss-120b", "Recommend one tech career in 1 sentence", "RECOMMENDATIONS"))
ok.append(test_model("3/8", "openai/gpt-oss-120b", "Skill gap for data scientist in 2 sentences", "SKILL GAP"))
ok.append(test_model("4/8", "openai/gpt-oss-120b", "2-week Python learning plan", "ROADMAP"))
ok.append(test_model("5/8", "openai/gpt-oss-20b", "1 MCQ: 2+2?\nA) 3\nB) 4\nC) 5\nD) 6\nANSWER: B", "APTITUDE"))
ok.append(test_model("6/8", "openai/gpt-oss-120b", "One interview question for data scientist", "INTERVIEW"))
ok.append(test_model("7/8", "openai/gpt-oss-20b", "Recommend 1 free Python course", "COURSES"))
ok.append(test_model("8/8", "openai/gpt-oss-safeguard-20b", "Is 'hello' safe? Answer SAFE or UNSAFE", "SAFEGUARD"))

print("=" * 60)
passed = sum(ok)
total = len(ok)
print(f"{'🎉 All models working!' if passed == total else f'⚠️  {total - passed}/{total} test(s) failed.'}")
print("=" * 60)

# Print discovered models for reference
if accessible:
    print("\n📋 Your accessible models:")
    for m in accessible:
        print(f"   • {m}")
