# routers/admin.py
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from typing import Optional

from database import get_db
from oauth2 import get_current_admin
from models import User, Student, Career
from crud import get_all_users, get_all_careers

router = APIRouter(prefix="/admin", tags=["Admin"])


@router.get("/users")
def list_users(
    skip: int = 0, limit: int = 50,
    search: Optional[str] = None, role: Optional[str] = None,
    db: Session = Depends(get_db),
    _: User = Depends(get_current_admin)
):
    return get_all_users(db, skip, limit, search, role)


@router.get("/students")
def list_students(
    skip: int = 0, limit: int = 50,
    department: Optional[str] = None, year: Optional[int] = None,
    db: Session = Depends(get_db),
    _: User = Depends(get_current_admin)
):
    from sqlalchemy import or_
    query = db.query(Student, User).join(User, Student.user_id == User.user_id)
    if department:
        query = query.filter(Student.department == department)
    if year:
        query = query.filter(Student.year_of_study == year)

    results = query.offset(skip).limit(limit).all()
    return [
        {
            "student_id": s.student_id,
            "full_name": u.full_name,
            "email": u.email,
            "degree": s.degree,
            "department": s.department,
            "year_of_study": s.year_of_study,
            "cgpa": float(s.cgpa) if s.cgpa else None
        }
        for s, u in results
    ]


@router.get("/careers")
def list_careers_admin(
    skip: int = 0, limit: int = 100,
    search: Optional[str] = None,
    db: Session = Depends(get_db),
    _: User = Depends(get_current_admin)
):
    return get_all_careers(db, skip, limit, search)
