# routers/notifications.py
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from database import get_db
from oauth2 import get_current_user, get_current_admin
from models import User, Notification
from schemas import NotificationCreate, NotificationResponse
from crud import get_notifications, mark_notification_read, mark_all_read, create_notification

router = APIRouter(prefix="/notifications", tags=["Notifications"])


@router.get("/", response_model=list[NotificationResponse])
def list_notifications(
    unread_only: bool = False, db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    return get_notifications(db, current_user.user_id, unread_only)


@router.get("/unread-count")
def unread_count(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    count = len(get_notifications(db, current_user.user_id, unread_only=True))
    return {"unread_count": count}


@router.put("/{notification_id}/read")
def mark_read(
    notification_id: int, db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    if not mark_notification_read(db, notification_id, current_user.user_id):
        raise HTTPException(status_code=404, detail="Not found")
    return {"message": "Marked as read"}


@router.put("/read-all")
def mark_all(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    mark_all_read(db, current_user.user_id)
    return {"message": "All marked as read"}


@router.post("/", response_model=NotificationResponse)
def create(
    notif: NotificationCreate, db: Session = Depends(get_db),
    _: User = Depends(get_current_admin)
):
    return create_notification(db=db, notif=notif)
