# routers/ai_aptitude.py
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List, Optional
from pydantic import BaseModel, Field
from datetime import datetime, timedelta
import secrets

from database import get_db
from oauth2 import get_current_user
from models import User, Student, StudentSkill, Skill, Assessment
from crud import get_student_by_user
from ai.ai_service import AIService
from ai.config import AIConfig

router = APIRouter(prefix="/ai/aptitude", tags=["AI Aptitude"])


class AptitudeGenerateRequest(BaseModel):
    num_questions: int = 20
    previous_questions: List[str] = []


class AptitudeSubmitRequest(BaseModel):
    session_token: str
    user_answers: List[Optional[int]] = Field(default_factory=list)
    time_taken_seconds: int = 0


# Module-level store for answer keys
_answer_store = {}


@router.post("/generate")
async def generate_questions(
    request: AptitudeGenerateRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Generate fresh AI-powered aptitude questions."""
    student = get_student_by_user(db, current_user.user_id)
    if not student:
        raise HTTPException(status_code=404, detail="Create profile first")

    student_skills_db = db.query(StudentSkill).filter(StudentSkill.student_id == student.student_id).all()
    all_skills = {s.skill_id: s.skill_name for s in db.query(Skill).all()}
    skill_names = [all_skills[ss.skill_id] for ss in student_skills_db if ss.skill_id in all_skills]

    career_focus = skill_names[0] if skill_names else (student.department or "general technology")

    ai = AIService()
    questions = ai.generate_aptitude_questions(
        user_skills=skill_names,
        career_focus=career_focus,
        previous_questions=request.previous_questions,
        num_questions=request.num_questions
    )

    if not questions or len(questions) < 5:
        raise HTTPException(status_code=500, detail="Failed to generate enough questions")

    session_token = secrets.token_urlsafe(32)
    _answer_store[session_token] = {
        "user_id": current_user.user_id,
        "questions": questions,
        "created_at": datetime.utcnow()
    }

    # Cleanup old sessions
    cutoff = datetime.utcnow() - timedelta(hours=2)
    expired_keys = [k for k, v in list(_answer_store.items()) if v["created_at"] < cutoff]
    for k in expired_keys:
        del _answer_store[k]

    public_questions = [
        {
            "id": i,
            "question": q["question"],
            "options": q["options"],
            "category": q.get("category", "General"),
            "difficulty": q.get("difficulty", "Medium")
        }
        for i, q in enumerate(questions)
    ]

    return {
        "questions": public_questions,
        "session_token": session_token,
        "total": len(public_questions),
        "powered_by": "Groq" if AIConfig.USE_GROQ else "AI Engine",
        "career_focus": career_focus,
        "based_on_skills": skill_names[:5]
    }


@router.post("/submit")
async def submit_answers(
    request: AptitudeSubmitRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Submit answers and get scored results."""
    student = get_student_by_user(db, current_user.user_id)
    if not student:
        raise HTTPException(status_code=404, detail="Create profile first")

    if request.session_token not in _answer_store:
        raise HTTPException(status_code=400, detail="Invalid or expired session")

    session = _answer_store[request.session_token]
    if session["user_id"] != current_user.user_id:
        raise HTTPException(status_code=403, detail="Session mismatch")

    questions = session["questions"]
    user_answers = request.user_answers
    del _answer_store[request.session_token]

    if len(questions) != len(user_answers):
        raise HTTPException(
            status_code=400, 
            detail=f"Answers count mismatch: got {len(user_answers)}, expected {len(questions)}"
        )

    # Calculate scores
    total = len(questions)
    correct = 0
    unanswered = 0
    category_scores = {}

    for i, q in enumerate(questions):
        cat = q.get("category", "General")
        if cat not in category_scores:
            category_scores[cat] = {"correct": 0, "total": 0}
        category_scores[cat]["total"] += 1

        user_ans = user_answers[i] if i < len(user_answers) else None

        if user_ans is None or user_ans == -1:
            unanswered += 1
        elif user_ans == q["answer"]:
            correct += 1
            category_scores[cat]["correct"] += 1

    overall_score = (correct / total * 100) if total > 0 else 0

    def pct(s):
        return round(s["correct"] / s["total"] * 100) if s["total"] > 0 else 0

    aptitude = pct(category_scores.get("Quantitative", {"correct": 0, "total": 0})) or overall_score
    logical = pct(category_scores.get("Logical", {"correct": 0, "total": 0})) or overall_score
    communication = pct(category_scores.get("Verbal", {"correct": 0, "total": 0})) or overall_score
    programming = pct(category_scores.get("Technical", {"correct": 0, "total": 0})) or overall_score

    from decimal import Decimal
    assessment = Assessment(
        student_id=student.student_id,
        aptitude_score=Decimal(str(aptitude)),
        logical_score=Decimal(str(logical)),
        communication_score=Decimal(str(communication)),
        programming_score=Decimal(str(programming))
    )
    db.add(assessment)
    db.commit()
    db.refresh(assessment)

    return {
        "overall_score": round(overall_score, 2),
        "correct": correct,
        "total": total,
        "unanswered": unanswered,
        "time_taken_seconds": request.time_taken_seconds,
        "category_breakdown": {
            cat: {"score": pct(s), "correct": s["correct"], "total": s["total"]}
            for cat, s in category_scores.items()
        },
        "sub_scores": {
            "aptitude": aptitude,
            "logical": logical,
            "communication": communication,
            "programming": programming
        },
        "assessment_id": assessment.assessment_id,
        "performance_message": get_performance_message(overall_score)
    }


def get_performance_message(score: float) -> str:
    if score >= 85:
        return "Outstanding! 🌟 You have exceptional aptitude for this career path."
    elif score >= 70:
        return "Great job! 🎉 Strong performance across most areas."
    elif score >= 55:
        return "Good effort! 👍 Solid foundation with room to grow."
    elif score >= 40:
        return "Keep practicing! 💪 Focus on weaker categories."
    else:
        return "Don't give up! 🚀 Review fundamentals and try again."
