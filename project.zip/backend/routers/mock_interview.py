# routers/mock_interview.py
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime

from database import get_db
from oauth2 import get_current_user
from models import User, Student, StudentSkill, Skill
from crud import get_student_by_user
from ai.ai_service import AIService
from ai.config import AIConfig

router = APIRouter(prefix="/mock-interview", tags=["Mock Interview"])


# ===== Request/Response Models =====

class StartInterviewRequest(BaseModel):
    career_name: str = "Software Engineer"
    num_questions: int = 10
    difficulty: str = "Medium"  # Easy, Medium, Hard


class InterviewQuestionResponse(BaseModel):
    question_id: str
    question: str
    category: str
    difficulty: str
    hint: Optional[str] = None


class AnswerSubmissionRequest(BaseModel):
    session_id: str
    question_id: str
    answer: str


class AnswerFeedbackResponse(BaseModel):
    score: int  # 0-100
    feedback: str
    strengths: List[str]
    improvements: List[str]
    sample_answer: Optional[str] = None


class InterviewSession(BaseModel):
    session_id: str
    career_name: str
    questions: List[InterviewQuestionResponse]
    current_index: int = 0
    created_at: str
    answers: List[dict] = []


class InterviewResult(BaseModel):
    session_id: str
    career_name: str
    total_questions: int
    answered: int
    average_score: float
    category_breakdown: dict
    overall_feedback: str
    recommendations: List[str]


# ===== In-Memory Storage (Use Redis/DB in production) =====
_interview_sessions = {}


# ===== Endpoints =====

@router.post("/start")
async def start_interview(
    request: StartInterviewRequest,
    current_user: User = Depends(get_current_user)
):
    """Start a new mock interview session with AI-generated questions."""
    
    session_id = f"interview_{current_user.user_id}_{datetime.utcnow().timestamp()}"
    
    # Generate questions using AI
    ai = AIService()
    questions = ai.generate_interview_questions_for_career(
        career_name=request.career_name,
        num_questions=request.num_questions,
        difficulty=request.difficulty
    )
    
    if not questions or len(questions) == 0:
        raise HTTPException(status_code=500, detail="Failed to generate interview questions")
    
    # Store session
    _interview_sessions[session_id] = {
        "user_id": current_user.user_id,
        "career_name": request.career_name,
        "questions": questions,
        "current_index": 0,
        "answers": [],
        "created_at": datetime.utcnow().isoformat()
    }
    
    return {
        "session_id": session_id,
        "career_name": request.career_name,
        "total_questions": len(questions),
        "questions": questions,
        "current_index": 0,
        "powered_by": "Groq" if AIConfig.USE_GROQ else "Fallback"
    }


@router.post("/submit-answer")
async def submit_answer(
    request: AnswerSubmissionRequest,
    current_user: User = Depends(get_current_user)
):
    """Submit an answer and get AI feedback."""
    
    if request.session_id not in _interview_sessions:
        raise HTTPException(status_code=404, detail="Interview session not found")
    
    session = _interview_sessions[request.session_id]
    
    if session["user_id"] != current_user.user_id:
        raise HTTPException(status_code=403, detail="Unauthorized")
    
    # Find the question
    question = next((q for q in session["questions"] if q["question_id"] == request.question_id), None)
    if not question:
        raise HTTPException(status_code=404, detail="Question not found")
    
    if not request.answer or len(request.answer.strip()) < 10:
        raise HTTPException(status_code=400, detail="Answer too short. Please provide at least 10 characters.")
    
    # Get AI feedback
    ai = AIService()
    feedback = ai.evaluate_interview_answer(
        question=question["question"],
        answer=request.answer,
        category=question["category"],
        career_name=session["career_name"]
    )
    
    # Store answer
    session["answers"].append({
        "question_id": request.question_id,
        "question": question["question"],
        "answer": request.answer,
        "score": feedback["score"],
        "feedback": feedback,
        "timestamp": datetime.utcnow().isoformat()
    })
    
    return {
        "question_id": request.question_id,
        "score": feedback["score"],
        "feedback": feedback["feedback"],
        "strengths": feedback["strengths"],
        "improvements": feedback["improvements"],
        "sample_answer": feedback.get("sample_answer"),
        "next_question_index": len(session["answers"])
    }


@router.post("/next-question")
async def get_next_question(
    request: dict,
    current_user: User = Depends(get_current_user)
):
    """Get the next question in the interview."""
    
    session_id = request.get("session_id")
    if not session_id or session_id not in _interview_sessions:
        raise HTTPException(status_code=404, detail="Session not found")
    
    session = _interview_sessions[session_id]
    if session["user_id"] != current_user.user_id:
        raise HTTPException(status_code=403, detail="Unauthorized")
    
    next_index = len(session["answers"])
    
    if next_index >= len(session["questions"]):
        return {
            "completed": True,
            "message": "All questions answered. Get your results!",
            "next_index": next_index
        }
    
    return {
        "completed": False,
        "current_index": next_index,
        "question": session["questions"][next_index],
        "total_questions": len(session["questions"]),
        "answered": next_index
    }


@router.post("/result")
async def get_interview_result(
    request: dict,
    current_user: User = Depends(get_current_user)
):
    """Get final interview results with overall feedback."""
    
    session_id = request.get("session_id")
    if not session_id or session_id not in _interview_sessions:
        raise HTTPException(status_code=404, detail="Session not found")
    
    session = _interview_sessions[session_id]
    if session["user_id"] != current_user.user_id:
        raise HTTPException(status_code=403, detail="Unauthorized")
    
    if not session["answers"]:
        raise HTTPException(status_code=400, detail="No answers submitted yet")
    
    # Calculate statistics
    total_score = sum(a["score"] for a in session["answers"])
    avg_score = total_score / len(session["answers"])
    
    # Category breakdown
    category_scores = {}
    for answer in session["answers"]:
        question = next((q for q in session["questions"] if q["question_id"] == answer["question_id"]), None)
        if question:
            cat = question["category"]
            if cat not in category_scores:
                category_scores[cat] = {"total": 0, "count": 0}
            category_scores[cat]["total"] += answer["score"]
            category_scores[cat]["count"] += 1
    
    for cat in category_scores:
        category_scores[cat]["average"] = round(category_scores[cat]["total"] / category_scores[cat]["count"], 2)
    
    # Get AI overall feedback
    ai = AIService()
    overall_feedback = ai.generate_interview_overall_feedback(
        career_name=session["career_name"],
        answers=session["answers"],
        average_score=avg_score
    )
    
    # Generate recommendations
    recommendations = ai.generate_interview_recommendations(
        career_name=session["career_name"],
        average_score=avg_score,
        category_scores=category_scores
    )
    
    # Cleanup session
    result = {
        "session_id": session_id,
        "career_name": session["career_name"],
        "total_questions": len(session["questions"]),
        "answered": len(session["answers"]),
        "average_score": round(avg_score, 2),
        "category_breakdown": category_scores,
        "overall_feedback": overall_feedback,
        "recommendations": recommendations,
        "answers_detail": session["answers"]
    }
    
    # Optionally delete session to free memory
    del _interview_sessions[session_id]
    
    return result


@router.post("/end")
async def end_interview(
    request: dict,
    current_user: User = Depends(get_current_user)
):
    """End interview without completing."""
    
    session_id = request.get("session_id")
    if session_id in _interview_sessions:
        del _interview_sessions[session_id]
    
    return {"message": "Interview ended", "session_id": session_id}
