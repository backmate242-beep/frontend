# routers/roadmap.py
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from database import get_db
from oauth2 import get_current_user, get_current_admin
from models import User
from schemas import RoadmapCreate, RoadmapResponse
from crud import get_roadmap, get_roadmaps_by_career, create_roadmap

router = APIRouter(prefix="/roadmaps", tags=["Roadmaps"])


@router.post("/", response_model=RoadmapResponse, status_code=201)
def add_roadmap(
    roadmap: RoadmapCreate, db: Session = Depends(get_db),
    _: User = Depends(get_current_admin)
):
    return create_roadmap(db=db, roadmap=roadmap)


@router.get("/career/{career_id}", response_model=list[RoadmapResponse])
def by_career(
    career_id: int, db: Session = Depends(get_db),
    _: User = Depends(get_current_user)
):
    return get_roadmaps_by_career(db, career_id)


@router.get("/{roadmap_id}", response_model=RoadmapResponse)
def get_by_id(
    roadmap_id: int, db: Session = Depends(get_db),
    _: User = Depends(get_current_user)
):
    roadmap = get_roadmap(db, roadmap_id)
    if not roadmap:
        raise HTTPException(status_code=404, detail="Not found")
    return roadmap
