# routers/career.py
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import Optional

from database import get_db
from oauth2 import get_current_user, get_current_admin
from models import User
from schemas import (
    CareerCreate, CareerResponse, CareerUpdate,
    CareerSkillResponse, CareerSkillCreate
)
from crud import (
    get_career, get_all_careers, create_career, update_career,
    delete_career, get_career_skills, add_career_skill
)

router = APIRouter(prefix="/careers", tags=["Careers"])


@router.post("/", response_model=CareerResponse, status_code=status.HTTP_201_CREATED)
def add_career(
    career: CareerCreate, db: Session = Depends(get_db),
    _: User = Depends(get_current_admin)
):
    return create_career(db=db, career=career)


@router.get("/", response_model=list[CareerResponse])
def list_careers(
    skip: int = 0, limit: int = 100, search: Optional[str] = None,
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user)
):
    return get_all_careers(db, skip, limit, search)


@router.get("/{career_id}", response_model=CareerResponse)
def get_by_id(
    career_id: int, db: Session = Depends(get_db),
    _: User = Depends(get_current_user)
):
    career = get_career(db, career_id)
    if not career:
        raise HTTPException(status_code=404, detail="Not found")
    return career


@router.put("/{career_id}", response_model=CareerResponse)
def update_career_endpoint(
    career_id: int, career: CareerUpdate, db: Session = Depends(get_db),
    _: User = Depends(get_current_admin)
):
    updated = update_career(db, career_id, career)
    if not updated:
        raise HTTPException(status_code=404, detail="Not found")
    return updated


@router.delete("/{career_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_career_endpoint(
    career_id: int, db: Session = Depends(get_db),
    _: User = Depends(get_current_admin)
):
    if not delete_career(db, career_id):
        raise HTTPException(status_code=404, detail="Not found")
    return None


# ===== Career Skills =====

@router.post("/{career_id}/skills", response_model=CareerSkillResponse, status_code=status.HTTP_201_CREATED)
def add_skill(
    career_id: int, payload: CareerSkillCreate,
    db: Session = Depends(get_db),
    _: User = Depends(get_current_admin)
):
    return add_career_skill(db, career_id, payload.skill_id, payload.importance_level)


@router.get("/{career_id}/skills", response_model=list[CareerSkillResponse])
def get_skills(
    career_id: int, db: Session = Depends(get_db),
    _: User = Depends(get_current_user)
):
    return get_career_skills(db, career_id)
