# routers/user.py
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import Optional

from database import get_db
from oauth2 import get_current_user, get_current_admin
from models import User
from schemas import UserResponse
from crud import get_user, get_all_users, update_user, delete_user

router = APIRouter(prefix="/users", tags=["Users"])


@router.get("/me", response_model=UserResponse)
def get_my_profile(current_user: User = Depends(get_current_user)):
    return current_user


@router.get("/", response_model=list[UserResponse])
def list_users(
    skip: int = 0, limit: int = 50,
    search: Optional[str] = None, role: Optional[str] = None,
    db: Session = Depends(get_db),
    _: User = Depends(get_current_admin)
):
    return get_all_users(db, skip, limit, search, role)


@router.get("/{user_id}", response_model=UserResponse)
def get_user_by_id(
    user_id: int, db: Session = Depends(get_db),
    _: User = Depends(get_current_admin)
):
    user = get_user(db, user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return user


@router.put("/me", response_model=UserResponse)
def update_my_profile(
    full_name: Optional[str] = None,
    profile_picture: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    updates = {k: v for k, v in {"full_name": full_name, "profile_picture": profile_picture}.items() if v}
    return update_user(db, current_user.user_id, updates)


@router.delete("/{user_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_user_endpoint(
    user_id: int, db: Session = Depends(get_db),
    _: User = Depends(get_current_admin)
):
    if not delete_user(db, user_id):
        raise HTTPException(status_code=404, detail="User not found")
    return None
