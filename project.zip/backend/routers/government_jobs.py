# routers/government_jobs.py
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import Optional

from database import get_db
from oauth2 import get_current_user, get_current_admin
from models import User
from schemas import GovernmentJobCreate, GovernmentJobResponse
from crud import (
    get_all_government_jobs, get_government_job,
    create_government_job, add_job_bookmark,
    get_user_job_bookmarks, remove_job_bookmark
)

router = APIRouter(prefix="/government-jobs", tags=["Government Jobs"])


@router.get("/", response_model=list[GovernmentJobResponse])
def list_jobs(
    skip: int = 0,
    limit: int = 100,
    search: Optional[str] = None,
    state: Optional[str] = None,
    exam_type: Optional[str] = None,
    qualification: Optional[str] = None,
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user)
):
    return get_all_government_jobs(db, skip, limit, search, state, exam_type, qualification)


@router.get("/{job_id}", response_model=GovernmentJobResponse)
def get_job(
    job_id: int,
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user)
):
    job = get_government_job(db, job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    return job


@router.post("/", response_model=GovernmentJobResponse, status_code=201)
def create_job(
    job: GovernmentJobCreate,
    db: Session = Depends(get_db),
    _: User = Depends(get_current_admin)
):
    return create_government_job(db, job)


@router.post("/bookmark")
def bookmark_job(
    payload: dict,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    job_id = payload.get("job_id")
    if not job_id:
        raise HTTPException(status_code=400, detail="job_id required")
    bm = add_job_bookmark(db, current_user.user_id, job_id, "government")
    return {"message": "Bookmarked", "bookmark_id": bm.id}


@router.delete("/bookmark/{job_id}")
def remove_bookmark(
    job_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    if not remove_job_bookmark(db, current_user.user_id, job_id, "government"):
        raise HTTPException(status_code=404, detail="Not found")
    return {"message": "Removed"}


@router.get("/my/bookmarks")
def my_bookmarks(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    bms = get_user_job_bookmarks(db, current_user.user_id)
    gov_bms = [b for b in bms if b.job_type == "government"]
    result = []
    for b in gov_bms:
        job = get_government_job(db, b.job_id)
        if job:
            result.append({
                "bookmark_id": b.id,
                "job": {
                    "job_id": job.job_id,
                    "title": job.title,
                    "department": job.department,
                    "state": job.state,
                    "last_date": str(job.last_date) if job.last_date else None,
                    "apply_link": job.apply_link
                }
            })
    return result
