# routers/recommendation.py
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from decimal import Decimal

from database import get_db
from oauth2 import get_current_user
from models import User, CareerRecommendation
from schemas import CareerRecommendationResponse
from crud import get_student_by_user, get_recommendations_for_student

router = APIRouter(prefix="/recommendations", tags=["Recommendations"])


@router.get("/me", response_model=list[CareerRecommendationResponse])
def get_my_recommendations(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    student = get_student_by_user(db, current_user.user_id)
    if not student:
        raise HTTPException(status_code=404, detail="Profile not found")
    return get_recommendations_for_student(db, student.student_id)


@router.delete("/me", status_code=204)
def clear_recommendations(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    from crud import clear_recommendations
    student = get_student_by_user(db, current_user.user_id)
    if student:
        clear_recommendations(db, student.student_id)
    return None
