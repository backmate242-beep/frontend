# routers/bookmarks.py
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from database import get_db
from oauth2 import get_current_user
from models import User
from schemas import BookmarkCreate
from crud import add_bookmark, get_bookmarks, remove_bookmark

router = APIRouter(prefix="/bookmarks", tags=["Bookmarks"])


@router.post("/")
def add(
    payload: BookmarkCreate, db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    bookmark = add_bookmark(db, current_user.user_id, payload.career_id)
    return {"message": "Bookmarked", "bookmark_id": bookmark.bookmark_id}


@router.get("/")
def list_my_bookmarks(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    bookmarks = get_bookmarks(db, current_user.user_id)
    return [
        {
            "bookmark_id": b.bookmark_id,
            "career_id": c.career_id,
            "career_name": c.career_name,
            "description": c.description,
            "average_salary": float(c.average_salary) if c.average_salary else None
        }
        for b, c in bookmarks
    ]


@router.delete("/{career_id}")
def remove(
    career_id: int, db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    if not remove_bookmark(db, current_user.user_id, career_id):
        raise HTTPException(status_code=404, detail="Not found")
    return {"message": "Removed"}
