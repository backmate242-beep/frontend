# routers/assessment_quiz.py
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from decimal import Decimal

from database import get_db
from oauth2 import get_current_user
from models import User, Assessment
from schemas import QuizSubmission
from crud import get_student_by_user, create_assessment

router = APIRouter(prefix="/quiz", tags=["Career Quiz"])

QUIZ_QUESTIONS = [
    {"id": 1, "question": "What type of work excites you the most?",
     "options": [
         {"text": "Building software and apps", "category": "technology"},
         {"text": "Analyzing data and finding patterns", "category": "data_science"},
         {"text": "Designing beautiful interfaces", "category": "design"},
         {"text": "Leading teams and projects", "category": "business"}
     ]},
    {"id": 2, "question": "How do you prefer to solve problems?",
     "options": [
         {"text": "Using logical, step-by-step methods", "category": "analytical"},
         {"text": "Brainstorming creative solutions", "category": "creative"},
         {"text": "Collaborating with others", "category": "social"},
         {"text": "Following proven processes", "category": "conventional"}
     ]},
    {"id": 3, "question": "What's your ideal work environment?",
     "options": [
         {"text": "Fast-paced tech startup", "category": "technology"},
         {"text": "Research lab", "category": "research"},
         {"text": "Creative studio", "category": "design"},
         {"text": "Corporate office", "category": "business"}
     ]},
    {"id": 4, "question": "Which subject did you enjoy most?",
     "options": [
         {"text": "Mathematics and Physics", "category": "analytical"},
         {"text": "Computer Science", "category": "technology"},
         {"text": "Art and Design", "category": "creative"},
         {"text": "Business and Economics", "category": "business"}
     ]},
    {"id": 5, "question": "What motivates you most?",
     "options": [
         {"text": "Solving complex technical challenges", "category": "analytical"},
         {"text": "Creating something new", "category": "creative"},
         {"text": "Helping and teaching others", "category": "social"},
         {"text": "Achieving financial success", "category": "business"}
     ]},
    {"id": 6, "question": "How do you handle tight deadlines?",
     "options": [
         {"text": "Plan carefully and execute systematically", "category": "analytical"},
         {"text": "Thrive under pressure and adapt quickly", "category": "technology"},
         {"text": "Collaborate to find solutions", "category": "social"},
         {"text": "Prioritize ruthlessly", "category": "conventional"}
     ]},
    {"id": 7, "question": "Preferred team size?",
     "options": [
         {"text": "Solo or very small team", "category": "analytical"},
         {"text": "Small agile team (3-5)", "category": "technology"},
         {"text": "Medium team (6-15)", "category": "social"},
         {"text": "Large organization", "category": "business"}
     ]},
    {"id": 8, "question": "Work-life balance importance?",
     "options": [
         {"text": "Extremely important - flexibility", "category": "conventional"},
         {"text": "Important, willing to hustle when needed", "category": "technology"},
         {"text": "Passionate, balance is secondary", "category": "creative"},
         {"text": "Depends on project phase", "category": "social"}
     ]}
]

PERSONALITY_SCORES = {
    "technology": {"aptitude": 85, "logical": 90, "communication": 60, "programming": 88},
    "data_science": {"aptitude": 92, "logical": 95, "communication": 55, "programming": 80},
    "design": {"aptitude": 70, "logical": 65, "communication": 80, "programming": 60},
    "business": {"aptitude": 75, "logical": 70, "communication": 90, "programming": 50},
    "research": {"aptitude": 95, "logical": 90, "communication": 65, "programming": 70},
    "analytical": {"aptitude": 90, "logical": 92, "communication": 60, "programming": 75},
    "creative": {"aptitude": 70, "logical": 60, "communication": 80, "programming": 65},
    "social": {"aptitude": 65, "logical": 60, "communication": 95, "programming": 50},
    "conventional": {"aptitude": 70, "logical": 75, "communication": 70, "programming": 60}
}

CAREER_SUGGESTIONS = {
    "technology": ["Software Engineer", "DevOps Engineer", "Full Stack Developer", "Mobile Developer"],
    "data_science": ["Data Scientist", "ML Engineer", "Data Analyst", "AI Researcher"],
    "design": ["UI/UX Designer", "Product Designer", "Graphic Designer", "Web Designer"],
    "business": ["Product Manager", "Business Analyst", "Marketing Manager", "Consultant"],
    "research": ["Research Scientist", "Academic Professor", "R&D Engineer"],
    "analytical": ["Software Engineer", "Data Scientist", "Financial Analyst", "Systems Engineer"],
    "creative": ["UX Designer", "Content Creator", "Product Designer", "Frontend Developer"],
    "social": ["HR Manager", "Teacher", "Sales Manager", "Customer Success Manager"],
    "conventional": ["Accountant", "Project Manager", "Operations Analyst", "QA Engineer"]
}


@router.get("/questions")
def get_questions():
    return {"total_questions": len(QUIZ_QUESTIONS), "questions": QUIZ_QUESTIONS}


@router.post("/submit")
def submit_quiz(
    submission: QuizSubmission, db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    student = get_student_by_user(db, current_user.user_id)
    if not student:
        raise HTTPException(status_code=404, detail="Create profile first")

    category_scores = {}
    for ans in submission.answers:
        cat = ans.get("selected_category", "").lower()
        category_scores[cat] = category_scores.get(cat, 0) + 1

    sorted_cats = sorted(category_scores.items(), key=lambda x: x[1], reverse=True)
    primary = sorted_cats[0][0] if sorted_cats else "analytical"

    scores = PERSONALITY_SCORES.get(primary, PERSONALITY_SCORES["analytical"])

    assessment = Assessment(
        student_id=student.student_id,
        aptitude_score=Decimal(str(scores["aptitude"])),
        logical_score=Decimal(str(scores["logical"])),
        communication_score=Decimal(str(scores["communication"])),
        programming_score=Decimal(str(scores["programming"]))
    )
    db.add(assessment)
    db.commit()
    db.refresh(assessment)

    return {
        "personality_type": primary.title(),
        "category_breakdown": category_scores,
        "assessment_scores": scores,
        "suggested_careers": CAREER_SUGGESTIONS.get(primary, []),
        "assessment_id": assessment.assessment_id
    }
