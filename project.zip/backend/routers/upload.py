# routers/upload.py
import os
import uuid
from fastapi import APIRouter, Depends, UploadFile, File, HTTPException
from sqlalchemy.orm import Session
import aiofiles

from database import get_db
from oauth2 import get_current_user
from models import User, Student
from crud import get_student_by_user
from ai.ai_service import AIService

router = APIRouter(prefix="/upload", tags=["Upload"])

UPLOAD_DIR = "uploads"
os.makedirs(f"{UPLOAD_DIR}/resumes", exist_ok=True)
os.makedirs(f"{UPLOAD_DIR}/profile_pics", exist_ok=True)

ALLOWED = {".pdf", ".docx", ".txt"}
ALLOWED_IMG = {".jpg", ".jpeg", ".png", ".webp"}


@router.post("/resume")
async def upload_resume(
    file: UploadFile = File(...),
    target_career: str = "Software Engineer",
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    ext = os.path.splitext(file.filename)[1].lower()
    if ext not in ALLOWED:
        raise HTTPException(status_code=400, detail=f"Allowed: {ALLOWED}")

    content = await file.read()
    if len(content) > 5 * 1024 * 1024:
        raise HTTPException(status_code=400, detail="Max 5MB")

    fname = f"{current_user.user_id}_{uuid.uuid4().hex}{ext}"
    path = os.path.join(UPLOAD_DIR, "resumes", fname)
    async with aiofiles.open(path, 'wb') as f:
        await f.write(content)

    text = ""
    if ext == ".txt":
        text = content.decode('utf-8', errors='ignore')
    elif ext == ".pdf":
        try:
            import PyPDF2, io
            reader = PyPDF2.PdfReader(io.BytesIO(content))
            text = "\n".join([p.extract_text() for p in reader.pages])
        except ImportError:
            text = "Install PyPDF2 for PDF support"

    student = get_student_by_user(db, current_user.user_id)
    user_skills = []
    education = "N/A"
    if student:
        from models import StudentSkill, Skill
        skills = db.query(Skill).join(StudentSkill, Skill.skill_id == StudentSkill.skill_id).filter(
            StudentSkill.student_id == student.student_id
        ).all()
        user_skills = [s.skill_name for s in skills]
        education = f"{student.degree or ''} in {student.department or ''}".strip()

    ai = AIService(db)
    feedback = ai.analyze_resume(text or "Resume uploaded", target_career, user_skills, education)

    return {
        "filename": file.filename,
        "file_size": len(content),
        "extracted_text_length": len(text),
        "ai_feedback": feedback
    }


@router.post("/profile-picture")
async def upload_pic(
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    ext = os.path.splitext(file.filename)[1].lower()
    if ext not in ALLOWED_IMG:
        raise HTTPException(status_code=400, detail=f"Allowed: {ALLOWED_IMG}")

    content = await file.read()
    if len(content) > 2 * 1024 * 1024:
        raise HTTPException(status_code=400, detail="Max 2MB")

    user_dir = f"{UPLOAD_DIR}/profile_pics/{current_user.user_id}"
    os.makedirs(user_dir, exist_ok=True)
    path = os.path.join(user_dir, f"profile{ext}")

    async with aiofiles.open(path, 'wb') as f:
        await f.write(content)

    current_user.profile_picture = f"/uploads/profile_pics/{current_user.user_id}/profile{ext}"
    db.commit()

    return {"url": current_user.profile_picture, "message": "Updated"}
