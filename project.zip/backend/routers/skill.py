# routers/skill.py
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import Optional

from database import get_db
from oauth2 import get_current_user, get_current_admin
from models import User
from schemas import SkillCreate, SkillResponse
from crud import get_skill, get_skill_by_name, get_all_skills, create_skill

router = APIRouter(prefix="/skills", tags=["Skills"])


@router.post("/", response_model=SkillResponse, status_code=status.HTTP_201_CREATED)
def add_skill(
    skill: SkillCreate, db: Session = Depends(get_db),
    _: User = Depends(get_current_admin)
):
    if get_skill_by_name(db, skill.skill_name):
        raise HTTPException(status_code=400, detail="Skill exists")
    return create_skill(db=db, skill=skill)


@router.get("/", response_model=list[SkillResponse])
def list_skills(
    skip: int = 0, limit: int = 200, search: Optional[str] = None,
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user)
):
    return get_all_skills(db, skip, limit, search)


@router.get("/{skill_id}", response_model=SkillResponse)
def get_by_id(
    skill_id: int, db: Session = Depends(get_db),
    _: User = Depends(get_current_user)
):
    skill = get_skill(db, skill_id)
    if not skill:
        raise HTTPException(status_code=404, detail="Not found")
    return skill
