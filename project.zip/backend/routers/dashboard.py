# routers/dashboard.py
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import func
from datetime import datetime, timedelta

from database import get_db
from oauth2 import get_current_user, get_current_admin
from models import (
    User, Student, Career, Skill, Course,
    CareerRecommendation, Assessment, StudentSkill
)
from crud import get_student_by_user, get_student_skills

router = APIRouter(prefix="/dashboard", tags=["Dashboard"])


@router.get("/student")
def student_dashboard(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    student = get_student_by_user(db, current_user.user_id)
    if not student:
        return {"error": "Create profile first"}

    skills = get_student_skills(db, student.student_id)
    prof_dist = {"Beginner": 0, "Intermediate": 0, "Advanced": 0}
    for s in skills:
        prof_dist[s.proficiency] = prof_dist.get(s.proficiency, 0) + 1

    latest = db.query(Assessment).filter(
        Assessment.student_id == student.student_id
    ).order_by(Assessment.assessment_date.desc()).first()

    top = db.query(CareerRecommendation).filter(
        CareerRecommendation.student_id == student.student_id
    ).order_by(CareerRecommendation.match_percentage.desc()).first()

    return {
        "student": {
            "name": current_user.full_name,
            "degree": student.degree,
            "department": student.department,
            "year_of_study": student.year_of_study,
            "cgpa": float(student.cgpa) if student.cgpa else None
        },
        "stats": {
            "total_skills": len(skills),
            "total_recommendations": db.query(CareerRecommendation).filter(
                CareerRecommendation.student_id == student.student_id
            ).count(),
            "assessments_taken": db.query(Assessment).filter(
                Assessment.student_id == student.student_id
            ).count()
        },
        "proficiency_distribution": prof_dist,
        "latest_assessment": {
            "aptitude": float(latest.aptitude_score) if latest else None,
            "logical": float(latest.logical_score) if latest else None,
            "communication": float(latest.communication_score) if latest else None,
            "programming": float(latest.programming_score) if latest else None,
            "date": str(latest.assessment_date) if latest else None
        } if latest else None,
        "top_career": {
            "name": top.career.career_name,
            "match": float(top.match_percentage)
        } if top else None
    }


@router.get("/admin")
def admin_dashboard(
    db: Session = Depends(get_db),
    _: User = Depends(get_current_admin)
):
    week_ago = datetime.utcnow() - timedelta(days=7)

    top_skills = db.query(
        Skill.skill_name, func.count(StudentSkill.student_skill_id).label('c')
    ).join(StudentSkill, Skill.skill_id == StudentSkill.skill_id
    ).group_by(Skill.skill_id).order_by(func.count(StudentSkill.student_skill_id).desc()).limit(10).all()

    top_careers = db.query(
        Career.career_name, func.count(CareerRecommendation.recommendation_id).label('c')
    ).join(CareerRecommendation, Career.career_id == CareerRecommendation.career_id
    ).group_by(Career.career_id).order_by(func.count(CareerRecommendation.recommendation_id).desc()).limit(10).all()

    avg = db.query(
        func.avg(Assessment.aptitude_score),
        func.avg(Assessment.logical_score),
        func.avg(Assessment.communication_score),
        func.avg(Assessment.programming_score)
    ).first()

    return {
        "overview": {
            "total_users": db.query(User).count(),
            "total_students": db.query(Student).count(),
            "total_careers": db.query(Career).count(),
            "total_skills": db.query(Skill).count(),
            "total_courses": db.query(Course).count(),
            "total_assessments": db.query(Assessment).count(),
            "total_recommendations": db.query(CareerRecommendation).count(),
            "recent_signups_7d": db.query(User).filter(User.created_at >= week_ago).count()
        },
        "top_skills": [{"name": s[0], "count": s[1]} for s in top_skills],
        "top_careers": [{"name": c[0], "recommendations": c[1]} for c in top_careers],
        "average_assessment_scores": {
            "aptitude": round(float(avg[0] or 0), 2),
            "logical": round(float(avg[1] or 0), 2),
            "communication": round(float(avg[2] or 0), 2),
            "programming": round(float(avg[3] or 0), 2)
        }
    }


