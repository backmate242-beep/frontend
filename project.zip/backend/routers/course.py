# routers/course.py
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from database import get_db
from oauth2 import get_current_user, get_current_admin
from models import User
from schemas import CourseCreate, CourseResponse
from crud import get_course, get_all_courses, get_courses_by_skill, create_course

router = APIRouter(prefix="/courses", tags=["Courses"])


@router.post("/", response_model=CourseResponse, status_code=201)
def add_course(
    course: CourseCreate, db: Session = Depends(get_db),
    _: User = Depends(get_current_admin)
):
    return create_course(db=db, course=course)


@router.get("/", response_model=list[CourseResponse])
def list_courses(
    skip: int = 0, limit: int = 200, db: Session = Depends(get_db),
    _: User = Depends(get_current_user)
):
    return get_all_courses(db, skip, limit)


@router.get("/skill/{skill_id}", response_model=list[CourseResponse])
def by_skill(
    skill_id: int, db: Session = Depends(get_db),
    _: User = Depends(get_current_user)
):
    return get_courses_by_skill(db, skill_id)


@router.get("/{course_id}", response_model=CourseResponse)
def get_by_id(
    course_id: int, db: Session = Depends(get_db),
    _: User = Depends(get_current_user)
):
    course = get_course(db, course_id)
    if not course:
        raise HTTPException(status_code=404, detail="Not found")
    return course
