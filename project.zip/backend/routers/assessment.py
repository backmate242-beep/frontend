# routers/assessment.py
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from database import get_db
from oauth2 import get_current_user
from models import User
from schemas import AssessmentCreate, AssessmentResponse
from crud import get_student_by_user, get_assessments_for_student, create_assessment

router = APIRouter(prefix="/assessments", tags=["Assessments"])


@router.post("/", response_model=AssessmentResponse, status_code=201)
def submit(
    assessment: AssessmentCreate, db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    student = get_student_by_user(db, current_user.user_id)
    if not student:
        raise HTTPException(status_code=404, detail="Create profile first")
    return create_assessment(db=db, assessment=assessment, student_id=student.student_id)


@router.get("/me", response_model=list[AssessmentResponse])
def get_my_assessments(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    student = get_student_by_user(db, current_user.user_id)
    if not student:
        raise HTTPException(status_code=404, detail="Profile not found")
    return get_assessments_for_student(db, student.student_id)
